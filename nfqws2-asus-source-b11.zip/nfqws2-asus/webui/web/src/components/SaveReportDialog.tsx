import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
  Typography,
} from '@mui/material';

import { sendSupportBundle, type SupportBundleFile } from '@/api/supportBundle';
import {
  canChooseReportLocation,
  inspectSupportReport,
  newSupportSubmissionId,
  saveSupportReport,
  sendSupportReport,
  type SupportMailAvailability,
  type SupportMailResult,
  type SupportReportFile,
  type SupportReportPreview,
} from '@/api/supportReport';

import { DpiAttachment } from '@/components/DpiAttachment';
import { ReportPreview } from '@/components/ReportPreview';

import { useAppStore } from '@/store/useAppStore';

import { useTranslation } from '@/hooks/useTranslation';

export const SaveReportDialog = ({
  file,
  csrfToken,
  availability,
  onSaved,
  onClose,
}: {
  file: SupportReportFile;
  csrfToken: string;
  availability?: SupportMailAvailability;
  onSaved: (saved: 'native' | 'browser') => void;
  onClose: () => void;
}) => {
  const { t } = useTranslation();
  const [bundle, setBundle] = useState<SupportBundleFile>();
  const [attachSelected, setAttachSelected] = useState(false);
  const [saving, setSaving] = useState(false);
  const [failed, setFailed] = useState(false);
  const [sending, setSending] = useState(false);
  const [sendFailed, setSendFailed] = useState(false);
  const [saved, setSaved] = useState<'native' | 'browser'>();
  const [result, setResult] = useState<SupportMailResult>();
  const [preview, setPreview] = useState<SupportReportPreview>();
  const [invalid, setInvalid] = useState(false);
  const pending = useRef(false);
  const attempt = useRef<string | undefined>(undefined);
  const native = canChooseReportLocation();
  useEffect(() => {
    let active = true;
    setBundle(undefined);
    setAttachSelected(false);
    void inspectSupportReport(file).then(
      (value) => {
        if (active) setPreview(value);
      },
      () => {
        if (active) setInvalid(true);
      },
    );
    return () => {
      active = false;
    };
  }, [file]);
  const save = async () => {
    if (pending.current) return;
    pending.current = true;
    setSaving(true);
    setFailed(false);
    try {
      // Keep the native picker inside this click's user activation.
      const method = await saveSupportReport(file);
      setSaved(method);
      onSaved(method);
    } catch (error) {
      if (!(error instanceof DOMException && error.name === 'AbortError'))
        setFailed(true);
    } finally {
      pending.current = false;
      setSaving(false);
    }
  };
  const send = async () => {
    if (
      pending.current ||
      !preview ||
      !availability?.configured ||
      !file.proof ||
      (attachSelected && (!bundle || !availability?.dpi_attachments)) ||
      result?.state === 'accepted' ||
      result?.state === 'unknown'
    )
      return;
    pending.current = true;
    setSending(true);
    setSendFailed(false);
    attempt.current = newSupportSubmissionId();
    try {
      setResult(
        bundle && attachSelected
          ? await sendSupportBundle(bundle, csrfToken, attempt.current)
          : await sendSupportReport(file, csrfToken, attempt.current, () =>
              useAppStore.getState().setAuth(false),
            ),
      );
    } catch {
      setSendFailed(true);
    } finally {
      pending.current = false;
      setSending(false);
    }
  };
  const busy = saving || sending;
  const terminal = result?.state === 'accepted' || result?.state === 'unknown';
  return (
    <Dialog
      open
      fullWidth
      maxWidth="md"
      onClose={() => !pending.current && onClose()}
    >
      <DialogTitle>{t('report.preview_title')}</DialogTitle>
      <DialogContent>
        <Stack spacing={2}>
          <Typography sx={{ overflowWrap: 'anywhere' }}>
            {file.filename}
          </Typography>
          <Typography variant="body2">{t('report.preview_privacy')}</Typography>
          <Typography variant="body2">{t('report.preview_consent')}</Typography>
          {!file.complete && (
            <Alert severity="warning">{t('report.partial')}</Alert>
          )}
          {preview ? (
            <ReportPreview preview={preview} />
          ) : invalid ? (
            <Alert severity="error">{t('report.errors.invalid')}</Alert>
          ) : (
            <CircularProgress size={24} />
          )}
          <DpiAttachment
            key={file.proof ?? file.filename}
            csrfToken={csrfToken}
            report={file}
            transportEnabled={availability?.dpi_attachments === true}
            disabled={busy || terminal}
            onPrepared={setBundle}
            onCleared={() => setBundle(undefined)}
            onSelection={setAttachSelected}
          />
          {!availability?.configured || !file.proof ? (
            <Alert severity="info">{t('report.mail_unavailable')}</Alert>
          ) : null}
          {result && (
            <Alert
              severity={
                result.state === 'accepted'
                  ? 'success'
                  : result.state === 'failed_safe'
                    ? 'error'
                    : 'warning'
              }
            >
              {t(`report.mail_states.${result.state}`)}
            </Alert>
          )}
          {sendFailed && (
            <Alert severity="error">{t('report.send_invalid')}</Alert>
          )}
          <Typography variant="body2">
            {t(native ? 'report.choose_hint' : 'report.browser_hint')}
          </Typography>
          {saved && (
            <Alert severity="success">{t(`report.saved_${saved}`)}</Alert>
          )}
          {failed && (
            <Alert severity="error">{t('report.errors.save_failed')}</Alert>
          )}
        </Stack>
      </DialogContent>
      <DialogActions sx={{ flexWrap: 'wrap' }}>
        <Button disabled={busy} onClick={onClose}>
          {t('common.cancel')}
        </Button>
        <Button disabled={busy} onClick={() => void save()}>
          {t(native ? 'report.choose_file' : 'report.download')}
        </Button>
        <Button
          variant="contained"
          disabled={
            busy ||
            !preview ||
            !availability?.configured ||
            !file.proof ||
            (attachSelected && (!bundle || !availability?.dpi_attachments)) ||
            terminal
          }
          onClick={() => void send()}
        >
          {sending ? (
            <CircularProgress size={20} />
          ) : (
            t(
              result?.state === 'failed_safe'
                ? 'report.send_again'
                : 'report.send',
            )
          )}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
