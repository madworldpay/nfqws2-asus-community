import { useState } from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Alert,
  Button,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from '@mui/material';

import type { DpiMetadata } from '@/api/dpiClient';
import {
  effectiveDpiSettings,
  parseDpiOptions,
  type DpiOptions,
} from '@/api/dpiOptions';

import { useTranslation } from '@/hooks/useTranslation';

export const DpiSettings = ({
  value,
  onChange,
  metadata,
  disabled,
  onInvalid,
}: {
  value: DpiOptions;
  onChange: (v: DpiOptions) => void;
  metadata: DpiMetadata;
  disabled: boolean;
  onInvalid: (v: boolean) => void;
}) => {
  const { t } = useTranslation();
  const [draft, setDraft] = useState<string>();
  const [invalid, setInvalid] = useState(false);
  const [invalidField, setInvalidField] = useState<string>();
  const e = effectiveDpiSettings(value, metadata);
  const change = (v: DpiOptions) => {
    onChange(v);
    setDraft(undefined);
    setInvalid(false);
    setInvalidField(undefined);
    onInvalid(false);
  };
  const config = (key: string, v: unknown) => {
    const c = { ...value.config };
    if (v === '') delete c[key];
    else c[key] = v;
    change({ ...value, config: c });
  };
  return (
    <Stack spacing={2}>
      <Typography variant="subtitle1">{t('dpi.settings')}</Typography>
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
        <TextField
          select
          fullWidth
          size="small"
          label={t('dpi.profile')}
          value={value.profile ?? 'ru'}
          disabled={disabled}
          onChange={(ev) => change({ ...value, profile: ev.target.value })}
        >
          {['ru', 'ir', 'cn', 'global'].map((p) => (
            <MenuItem key={p} value={p}>
              {p.toUpperCase()}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          select
          fullWidth
          size="small"
          label={t('dpi.language')}
          value={value.language ?? 'ru'}
          disabled={disabled}
          onChange={(ev) => change({ ...value, language: ev.target.value })}
        >
          {['ru', 'en', 'zh', 'fa', 'auto'].map((p) => (
            <MenuItem key={p} value={p}>
              {p}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          select
          fullWidth
          size="small"
          label={t('dpi.interface')}
          value={value.interface ?? ''}
          disabled={disabled}
          onChange={(ev) =>
            change({ ...value, interface: ev.target.value || null })
          }
        >
          <MenuItem value="">{t('dpi.native_default')}</MenuItem>
          {metadata.interfaces.map((p) => (
            <MenuItem key={p} value={p}>
              {p}
            </MenuItem>
          ))}
        </TextField>
      </Stack>
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
        <TextField
          fullWidth
          size="small"
          label={t('dpi.concurrency')}
          type="number"
          value={value.config?.MAX_CONCURRENT ?? ''}
          placeholder={String(e.concurrency)}
          disabled={disabled}
          onChange={(ev) =>
            config(
              'MAX_CONCURRENT',
              ev.target.value === '' ? '' : Number(ev.target.value),
            )
          }
        />
        <TextField
          fullWidth
          size="small"
          label={t('dpi.timeout')}
          type="number"
          value={value.config?.TIMEOUT ?? ''}
          placeholder={String(e.timeout)}
          disabled={disabled}
          onChange={(ev) =>
            config(
              'TIMEOUT',
              ev.target.value === '' ? '' : Number(ev.target.value),
            )
          }
        />
        <TextField
          select
          fullWidth
          size="small"
          label="IP"
          value={String(value.config?.IP_VERSION ?? '')}
          disabled={disabled}
          onChange={(ev) => config('IP_VERSION', ev.target.value)}
        >
          <MenuItem value="">
            {t('dpi.native_default')} ({String(e.ipVersion)})
          </MenuItem>
          <MenuItem value="ipv4">IPv4</MenuItem>
          <MenuItem value="ipv6">IPv6</MenuItem>
        </TextField>
      </Stack>
      <TextField
        select
        fullWidth
        size="small"
        label={t('dpi.fingerprint')}
        value={value.fingerprint ?? ''}
        disabled={disabled}
        onChange={(ev) =>
          change({ ...value, fingerprint: ev.target.value || null })
        }
      >
        <MenuItem value="">{t('dpi.native_default')}</MenuItem>
        {metadata.fingerprints.map((p) => (
          <MenuItem key={p} value={p}>
            {p}
          </MenuItem>
        ))}
      </TextField>
      <TextField
        fullWidth
        size="small"
        label="Proxy URL (SOCKS5 / HTTP)"
        type="password"
        autoComplete="off"
        value={value.proxy ?? ''}
        disabled={disabled}
        helperText={t('dpi.proxy_help')}
        onChange={(ev) => change({ ...value, proxy: ev.target.value || null })}
      />
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
        <TextField
          fullWidth
          size="small"
          type="number"
          label={t('dpi.total_budget')}
          value={value.limits?.total_seconds ?? 600}
          disabled={disabled}
          onChange={(ev) =>
            change({
              ...value,
              limits: {
                ...value.limits,
                total_seconds: Number(ev.target.value),
              },
            })
          }
        />
        <TextField
          fullWidth
          size="small"
          type="number"
          label={t('dpi.group_budget')}
          value={value.limits?.group_seconds ?? 180}
          disabled={disabled}
          onChange={(ev) =>
            change({
              ...value,
              limits: {
                ...value.limits,
                group_seconds: Number(ev.target.value),
              },
            })
          }
        />
      </Stack>
      <Typography variant="body2">
        {t('dpi.coverage')}: DNS {e.coverage.dns} · {t('dpi.domains')}{' '}
        {e.coverage.domains} · TCP {e.coverage.tcp} · SNI {e.coverage.sni} ·
        Burst {e.coverage.burst_domains}
      </Typography>
      <Accordion disableGutters>
        <AccordionSummary>{t('dpi.advanced')}</AccordionSummary>
        <AccordionDetails>
          <Stack spacing={1}>
            <Alert severity="info">{t('dpi.advanced_help')}</Alert>
            <Typography variant="caption">
              config: {metadata.config_keys.join(', ')}
            </Typography>
            <TextField
              multiline
              minRows={10}
              maxRows={25}
              fullWidth
              label={t('dpi.settings_json')}
              disabled={disabled}
              value={draft ?? JSON.stringify(value, null, 2)}
              error={invalid}
              helperText={
                invalid
                  ? `${t('dpi.invalid_options')}${invalidField ? `: ${invalidField}` : ''}`
                  : undefined
              }
              onChange={(ev) => {
                const text = ev.target.value;
                setDraft(text);
                try {
                  onChange(parseDpiOptions(text));
                  setInvalid(false);
                  setInvalidField(undefined);
                  onInvalid(false);
                } catch (error) {
                  const field =
                    error instanceof Error
                      ? /^invalid_options:([a-zA-Z0-9_.]{1,80})$/.exec(
                          error.message,
                        )?.[1]
                      : undefined;
                  setInvalidField(field);
                  setInvalid(true);
                  onInvalid(true);
                }
              }}
              slotProps={{
                input: { sx: { fontFamily: 'monospace', fontSize: 12 } },
              }}
            />
            <Button
              disabled={disabled}
              onClick={() => {
                const targets: Record<string, unknown[]> = {};
                for (const [key, file] of Object.entries({
                  domains: 'domains.txt',
                  tcp: 'tcp16.json',
                  sni: 'whitelist_sni.txt',
                  burst_domains: 'burst-domains.txt',
                  quic_unsupported: 'quic_unsupported.txt',
                }))
                  targets[key] =
                    key === 'tcp'
                      ? JSON.parse(metadata.files[file])
                      : metadata.files[file]
                          .split(/\r?\n/)
                          .filter((v) => v.trim() && !v.trim().startsWith('#'));
                change({
                  ...value,
                  config: { ...metadata.config, ...value.config },
                  targets: { ...targets, ...value.targets },
                  burst: {
                    connections: 10,
                    timeout: 8,
                    gap: 20,
                    profiles:
                      'rustls,chrome146,chrome123,chrome116,firefox147,safari260,tor145',
                    tls: '1.3+1.2',
                    alpn: 'h2',
                    ...value.burst,
                  },
                });
              }}
            >
              {t('dpi.edit_stock')}
            </Button>
            <Typography variant="body2">{t('dpi.burst_help')}</Typography>
          </Stack>
        </AccordionDetails>
      </Accordion>
      <Button disabled={disabled} onClick={() => change({})}>
        {t('dpi.reset_native')}
      </Button>
    </Stack>
  );
};
