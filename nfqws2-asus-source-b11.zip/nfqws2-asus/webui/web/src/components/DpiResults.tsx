import { useEffect, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Stack,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Typography,
} from '@mui/material';

import type { DpiFile, DpiNativeFile } from '@/api/dpiClient';
import { presentDpiNative } from '@/api/dpiPresentation';
import { saveSupportReport } from '@/api/supportReport';

import { useTranslation } from '@/hooks/useTranslation';

export const DpiResults = ({ file }: { file: DpiFile | DpiNativeFile }) => {
  const { t, langcode } = useTranslation();
  const [text, setText] = useState('');
  const [error, setError] = useState(false);
  const [tab, setTab] = useState(0);
  useEffect(() => {
    let alive = true;
    void file.blob.text().then((v) => {
      if (alive) {
        setText(v);
        setTab(0);
      }
    });
    return () => {
      alive = false;
    };
  }, [file]);
  let value: Record<string, unknown> = {};
  try {
    value = JSON.parse(text);
  } catch {
    /* Blob loads asynchronously. */
  }
  const native = value.type === 'nfqws2_dpi_native';
  const language = langcode;
  const tables = presentDpiNative(value, language);
  const labels = [
    t('dpi.group0'),
    t('dpi.group1'),
    t('dpi.group2'),
    t('dpi.group3'),
    t('dpi.group4'),
    t('dpi.group5'),
    t('dpi.group6'),
  ];
  const pre = (content: string) => (
    <Box
      component="pre"
      sx={{
        m: 0,
        p: 1,
        whiteSpace: 'pre-wrap',
        overflowWrap: 'anywhere',
        maxHeight: 480,
        overflow: 'auto',
        bgcolor: 'action.hover',
        fontSize: 12,
      }}
    >
      {content}
    </Box>
  );
  return (
    <Stack spacing={1}>
      <Typography variant="body2">{file.filename}</Typography>
      {!file.complete && <Alert severity="info">{t('dpi.partial')}</Alert>}
      {native ? (
        <>
          <Alert severity="info">{t('dpi.local_private')}</Alert>
          {value.messages_truncated === true && (
            <Alert severity="warning">{t('dpi.messages_truncated')}</Alert>
          )}
          <Typography variant="body2">
            {t('dpi.coverage')}: {JSON.stringify(value.coverage)}
          </Typography>
          <Tabs
            value={tab}
            onChange={(_, v: number) => setTab(v)}
            variant="scrollable"
          >
            <Tab label={t('dpi.tables')} />
            <Tab label={t('dpi.full_json')} />
            <Tab label={t('dpi.messages')} />
          </Tabs>
          {tab === 0 && (
            <Stack spacing={2}>
              <Typography variant="body2">{t('dpi.legend')}</Typography>
              {tables.map((table, i) => (
                <Stack key={i} spacing={1}>
                  <Typography variant="subtitle2">
                    {table.group}. {labels[table.group]}
                  </Typography>
                  {table.note && (
                    <Typography variant="body2">{table.note}</Typography>
                  )}
                  <TableContainer
                    sx={{
                      maxHeight: 430,
                      border: 1,
                      borderColor: 'divider',
                      borderRadius: 1,
                    }}
                  >
                    <Table size="small" stickyHeader>
                      <TableHead>
                        <TableRow>
                          {table.headers.map((h, j) => (
                            <TableCell key={j}>{h}</TableCell>
                          ))}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {table.rows.map((row, j) => (
                          <TableRow key={j}>
                            {row.map((c, k) => (
                              <TableCell
                                key={k}
                                sx={{
                                  color:
                                    c.tone === 'success'
                                      ? 'success.main'
                                      : c.tone === 'warning'
                                        ? 'warning.main'
                                        : undefined,
                                  overflowWrap: 'anywhere',
                                }}
                              >
                                {c.tone === 'success' ? '✓ ' : ''}
                                {c.text}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Stack>
              ))}
            </Stack>
          )}
          {tab === 1 && pre(text)}
          {tab === 2 && pre(JSON.stringify(value.messages, null, 2))}
        </>
      ) : (
        <>
          <Alert severity="info">
            {value.schema_version === 1
              ? t('dpi.legacy_result')
              : t('dpi.analysis_result')}
          </Alert>
          {pre(text)}
        </>
      )}
      {error && (
        <Alert severity="error">{t('report.errors.save_failed')}</Alert>
      )}
      <Button
        onClick={() => {
          setError(false);
          void saveSupportReport(file).catch((e) => {
            if (!(e instanceof DOMException && e.name === 'AbortError'))
              setError(true);
          });
        }}
      >
        {t(native ? 'dpi.save_native' : 'dpi.save')}
      </Button>
    </Stack>
  );
};
