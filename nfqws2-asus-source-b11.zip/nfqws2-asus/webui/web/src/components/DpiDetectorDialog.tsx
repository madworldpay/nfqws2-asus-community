import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  Button,
  Checkbox,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  Link,
  Stack,
  Typography,
} from '@mui/material';

import {
  deleteDpiResult,
  downloadDpiNativeResult,
  downloadDpiResult,
  DpiError,
  dpiPreferences,
  getDpiMetadata,
  getDpiStatus,
  installDpi,
  startDpi,
  stopDpi,
  type DpiFile,
  type DpiMetadata,
  type DpiNativeFile,
  type DpiStatus,
} from '@/api/dpiClient';
import { effectiveDpiSettings, type DpiOptions } from '@/api/dpiOptions';
import { newSupportSubmissionId } from '@/api/supportReport';

import { DpiResults } from '@/components/DpiResults';
import { DpiSettings } from '@/components/DpiSettings';

import { useTranslation } from '@/hooks/useTranslation';

export const DpiDetectorDialog = ({
  csrfToken,
  onClose,
}: {
  csrfToken: string;
  onClose: () => void;
}) => {
  const { t } = useTranslation();
  const [status, setStatus] = useState<DpiStatus>();
  const [tests, setTests] = useState([1, 2]);
  const [consent, setConsent] = useState<number[]>([]);
  const [confirm, setConfirm] = useState<'install' | 'run' | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [commandCopied, setCommandCopied] = useState(false);
  const [file, setFile] = useState<DpiFile | DpiNativeFile>();
  const [metadata, setMetadata] = useState<DpiMetadata>();
  const [options, setOptions] = useState<DpiOptions>({});
  const [invalidSettings, setInvalidSettings] = useState(false);
  const effective = metadata
    ? effectiveDpiSettings(options, metadata)
    : undefined;
  const alive = useRef(true);
  const busy = useRef(false);
  const loading = useRef(false);
  const load = useCallback(async () => {
    if (loading.current) return;
    loading.current = true;
    try {
      const s = await getDpiStatus(csrfToken);
      if (alive.current) {
        setStatus(s);
      }
    } catch {
      if (alive.current) setError(t('dpi.request_failed'));
    } finally {
      loading.current = false;
    }
  }, [csrfToken, t]);
  useEffect(() => {
    alive.current = true;
    void load();
    void Promise.all([
      getDpiMetadata(csrfToken),
      dpiPreferences(csrfToken, 'read'),
    ]).then(
      ([m, o]) => {
        if (alive.current) {
          setMetadata(m);
          setOptions(o as DpiOptions);
        }
      },
      () => {
        if (alive.current) setError(t('dpi.request_failed'));
      },
    );
    const timer = setInterval(() => {
      void load();
    }, 2000);
    return () => {
      alive.current = false;
      clearInterval(timer);
    };
  }, [load, csrfToken, t]);
  const action = async (fn: () => Promise<unknown>) => {
    if (busy.current) return;
    busy.current = true;
    setPending(true);
    setError('');
    try {
      await fn();
      setConfirm(null);
      await load();
    } catch (e) {
      setError(
        e instanceof DpiError && e.code === 'invalid_options'
          ? `${t('dpi.invalid_options')}: ${e.field ?? ''}`
          : t('dpi.request_failed'),
      );
    } finally {
      busy.current = false;
      setPending(false);
    }
  };
  const heavy = tests.filter((g) => g === 5 || g === 6);
  const canRun =
    !!status?.installed.installed &&
    !!status.available.available &&
    !status.active &&
    !pending &&
    !!metadata &&
    !invalidSettings;
  const groupLabels = [
    t('dpi.group0'),
    t('dpi.group1'),
    t('dpi.group2'),
    t('dpi.group3'),
    t('dpi.group4'),
    t('dpi.group5'),
    t('dpi.group6'),
  ];
  return (
    <Dialog open onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>DPI Detector</DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2}>
          <Typography>{t('dpi.purpose')}</Typography>
          <Alert severity="info">{t('dpi.router_origin')}</Alert>
          <Typography variant="body2">
            {status?.version ?? 'v5.0.0-alpha.21'} · {t('dpi.prerelease')} ·{' '}
            {t('dpi.limits')}
          </Typography>
          {error && <Alert severity="error">{error}</Alert>}
          {!status && <CircularProgress size={22} />}
          {status && !status.available.available && (
            <Alert severity="info">
              {t('dpi.unavailable')} ({status.available.code})
            </Alert>
          )}
          {status?.active && (
            <Alert severity="info">
              {t('dpi.active')} ·{' '}
              {status.active.kind === 'install'
                ? t('dpi.install')
                : t(`dpi.state_${status.active.state}`)}
              {status.active.current_group !== null
                ? ` · ${groupLabels[status.active.current_group]}`
                : ''}{' '}
              · {t('dpi.completed')}:{' '}
              {status.active.completed_tests.join(', ') || '—'}
              {' · '}
              {t('dpi.elapsed')}:{' '}
              {Math.max(
                0,
                Math.floor(Date.now() / 1000 - status.active.started_at),
              )}
              {t('dpi.seconds')}
            </Alert>
          )}
          {!status?.installed.installed ? (
            <Stack direction="row" spacing={1} alignItems="center">
              <Button
                variant="contained"
                disabled={
                  !status?.available.available || !!status?.active || pending
                }
                onClick={() => setConfirm('install')}
              >
                {t('dpi.install')}
              </Button>
              <Typography variant="body2">{t('dpi.install_size')}</Typography>
            </Stack>
          ) : (
            <Alert severity="success">
              {t('dpi.installed')} {status.installed.version}
            </Alert>
          )}
          <Alert severity="info">
            <Stack spacing={1} alignItems="flex-start">
              <Typography variant="body2">{t('dpi.entware_hint')}</Typography>
              <Typography component="code" sx={{ userSelect: 'all' }}>
                /opt/bin/nfqws2-dpi
              </Typography>
              <Button
                size="small"
                onClick={async () => {
                  try {
                    const command = '/opt/bin/nfqws2-dpi';
                    if (navigator.clipboard)
                      await navigator.clipboard.writeText(command);
                    else {
                      const input = document.createElement('textarea');
                      input.value = command;
                      document.body.append(input);
                      input.select();
                      const copied = document.execCommand('copy');
                      input.remove();
                      if (!copied) throw new Error('copy_failed');
                    }
                    setCommandCopied(true);
                  } catch {
                    setCommandCopied(false);
                  }
                }}
              >
                {t(commandCopied ? 'dpi.command_copied' : 'dpi.copy_command')}
              </Button>
            </Stack>
          </Alert>
          {metadata && (
            <>
              <DpiSettings
                value={options}
                onChange={setOptions}
                metadata={metadata}
                disabled={pending || !!status?.active}
                onInvalid={setInvalidSettings}
              />
              <Button
                disabled={pending || !!status?.active || invalidSettings}
                onClick={() =>
                  void action(() => dpiPreferences(csrfToken, 'save', options))
                }
              >
                {t('dpi.save_preferences')}
              </Button>
            </>
          )}
          <Stack spacing={0}>
            <Button
              disabled={pending || !!status?.active}
              onClick={() => {
                setTests([1, 2]);
                setConsent([]);
              }}
            >
              {t('dpi.quick')}
            </Button>
            {groupLabels.map((label, g) => (
              <FormControlLabel
                key={g}
                control={
                  <Checkbox
                    checked={tests.includes(g)}
                    disabled={pending || !!status?.active}
                    onChange={(_, checked) => {
                      setTests((v) =>
                        checked
                          ? [...v, g].sort((a, b) => a - b)
                          : v.filter((x) => x !== g),
                      );
                      setConsent([]);
                    }}
                  />
                }
                label={`${g}. ${label}`}
              />
            ))}
          </Stack>
          <Stack direction="row" spacing={1}>
            <Button
              variant="contained"
              disabled={!canRun || !tests.length}
              onClick={() => {
                setConsent([]);
                setConfirm('run');
              }}
            >
              {t('dpi.start')}
            </Button>
            <Button
              disabled={pending || !status?.active}
              onClick={() =>
                void action(() => stopDpi(csrfToken, status!.active!.id))
              }
            >
              {t('dpi.stop')}
            </Button>
          </Stack>
          {status?.history.map((job) => (
            <Stack
              key={job.id}
              direction="row"
              spacing={1}
              alignItems="center"
              flexWrap="wrap"
            >
              <Typography variant="body2">
                {job.kind === 'install'
                  ? t('dpi.install')
                  : job.tests.join(', ')}{' '}
                · {t(`dpi.state_${job.state}`)}
                {job.code ? ` (${job.code})` : ''}
              </Typography>
              {(job.completed_tests.length > 0 || job.native_available) && (
                <>
                  <Button
                    disabled={pending}
                    onClick={() =>
                      void action(async () => {
                        try {
                          setFile(
                            await downloadDpiNativeResult(csrfToken, job.id),
                          );
                        } catch {
                          setFile(await downloadDpiResult(csrfToken, job.id));
                        }
                      })
                    }
                  >
                    {t('dpi.results')}
                  </Button>
                  <Button
                    disabled={pending}
                    onClick={() =>
                      void action(async () => {
                        await deleteDpiResult(csrfToken, job.id);
                        if (file?.jobId === job.id) setFile(undefined);
                      })
                    }
                  >
                    {t('dpi.delete')}
                  </Button>
                </>
              )}
            </Stack>
          ))}
          {file && <DpiResults file={file} />}
          <Link
            href="https://github.com/Runnin4ik/dpi-detector"
            target="_blank"
            rel="noopener noreferrer"
          >
            DPI Detector · GitHub
          </Link>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.close')}</Button>
      </DialogActions>
      <Dialog
        open={confirm !== null}
        onClose={() => {
          if (!pending) setConfirm(null);
        }}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          {t(confirm === 'install' ? 'dpi.install' : 'dpi.start')}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2}>
            <Typography>
              {t(
                confirm === 'install'
                  ? 'dpi.install_confirm'
                  : 'dpi.run_confirm',
              )}
            </Typography>
            {confirm === 'run' && effective && (
              <Alert severity="info">
                {t('dpi.coverage')}: DNS {effective.coverage.dns},{' '}
                {t('dpi.domains')} {effective.coverage.domains}, TCP{' '}
                {effective.coverage.tcp}, SNI {effective.coverage.sni}.{' '}
                {effective.profile.toUpperCase()} · IP{' '}
                {String(effective.ipVersion)} · {t('dpi.concurrency')}{' '}
                {String(effective.concurrency)} · TIMEOUT{' '}
                {String(effective.timeout)} s · {t('dpi.total_budget')}:{' '}
                {effective.limits.total_seconds} s · {t('dpi.group_budget')}:{' '}
                {effective.limits.group_seconds} s.{' '}
                {t('dpi.effective_settings')}:{' '}
                {JSON.stringify({
                  ...options,
                  proxy: options.proxy ? 'configured' : null,
                })}
              </Alert>
            )}
            {confirm === 'run' &&
              heavy.map((g) => (
                <FormControlLabel
                  key={g}
                  control={
                    <Checkbox
                      checked={consent.includes(g)}
                      onChange={(_, checked) =>
                        setConsent((v) =>
                          checked ? [...v, g].sort() : v.filter((x) => x !== g),
                        )
                      }
                    />
                  }
                  label={t(g === 5 ? 'dpi.heavy5' : 'dpi.heavy6')}
                />
              ))}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button disabled={pending} onClick={() => setConfirm(null)}>
            {t('common.cancel')}
          </Button>
          <Button
            variant="contained"
            disabled={
              pending ||
              (confirm === 'run' && heavy.join('') !== consent.join(''))
            }
            onClick={() =>
              void action(() =>
                confirm === 'install'
                  ? installDpi(csrfToken, newSupportSubmissionId())
                  : startDpi(
                      csrfToken,
                      newSupportSubmissionId(),
                      tests,
                      consent,
                      options,
                    ),
              )
            }
          >
            {pending ? <CircularProgress size={18} /> : t('ark.confirm')}
          </Button>
        </DialogActions>
      </Dialog>
    </Dialog>
  );
};
