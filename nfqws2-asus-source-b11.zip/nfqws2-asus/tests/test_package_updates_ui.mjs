import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';

const source = new URL('../webui/web/src/api/packageUpdates.ts', import.meta.url);
assert.ok(existsSync(source), 'package update client is missing');
const api = await import(source.href);
const candidate = {
  revision: 'a'.repeat(64), package_version: '1.3.1-asus6+b12',
  core_version: '1.3.1-asus6', web_version: '0.1.4', build: 12,
  notes: 'A real signed Build.',
  package: { family: 'aarch64-3.10', filename: 'nfqws2-asus_1.3.1-asus6+b12_aarch64-3.10.ipk', size: 1000, sha256: 'b'.repeat(64) },
};
const available = { state: 'available', candidate, code: null, installed_version: '1.3.1-asus6+b11' };
assert.deepEqual(api.packageUpdateBadges(available, '1.3.1-asus6+b11', '0.1.4', '11'), { core: false, web: false, build: true });
assert.deepEqual(api.packageUpdateBadges({ ...available, candidate: { ...candidate, core_version: '1.3.2-asus7', web_version: '0.1.5' } }, '1.3.1-asus6+b11', '0.1.4', '11'), { core: true, web: true, build: true });
assert.deepEqual(api.packageUpdateBadges({ ...available, state: 'failed' }, '1.3.1-asus6+b11', '0.1.4', '11'), { core: false, web: false, build: false });
assert.match(api.packageUpdateRequestId(), /^[a-f0-9]{32}$/);
assert.notEqual(api.packageUpdateRequestId(), api.packageUpdateRequestId());

const operation = { id: 'c'.repeat(32), revision: candidate.revision, state: 'applying', phase: 'queued', package_version: candidate.package_version, code: null, service_intent: null };
const calls = [];
globalThis.fetch = async (url, options) => {
  calls.push([url, options]);
  const cmd = options.body.get('cmd');
  return Response.json(cmd === 'packageupdatecheck' ? available : cmd === 'packageupdatestatus' ? { check: available, operation } : operation);
};
assert.deepEqual(await api.checkPackageUpdate('csrf', true), available);
assert.equal(calls[0][0], '/index.php');assert.equal(calls[0][1].credentials, 'same-origin');assert.equal(calls[0][1].redirect, 'error');
assert.equal(calls[0][1].body.get('force'), '1');
await api.preparePackageUpdate('csrf', candidate.revision, 'd'.repeat(32));
await api.applyPackageUpdate('csrf', operation.id, candidate.revision, 'e'.repeat(32));
assert.equal(calls.at(-1)[1].body.get('consent'), 'install');
assert.equal(calls.at(-1)[1].body.get('csrf_token'), 'csrf');
assert.equal((await api.getPackageUpdate('csrf', operation.id)).id, operation.id);
assert.equal((await api.getPackageUpdateOverview('csrf')).operation.state, 'applying');

globalThis.fetch = async () => Response.json({ error: 'busy' }, { status: 409 });
await assert.rejects(api.checkPackageUpdate('csrf', false), error => error.code === 'busy');
globalThis.fetch = async () => Response.json({ ...available, token: 'PRIVATE_CANARY' });
await assert.rejects(api.checkPackageUpdate('csrf', false), error => error.code === 'invalid_response');
globalThis.fetch = async () => Response.json({ state: 'current', candidate: null, code: null, installed_version: null });
assert.equal((await api.checkPackageUpdate('csrf', false)).state, 'current');
console.log('PASS: component-specific update badges, HTTP-LAN request IDs, consent/CSRF, strict responses and status-only recovery');
