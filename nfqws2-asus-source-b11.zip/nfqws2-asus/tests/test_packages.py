"""Inspect the actual installable artifacts, including their maintainer scripts."""
import io
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def read_ipk(path):
    result = {}
    with tarfile.open(path) as outer:
        for section in ['control', 'data']:
            with tarfile.open(fileobj=io.BytesIO(outer.extractfile(section+'.tar.gz').read())) as inner:
                result[section] = {m.name.removeprefix('./'): (m, inner.extractfile(m).read())
                                   for m in inner if m.isfile()}
    return result


class PackageTests(unittest.TestCase):
    def test_update_launcher_is_static_matching_abi_and_bound_to_source(self):
        meta=json.loads((ROOT/'asus/update/bin/launchers.json').read_text())
        self.assertEqual(meta['source_sha256'],hashlib.sha256((ROOT/'asus/update/opkg-launch.c').read_bytes()).hexdigest())
        for family,package in self.packages().items():
            data=package['data'];path='opt/libexec/nfqws2-asus/update-launch'
            self.assertIn(path,list(data));actual=data[path][1];key='aarch64' if family=='aarch64-3.10' else 'armv7'
            self.assertEqual(hashlib.sha256(actual).hexdigest(),meta['outputs'][key]['sha256'])
            self.assertEqual(actual,(ROOT/f'asus/update/bin/{key}-opkg-launch').read_bytes())
            self.assertEqual(data[path][0].mode,0o755);self.assertEqual(actual[:4],b'\x7fELF')
            self.assertEqual(int.from_bytes(actual[18:20],'little'),183 if key=='aarch64' else 40)

    def test_package_update_trust_material_is_public_and_matches_source(self):
        for package in self.packages().values():
            data = package['data']
            for source, path in [
                ('updates/package-manifest.schema.json', 'opt/share/nfqws2-asus/package-manifest.schema.json'),
                ('updates/trusted-release-key.pem', 'opt/share/nfqws2-asus/update-release-key.pem'),
                ('webui/web/public/update-manifest.php', 'opt/share/nfqws-asus-web/update-manifest.php'),
            ]:
                self.assertIn(path, list(data))
                self.assertEqual(data[path][1], (ROOT/source).read_bytes())
                self.assertEqual(data[path][0].mode, 0o644)
            key = data['opt/share/nfqws2-asus/update-release-key.pem'][1]
            self.assertTrue(key.startswith(b'-----BEGIN PUBLIC KEY-----'))
            self.assertNotIn(b'PRIVATE KEY', key)

    def test_diagnostic_manifest_matches_actual_engine_and_strategy_payload(self):
        for package in self.packages().values():
            data = package['data']
            manifest_path = 'opt/share/nfqws2-asus/report-baseline.json'
            self.assertIn(manifest_path, list(data))
            manifest = json.loads(data[manifest_path][1])
            self.assertEqual(manifest['schema_version'], 1)
            self.assertEqual(manifest['engine']['sha256'], hashlib.sha256(data['opt/usr/bin/nfqws2'][1]).hexdigest())
            for name, meta in manifest['resources'].items():
                kind, name = name.split('/', 1)
                path = 'opt/etc/nfqws2/' + ('blobs' if kind == 'blob' else 'lua') + '/' + name
                actual = data[path][1]
                self.assertEqual(meta['bytes'], len(actual))
                self.assertEqual(meta['sha256'], hashlib.sha256(actual).hexdigest())
            for name in ['support-report.php','support-report-io.php','support-report-values.php',
                         'support-report-platform.php','support-report-network.php']:
                self.assertIn('opt/share/nfqws-asus-web/' + name, list(data))
                self.assertEqual(data['opt/share/nfqws-asus-web/' + name][1],
                                 (ROOT/'webui/web/public'/name).read_bytes(),
                                 name+' must be rebuilt from current public source')

    def packages(self):
        files = sorted(Path(os.environ.get('PACKAGES_DIR', ROOT/'dist')).glob('*.ipk'))
        self.assertEqual(len(files), 2, 'Build both IPKs first: python3 asus/build.py')
        self.assertTrue(all(p.name.startswith('nfqws2-asus_') for p in files), 'each architecture must include core and web')
        return {p.name.rsplit('_',1)[1].removesuffix('.ipk'): read_ipk(p) for p in files}

    def test_core_is_complete_and_has_no_keenetic_runtime(self):
        p = self.packages()['aarch64-3.10']
        data = p['data']
        for path in ['opt/usr/bin/nfqws2', 'opt/etc/init.d/S51nfqws2',
                     'opt/libexec/nfqws2-asus/busybox', 'opt/lib/nfqws2-asus/bin/stat',
                     'opt/lib/nfqws2-asus/platform.sh', 'opt/lib/nfqws2-asus/lifecycle.sh',
                     'opt/lib/nfqws2-asus/args.sh', 'opt/etc/nfqws2/nfqws2.conf.notactive',
                     'opt/etc/nfqws2/lua/zapret-lib.lua', 'opt/etc/nfqws2/lua/zapret-antidpi.lua',
                     'opt/etc/nfqws2/lua/zapret-auto.lua',
                     'opt/etc/nfqws2/blobs/quic_initial.bin']:
            self.assertIn(path, list(data))
        binary = data['opt/usr/bin/nfqws2'][1]
        self.assertEqual(binary[:5], b'\x7fELF\x02')
        self.assertEqual(int.from_bytes(binary[18:20], 'little'), 183, 'ARM64 ELF required')
        self.assertFalse(any('/ndm/' in name for name in data))
        for path, (_, content) in data.items():
            if path.startswith(('opt/lib/nfqws2-asus/', 'opt/etc/init.d/')):
                self.assertNotIn(b'ndmc', content, path)
        control = p['control']['control'][1].decode()
        self.assertIn('Architecture: aarch64-3.10', control)
        depends = next(line for line in control.splitlines() if line.startswith('Depends:'))
        self.assertNotIn('busybox', depends, 'A fresh Entware busybox preinst needs its own missing binary')
        self.assertIn('Conflicts: nfqws2-keenetic, nfqws-keenetic, tpws-keenetic', control)
        self.assertIn('opt/etc/nfqws2/lists/auto.list.notactive', data)
        self.assertNotIn('opt/etc/nfqws2/nfqws2.conf', data)
        self.assertNotIn('opt/etc/nfqws2/lists/auto.list', data)

    def test_web_is_complete_and_does_not_install_global_server(self):
        self.assertIn('armv7', list(self.packages()), 'one ARMv7 package must serve both Entware ABIs')
        p = self.packages()['armv7']
        data = p['data']
        for path in ['opt/share/nfqws-asus-web/index.html', 'opt/share/nfqws-asus-web/index.php',
                     'opt/share/nfqws-asus-web/asus.php', 'opt/share/nfqws-asus-web/ark.php', 'opt/etc/init.d/S81nfqws-asus-web',
                     'opt/etc/nfqws-asus-web/auth.json',
                     'opt/libexec/nfqws-asus-web/lighttpd',
                     'opt/lib/nfqws-asus-web/lighttpd/armv7-2.6/mod_cgi.so',
                     'opt/lib/nfqws-asus-web/lighttpd/armv7-3.2/mod_cgi.so']:
            self.assertIn(path, list(data))
        self.assertFalse(any('/etc/lighttpd/' in name or 'S80lighttpd' in name for name in data))
        control = p['control']['control'][1].decode()
        for dependency in ['php8-cgi', 'php8-mod-session', 'libpcre2', 'libnettle']:
            self.assertIn(dependency, control)
        self.assertNotIn('nfqws2-asus (', control)
        self.assertIn('Replaces: nfqws-asus-web\n', control)
        self.assertNotIn('php8-mod-curl', control)
        self.assertNotIn(b'opkg upgrade', data['opt/share/nfqws-asus-web/index.php'][1])
        self.assertEqual(data['opt/etc/nfqws-asus-web/auth.json'][0].mode, 0o600)
        self.assertIn(b'/opt/etc/nfqws-asus-web/auth.json\n', p['control']['conffiles'][1])

    def test_enabled_ipv6_adds_ipv6_socket_binding_for_multiple_wans(self):
        args = self.packages()['aarch64-3.10']['data']['opt/lib/nfqws2-asus/args.sh'][1].decode()
        r = subprocess.run(['sh', '-c', args + '''
        USER=nobody; NFQUEUE_NUM=300; ISP_INTERFACE='eth0 eth1'
        IPV6_ENABLED=1; LOG_LEVEL=0; NFQWS_ARGS='--filter-tcp=443'
        _startup_args
        '''], text=True, capture_output=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn('--bind-fix4', r.stdout)
        self.assertIn('--bind-fix6', r.stdout)
        r = subprocess.run(['sh', '-c', args + '''
        USER=nobody; NFQUEUE_NUM=300; ISP_INTERFACE='eth0 eth1'
        IPV6_ENABLED=0; LOG_LEVEL=0; NFQWS_ARGS='--filter-tcp=443'
        _startup_args
        '''], text=True, capture_output=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertNotIn('--bind-fix6', r.stdout)

    def scripts(self, action, core=0, web=0, no_start=False):
        p=self.packages()['aarch64-3.10']
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); init=root/'opt/etc/init.d'; init.mkdir(parents=True)
            for name,code in [('S51nfqws2',core),('S81nfqws-asus-web',web)]:
                f=init/name; f.write_text(f'#!/bin/sh\necho "{name} $1" >> "{tmp}/calls"\nexit {code}\n'); f.chmod(0o755)
            script=p['control'][action][1].decode().replace('/opt/', tmp+'/opt/')
            r=subprocess.run(['sh','-c',script],text=True,capture_output=True,
                             env={**os.environ,'NFQWS_ASUS_NO_START':str(int(no_start))})
            calls=(root/'calls').read_text().splitlines() if (root/'calls').exists() else []
            return r,calls

    def test_postinst_starts_web_before_core_and_propagates_failures(self):
        for code in [0,7]:
            r,calls=self.scripts('postinst',core=code)
            self.assertEqual(r.returncode,code,r.stderr)
            self.assertEqual(calls,['S81nfqws-asus-web start','S51nfqws2 start'])
        r,calls=self.scripts('postinst',web=9)
        self.assertEqual(r.returncode,9,r.stderr)
        self.assertEqual(calls,['S81nfqws-asus-web start'])

    def test_prerm_keeps_web_available_when_core_cannot_stop(self):
        r,calls=self.scripts('prerm',core=7)
        self.assertEqual(r.returncode,7,r.stderr)
        self.assertEqual(calls,['S51nfqws2 stop'])
        r,calls=self.scripts('prerm')
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(calls,['S51nfqws2 stop','S81nfqws-asus-web stop'])

    def test_archive_ownership_and_script_modes(self):
        for p in self.packages().values():
            for section in p.values():
                for name, (info, _) in section.items():
                    self.assertEqual((info.uid, info.gid), (0, 0), name)
                    if name in ['preinst', 'postinst', 'prerm', 'postrm'] or '/init.d/' in name:
                        self.assertEqual(info.mode, 0o755, name)


    def test_diagnostic_install_starts_web_and_leaves_core_stopped(self):
        r,calls=self.scripts('postinst',no_start=True)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(calls,['S81nfqws-asus-web start'])

    def test_all_native_files_match_package_architecture(self):
        for arch,p in self.packages().items():
            cls,machine = (1,40) if arch=='armv7' else (2,183)
            names = ['opt/usr/bin/nfqws2']
            if arch == 'armv7':
                for abi in ['armv7-2.6', 'armv7-3.2']:
                    names.extend([f'opt/libexec/nfqws2-asus/{abi}/busybox',
                                  f'opt/libexec/nfqws-asus-web/{abi}/lighttpd',
                                  f'opt/lib/nfqws-asus-web/lighttpd/{abi}/mod_cgi.so'])
                for shim in ['opt/libexec/nfqws2-asus/busybox', 'opt/libexec/nfqws-asus-web/lighttpd']:
                    self.assertEqual(p['data'][shim][1][:10], b'#!/bin/sh\n', 'fresh legacy install must bootstrap with the stock shell')
            else:
                names.extend(['opt/libexec/nfqws2-asus/busybox',
                              'opt/libexec/nfqws-asus-web/lighttpd', 'opt/lib/nfqws-asus-web/lighttpd/mod_cgi.so'])
            for name in names:
                binary=p['data'][name][1]
                self.assertEqual(binary[:5],b'\x7fELF'+bytes([cls]),name)
                self.assertEqual(int.from_bytes(binary[18:20],'little'),machine,name)
            self.assertIn(f"Architecture: {'all' if arch == 'armv7' else arch}\n",p['control']['control'][1].decode())
            self.assertIn('opt/etc/init.d/S51nfqws2',p['data'])
            self.assertIn('opt/etc/init.d/S81nfqws-asus-web',p['data'])
            self.assertNotIn('opt/etc/nfqws-asus-web/ark-backup.json',p['data'])


if __name__ == '__main__': unittest.main()
