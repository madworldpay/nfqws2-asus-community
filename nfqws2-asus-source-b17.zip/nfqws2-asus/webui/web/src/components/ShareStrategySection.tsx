import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Button,
  Checkbox,
  FormControlLabel,
  Link,
  Stack,
  TextField,
  Typography,
} from '@mui/material';

import {
  getShareLocation,
  getStrategyDraft,
  type ShareLocation,
  type StrategyContext,
  type StrategyDraft,
  type StrategyKey,
} from '@/api/shareClient';

import { useTranslation } from '@/hooks/useTranslation';

export type ShareStrategyForm = {
  draft?: StrategyDraft;
  selected: StrategyKey[];
  full: boolean;
  context: StrategyContext;
  locationEdited: boolean;
};
export const ShareStrategySection = ({
  csrfToken,
  value,
  disabled,
  onChange,
  onLocation,
  onError,
}: {
  csrfToken: string;
  value: ShareStrategyForm;
  disabled: boolean;
  onChange: (update: (old: ShareStrategyForm) => ShareStrategyForm) => void;
  onLocation: (v: ShareLocation) => void;
  onError: (e: unknown) => void;
}) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [geoUnavailable, setGeoUnavailable] = useState(false);
  const generation = useRef({ value: 0 });
  useEffect(() => {
    let active = true;
    const seq = ++generation.current.value;
    void getStrategyDraft(csrfToken).then(
      (draft) => {
        if (active && seq === generation.current.value)
          onChange((old) => ({
            ...old,
            draft,
            selected: old.selected.filter((k) =>
              draft.blocks.some((b) => b.key === k),
            ),
          }));
      },
      (e) => {
        if (active) onError(e);
      },
    );
    void getShareLocation(csrfToken).then(
      (v) => {
        if (active) {
          setGeoUnavailable(!v.available);
          onLocation(v);
        }
      },
      () => {
        if (active) setGeoUnavailable(true);
      },
    );
    const generationState = generation.current;
    return () => {
      active = false;
      generationState.value++;
    };
  }, [csrfToken, onChange, onError, onLocation]);
  const refresh = async () => {
    if (loading || disabled) return;
    setLoading(true);
    const seq = ++generation.current.value;
    onChange((old) => ({ ...old }));
    try {
      const draft = await getStrategyDraft(csrfToken);
      if (seq !== generation.current.value) return;
      onChange((old) => ({
        ...old,
        draft,
        selected: old.selected.filter((k) =>
          draft.blocks.some((b) => b.key === k),
        ),
      }));
    } catch (e) {
      if (seq === generation.current.value) onError(e);
    } finally {
      if (seq === generation.current.value) setLoading(false);
    }
  };
  return (
    <Stack spacing={1.5}>
      <Typography variant="body2">{t('share.strategy_hint')}</Typography>
      <TextField
        size="small"
        required
        disabled={disabled}
        label={t('share.purpose')}
        value={value.context.purpose}
        slotProps={{ htmlInput: { maxLength: 120 } }}
        onChange={(e) =>
          onChange((old) => ({
            ...old,
            context: { ...old.context, purpose: e.target.value },
          }))
        }
      />
      <TextField
        size="small"
        required
        disabled={disabled}
        label={t('share.operator')}
        value={value.context.operator}
        helperText={t('share.operator_required')}
        slotProps={{ htmlInput: { maxLength: 120 } }}
        onChange={(e) =>
          onChange((old) => ({
            ...old,
            context: { ...old.context, operator: e.target.value },
          }))
        }
      />
      <FormControlLabel
        control={
          <Checkbox
            checked={value.full}
            disabled={disabled}
            onChange={(_, full) => onChange((old) => ({ ...old, full }))}
          />
        }
        label={t('share.full_config')}
      />
      {value.full ? (
        <TextField
          multiline
          minRows={7}
          maxRows={16}
          disabled={disabled}
          label={t('share.config_copy')}
          value={value.draft?.config ?? ''}
          onChange={(e) =>
            onChange((old) => ({
              ...old,
              draft: {
                blocks: old.draft?.blocks ?? [],
                config: e.target.value,
              },
            }))
          }
        />
      ) : (
        value.draft?.blocks.map((block) => (
          <Stack key={block.key} spacing={1}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={value.selected.includes(block.key)}
                  disabled={disabled}
                  onChange={(_, checked) =>
                    onChange((old) => ({
                      ...old,
                      selected: checked
                        ? [...old.selected, block.key]
                        : old.selected.filter((k) => k !== block.key),
                    }))
                  }
                />
              }
              label={`${block.key} · ${t(`share.blocks.${block.key}`)}`}
            />
            {value.selected.includes(block.key) && (
              <TextField
                multiline
                minRows={3}
                maxRows={10}
                disabled={disabled}
                label={block.key}
                value={block.value}
                onChange={(e) =>
                  onChange((old) => ({
                    ...old,
                    draft: old.draft
                      ? {
                          ...old.draft,
                          blocks: old.draft.blocks.map((b) =>
                            b.key === block.key
                              ? { ...b, value: e.target.value }
                              : b,
                          ),
                        }
                      : undefined,
                  }))
                }
              />
            )}
          </Stack>
        ))
      )}
      {!value.draft && (
        <Typography variant="body2">{t('share.reading_config')}</Typography>
      )}
      {value.draft && !value.full && !value.draft.blocks.length && (
        <Alert severity="info">{t('share.no_blocks')}</Alert>
      )}
      <TextField
        size="small"
        disabled={disabled}
        label={t('share.region')}
        value={value.context.region}
        slotProps={{ htmlInput: { maxLength: 120 } }}
        onChange={(e) =>
          onChange((old) => ({
            ...old,
            locationEdited: true,
            context: { ...old.context, region: e.target.value },
          }))
        }
      />
      <FormControlLabel
        control={
          <Checkbox
            checked={value.context.share_location}
            disabled={disabled}
            onChange={(_, share_location) =>
              onChange((old) => ({
                ...old,
                context: { ...old.context, share_location },
              }))
            }
          />
        }
        label={t('share.include_location')}
      />
      <Typography variant="caption">
        {t('share.location_hint')}{' '}
        <Link href="https://db-ip.com" target="_blank" rel="noreferrer">
          IP Geolocation by DB-IP
        </Link>
      </Typography>
      {geoUnavailable && (
        <Typography variant="caption">
          {t('share.location_unavailable')}
        </Typography>
      )}
      <TextField
        multiline
        minRows={2}
        maxRows={6}
        disabled={disabled}
        label={t('share.comment')}
        value={value.context.comment}
        slotProps={{ htmlInput: { maxLength: 2000 } }}
        onChange={(e) =>
          onChange((old) => ({
            ...old,
            context: { ...old.context, comment: e.target.value },
          }))
        }
      />
      <Button onClick={() => void refresh()} disabled={disabled || loading}>
        {t('share.refresh_config')}
      </Button>
    </Stack>
  );
};
