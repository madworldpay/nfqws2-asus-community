export type DpiState =
  | 'queued'
  | 'running'
  | 'completed'
  | 'partial'
  | 'cancelled'
  | 'timed_out'
  | 'failed'
  | 'interrupted';
export type DpiJob = {
  id: string;
  kind: 'install' | 'run';
  state: DpiState;
  started_at: number;
  finished_at: number | null;
  code: string | null;
  tests: number[];
  completed_tests: number[];
  current_group: number | null;
};
export type DpiStatus = {
  available: { available: boolean; code: string };
  installed: { installed: boolean; version: string | null };
  version: string;
  default_tests: number[];
  active: DpiJob | null;
  history: DpiJob[];
};
export type DpiFile = {
  blob: Blob;
  filename: string;
  jobId: string;
  startedAt: string;
  complete: boolean;
};
export class DpiError extends Error {
  code: string;
  constructor(code: string) {
    super(code);
    this.code = code;
  }
}
const JOB = /^[a-f0-9]{32}$/;
const UUID =
  /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
async function request(
  csrf: string,
  cmd: string,
  params: Record<string, string> = {},
  result = false,
): Promise<{ value: unknown; text: string; response: Response }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch('/index.php', {
      method: 'POST',
      credentials: 'same-origin',
      body: new URLSearchParams({ cmd, csrf_token: csrf, ...params }),
      signal: controller.signal,
    });
    if (
      !/^application\/json(?:;|$)/i.test(
        response.headers.get('Content-Type') ?? '',
      )
    )
      throw new DpiError('invalid_response');
    const max = result ? 262144 : 16384;
    if (Number(response.headers.get('Content-Length') ?? 0) > max)
      throw new DpiError('invalid_response');
    const reader = response.body?.getReader();
    if (!reader) throw new DpiError('invalid_response');
    let size = 0;
    const chunks: Uint8Array<ArrayBuffer>[] = [];
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > max) throw new DpiError('invalid_response');
        chunks.push(new Uint8Array(value));
      }
    } finally {
      await reader.cancel().catch(() => {});
      reader.releaseLock();
    }
    const text = new TextDecoder('utf-8', { fatal: true }).decode(
      await new Blob(chunks).arrayBuffer(),
    );
    const value: unknown = JSON.parse(text);
    if (!response.ok) {
      const error =
        typeof value === 'object' && value !== null && 'error' in value
          ? String(value.error)
          : 'request_failed';
      throw new DpiError(
        response.status === 401
          ? 'unauthorized'
          : response.status === 403
            ? 'forbidden'
            : /^[a-z_]{1,40}$/.test(error)
              ? error
              : 'request_failed',
      );
    }
    return { value, text, response };
  } catch (e) {
    if (e instanceof DpiError) throw e;
    throw new DpiError(
      controller.signal.aborted ? 'timeout' : 'request_failed',
    );
  } finally {
    clearTimeout(timer);
  }
}
function id(id: string) {
  if (!JOB.test(id)) throw new DpiError('invalid_request');
  return id;
}
function req(id: string) {
  if (!UUID.test(id)) throw new DpiError('invalid_request');
  return id;
}
function job(value: unknown): DpiJob {
  const j = value as DpiJob;
  if (
    !j ||
    !JOB.test(j.id) ||
    ![
      'queued',
      'running',
      'completed',
      'partial',
      'cancelled',
      'timed_out',
      'failed',
      'interrupted',
    ].includes(j.state) ||
    !Array.isArray(j.tests) ||
    !Array.isArray(j.completed_tests)
  )
    throw new DpiError('invalid_response');
  return j;
}
export async function getDpiStatus(csrf: string): Promise<DpiStatus> {
  const { value } = await request(csrf, 'dpistatus');
  const s = value as DpiStatus;
  if (
    typeof s?.available?.available !== 'boolean' ||
    typeof s.installed?.installed !== 'boolean' ||
    !Array.isArray(s.history) ||
    s.history.length > 3
  )
    throw new DpiError('invalid_response');
  if (s.active !== null) job(s.active);
  s.history.forEach(job);
  return s;
}
export async function installDpi(
  csrf: string,
  requestId: string,
): Promise<DpiJob> {
  return job(
    (
      await request(csrf, 'dpiinstall', {
        request_id: req(requestId),
        consent: 'install',
      })
    ).value,
  );
}
export async function startDpi(
  csrf: string,
  requestId: string,
  groups: number[],
  heavyConsent: number[],
): Promise<DpiJob> {
  if (
    !groups.length ||
    groups.some(
      (g, i) =>
        !Number.isInteger(g) || g < 0 || g > 6 || (i > 0 && g <= groups[i - 1]),
    ) ||
    heavyConsent.join('') !== groups.filter((g) => g === 5 || g === 6).join('')
  )
    throw new DpiError('invalid_request');
  return job(
    (
      await request(csrf, 'dpistart', {
        request_id: req(requestId),
        tests: groups.join(''),
        heavy_consent: heavyConsent.join(''),
      })
    ).value,
  );
}
export async function stopDpi(
  csrf: string,
  jobId: string,
): Promise<{ id: string; state: 'stopping' }> {
  const { value } = await request(csrf, 'dpistop', { job_id: id(jobId) });
  const v = value as { id: string; state: 'stopping' };
  if (v.id !== jobId || v.state !== 'stopping')
    throw new DpiError('invalid_response');
  return v;
}
export async function downloadDpiResult(
  csrf: string,
  jobId: string,
): Promise<DpiFile> {
  const { value, text, response } = await request(
    csrf,
    'dpiresult',
    { job_id: id(jobId) },
    true,
  );
  const v = value as {
    type: string;
    schema_version: number;
    origin: string;
    started_at: string;
    state: DpiState;
    groups: unknown[];
  };
  if (
    v?.type !== 'nfqws2_dpi' ||
    v.schema_version !== 1 ||
    v.origin !== 'router' ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(v.started_at) ||
    !Array.isArray(v.groups) ||
    !v.groups.length ||
    ['queued', 'running'].includes(v.state)
  )
    throw new DpiError('invalid_response');
  const filename = `NFQWS2_DPI_${v.started_at.slice(0, -1).replace('T', '_').replace(/:/g, '-')}Z.json`;
  if (
    response.headers.get('Content-Disposition') !==
    `attachment; filename="${filename}"`
  )
    throw new DpiError('invalid_response');
  return Object.freeze({
    blob: new Blob([text], { type: 'application/json' }),
    filename,
    jobId,
    startedAt: v.started_at,
    complete: v.state === 'completed',
  });
}
export async function deleteDpiResult(
  csrf: string,
  jobId: string,
): Promise<{ deleted: true }> {
  const { value } = await request(csrf, 'dpidelete', { job_id: id(jobId) });
  if ((value as { deleted: unknown })?.deleted !== true)
    throw new DpiError('invalid_response');
  return { deleted: true };
}
