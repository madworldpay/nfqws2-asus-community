import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  MenuItem,
  Select,
  Stack,
  Typography,
} from '@mui/material';

import { getDpiStatus, type DpiJob } from '@/api/dpiClient';
import {
  prepareSupportBundle,
  type SupportBundleFile,
} from '@/api/supportBundle';
import type { SupportReportFile } from '@/api/supportReport';

import { DpiResults } from '@/components/DpiResults';

import { useTranslation } from '@/hooks/useTranslation';

export const DpiAttachment = ({
  csrfToken,
  report,
  transportEnabled,
  disabled,
  onPrepared,
  onCleared,
  onSelection,
}: {
  csrfToken: string;
  report: SupportReportFile;
  transportEnabled: boolean;
  disabled: boolean;
  onPrepared: (bundle: SupportBundleFile) => void;
  onCleared: () => void;
  onSelection: (selected: boolean) => void;
}) => {
  const { t } = useTranslation();
  const [jobs, setJobs] = useState<DpiJob[]>([]);
  const [selected, setSelected] = useState(false);
  const [jobId, setJobId] = useState('');
  const [pending, setPending] = useState(false);
  const [failed, setFailed] = useState(false);
  const [bundle, setBundle] = useState<SupportBundleFile>();
  const sequence = useRef({ value: 0 });
  useEffect(() => {
    let active = true;
    const generation = sequence.current;
    void getDpiStatus(csrfToken).then(
      (s) => {
        if (active) {
          const eligible = s.history.filter(
            (j) => j.kind === 'run' && j.completed_tests.length > 0,
          );
          setJobs(eligible);
          setJobId(eligible[0]?.id ?? '');
        }
      },
      () => {},
    );
    return () => {
      active = false;
      generation.value++;
    };
  }, [csrfToken]);
  const prepare = async (id: string) => {
    const seq = ++sequence.current.value;
    setBundle(undefined);
    onCleared();
    setFailed(false);
    setPending(true);
    try {
      const b = await prepareSupportBundle(report, id, csrfToken);
      if (seq === sequence.current.value) {
        setBundle(b);
        onPrepared(b);
      }
    } catch {
      if (seq === sequence.current.value) setFailed(true);
    } finally {
      if (seq === sequence.current.value) setPending(false);
    }
  };
  return (
    <Stack spacing={1}>
      <FormControlLabel
        control={
          <Checkbox
            checked={selected}
            disabled={disabled || jobs.length === 0 || !report.proof}
            onChange={(_, checked) => {
              sequence.current.value++;
              setSelected(checked);
              onSelection(checked);
              setBundle(undefined);
              setPending(false);
              setFailed(false);
              onCleared();
              if (checked) void prepare(jobId);
            }}
          />
        }
        label={t('dpi.attach')}
      />
      {jobs.length === 0 && (
        <Typography variant="body2">{t('dpi.no_result')}</Typography>
      )}
      {selected && (
        <>
          <Select
            size="small"
            value={jobId}
            disabled={disabled || pending}
            onChange={(e) => {
              setJobId(e.target.value);
              void prepare(e.target.value);
            }}
          >
            {jobs.map((j) => (
              <MenuItem key={j.id} value={j.id}>
                {new Date(j.started_at * 1000).toLocaleString()} ·{' '}
                {t(`dpi.state_${j.state}`)} · {j.completed_tests.join(', ')}
              </MenuItem>
            ))}
          </Select>
          <Typography variant="body2">{t('dpi.attach_snapshot')}</Typography>
          {!transportEnabled && (
            <Alert severity="info">{t('dpi.attach_local_only')}</Alert>
          )}
          {pending && <CircularProgress size={20} />}
          {failed && <Alert severity="info">{t('dpi.attach_failed')}</Alert>}
          {bundle && (
            <DpiResults
              file={{
                ...bundle.files[1],
                jobId,
                startedAt: new Date(
                  jobs.find((j) => j.id === jobId)!.started_at * 1000,
                ).toISOString(),
              }}
            />
          )}
        </>
      )}
    </Stack>
  );
};
