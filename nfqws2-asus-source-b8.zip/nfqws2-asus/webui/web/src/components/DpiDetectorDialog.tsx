import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  Button,
  Checkbox,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  Link,
  Stack,
  Typography,
} from '@mui/material';

import {
  deleteDpiResult,
  downloadDpiResult,
  getDpiStatus,
  installDpi,
  startDpi,
  stopDpi,
  type DpiFile,
  type DpiStatus,
} from '@/api/dpiClient';
import { newSupportSubmissionId } from '@/api/supportReport';

import { DpiResults } from '@/components/DpiResults';

import { useTranslation } from '@/hooks/useTranslation';

export const DpiDetectorDialog = ({
  csrfToken,
  onClose,
}: {
  csrfToken: string;
  onClose: () => void;
}) => {
  const { t } = useTranslation();
  const [status, setStatus] = useState<DpiStatus>();
  const [tests, setTests] = useState([1, 2]);
  const [consent, setConsent] = useState<number[]>([]);
  const [confirm, setConfirm] = useState<'install' | 'run' | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [file, setFile] = useState<DpiFile>();
  const alive = useRef(true);
  const busy = useRef(false);
  const loading = useRef(false);
  const load = useCallback(async () => {
    if (loading.current) return;
    loading.current = true;
    try {
      const s = await getDpiStatus(csrfToken);
      if (alive.current) {
        setStatus(s);
        setError('');
      }
    } catch {
      if (alive.current) setError(t('dpi.request_failed'));
    } finally {
      loading.current = false;
    }
  }, [csrfToken, t]);
  useEffect(() => {
    alive.current = true;
    void load();
    const timer = setInterval(() => {
      void load();
    }, 2000);
    return () => {
      alive.current = false;
      clearInterval(timer);
    };
  }, [load]);
  const action = async (fn: () => Promise<unknown>) => {
    if (busy.current) return;
    busy.current = true;
    setPending(true);
    setError('');
    try {
      await fn();
      setConfirm(null);
      await load();
    } catch {
      setError(t('dpi.request_failed'));
    } finally {
      busy.current = false;
      setPending(false);
    }
  };
  const heavy = tests.filter((g) => g === 5 || g === 6);
  const canRun =
    !!status?.installed.installed &&
    !!status.available.available &&
    !status.active &&
    !pending;
  const groupLabels = [
    t('dpi.group0'),
    t('dpi.group1'),
    t('dpi.group2'),
    t('dpi.group3'),
    t('dpi.group4'),
    t('dpi.group5'),
    t('dpi.group6'),
  ];
  return (
    <Dialog open onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>DPI Detector</DialogTitle>
      <DialogContent dividers>
        <Stack spacing={2}>
          <Typography>{t('dpi.purpose')}</Typography>
          <Alert severity="info">{t('dpi.router_origin')}</Alert>
          <Typography variant="body2">
            {status?.version ?? 'v5.0.0-alpha.21'} · {t('dpi.prerelease')} ·{' '}
            {t('dpi.limits')}
          </Typography>
          {error && <Alert severity="error">{error}</Alert>}
          {!status && <CircularProgress size={22} />}
          {status && !status.available.available && (
            <Alert severity="info">
              {t('dpi.unavailable')} ({status.available.code})
            </Alert>
          )}
          {status?.active && (
            <Alert severity="info">
              {t('dpi.active')} ·{' '}
              {status.active.kind === 'install'
                ? t('dpi.install')
                : t(`dpi.state_${status.active.state}`)}
              {status.active.current_group !== null
                ? ` · ${groupLabels[status.active.current_group]}`
                : ''}{' '}
              · {t('dpi.completed')}:{' '}
              {status.active.completed_tests.join(', ') || '—'}
              {' · '}
              {t('dpi.elapsed')}:{' '}
              {Math.max(0, Math.floor(Date.now() / 1000 - status.active.started_at))}
              {t('dpi.seconds')}
            </Alert>
          )}
          {!status?.installed.installed ? (
            <Stack direction="row" spacing={1} alignItems="center">
              <Button
                variant="contained"
                disabled={
                  !status?.available.available || !!status?.active || pending
                }
                onClick={() => setConfirm('install')}
              >
                {t('dpi.install')}
              </Button>
              <Typography variant="body2">{t('dpi.install_size')}</Typography>
            </Stack>
          ) : (
            <Alert severity="success">
              {t('dpi.installed')} {status.installed.version}
            </Alert>
          )}
          <Stack spacing={0}>
            <Button
              disabled={pending || !!status?.active}
              onClick={() => {
                setTests([1, 2]);
                setConsent([]);
              }}
            >
              {t('dpi.quick')}
            </Button>
            {groupLabels.map((label, g) => (
              <FormControlLabel
                key={g}
                control={
                  <Checkbox
                    checked={tests.includes(g)}
                    disabled={pending || !!status?.active}
                    onChange={(_, checked) => {
                      setTests((v) =>
                        checked
                          ? [...v, g].sort((a, b) => a - b)
                          : v.filter((x) => x !== g),
                      );
                      setConsent([]);
                    }}
                  />
                }
                label={`${g}. ${label}`}
              />
            ))}
          </Stack>
          <Stack direction="row" spacing={1}>
            <Button
              variant="contained"
              disabled={!canRun || !tests.length}
              onClick={() => {
                setConsent([]);
                setConfirm('run');
              }}
            >
              {t('dpi.start')}
            </Button>
            <Button
              disabled={pending || !status?.active}
              onClick={() =>
                void action(() => stopDpi(csrfToken, status!.active!.id))
              }
            >
              {t('dpi.stop')}
            </Button>
          </Stack>
          {status?.history.map((job) => (
            <Stack
              key={job.id}
              direction="row"
              spacing={1}
              alignItems="center"
              flexWrap="wrap"
            >
              <Typography variant="body2">
                {job.kind === 'install'
                  ? t('dpi.install')
                  : job.tests.join(', ')}{' '}
                · {t(`dpi.state_${job.state}`)}
                {job.code ? ` (${job.code})` : ''}
              </Typography>
              {job.completed_tests.length > 0 && (
                <>
                  <Button
                    disabled={pending}
                    onClick={() =>
                      void action(async () => {
                        setFile(await downloadDpiResult(csrfToken, job.id));
                      })
                    }
                  >
                    {t('dpi.results')}
                  </Button>
                  <Button
                    disabled={pending}
                    onClick={() =>
                      void action(async () => {
                        await deleteDpiResult(csrfToken, job.id);
                        if (file?.jobId === job.id) setFile(undefined);
                      })
                    }
                  >
                    {t('dpi.delete')}
                  </Button>
                </>
              )}
            </Stack>
          ))}
          {file && <DpiResults file={file} />}
          <Link
            href="https://github.com/Runnin4ik/dpi-detector"
            target="_blank"
            rel="noopener noreferrer"
          >
            DPI Detector · GitHub
          </Link>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.close')}</Button>
      </DialogActions>
      <Dialog
        open={confirm !== null}
        onClose={() => {
          if (!pending) setConfirm(null);
        }}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          {t(confirm === 'install' ? 'dpi.install' : 'dpi.start')}
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2}>
            <Typography>
              {t(
                confirm === 'install'
                  ? 'dpi.install_confirm'
                  : 'dpi.run_confirm',
              )}
            </Typography>
            {confirm === 'run' &&
              heavy.map((g) => (
                <FormControlLabel
                  key={g}
                  control={
                    <Checkbox
                      checked={consent.includes(g)}
                      onChange={(_, checked) =>
                        setConsent((v) =>
                          checked ? [...v, g].sort() : v.filter((x) => x !== g),
                        )
                      }
                    />
                  }
                  label={t(g === 5 ? 'dpi.heavy5' : 'dpi.heavy6')}
                />
              ))}
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button disabled={pending} onClick={() => setConfirm(null)}>
            {t('common.cancel')}
          </Button>
          <Button
            variant="contained"
            disabled={
              pending ||
              (confirm === 'run' && heavy.join('') !== consent.join(''))
            }
            onClick={() =>
              void action(() =>
                confirm === 'install'
                  ? installDpi(csrfToken, newSupportSubmissionId())
                  : startDpi(
                      csrfToken,
                      newSupportSubmissionId(),
                      tests,
                      consent,
                    ),
              )
            }
          >
            {pending ? <CircularProgress size={18} /> : t('ark.confirm')}
          </Button>
        </DialogActions>
      </Dialog>
    </Dialog>
  );
};
