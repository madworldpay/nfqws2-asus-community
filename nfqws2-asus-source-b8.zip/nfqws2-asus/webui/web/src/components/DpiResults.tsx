import { useEffect, useState } from 'react';
import { Alert, Box, Button, Stack, Typography } from '@mui/material';

import type { DpiFile } from '@/api/dpiClient';
import { saveSupportReport } from '@/api/supportReport';

import { useTranslation } from '@/hooks/useTranslation';

export const DpiResults = ({ file }: { file: DpiFile }) => {
  const { t } = useTranslation();
  const [text, setText] = useState('');
  const [error, setError] = useState(false);
  useEffect(() => {
    let alive = true;
    void file.blob.text().then((v) => {
      if (alive) setText(v);
    });
    return () => {
      alive = false;
    };
  }, [file]);
  return (
    <Stack spacing={1}>
      <Typography variant="body2">{file.filename}</Typography>
      {!file.complete && <Alert severity="info">{t('dpi.partial')}</Alert>}
      <Box
        component="pre"
        sx={{
          m: 0,
          p: 1,
          whiteSpace: 'pre-wrap',
          overflowWrap: 'anywhere',
          maxHeight: 320,
          overflow: 'auto',
          bgcolor: 'action.hover',
          fontSize: 12,
        }}
      >
        {text}
      </Box>
      {error && (
        <Alert severity="error">{t('report.errors.save_failed')}</Alert>
      )}
      <Button
        onClick={() => {
          setError(false);
          void saveSupportReport(file).catch((e) => {
            if (!(e instanceof DOMException && e.name === 'AbortError'))
              setError(true);
          });
        }}
      >
        {t('dpi.save')}
      </Button>
    </Stack>
  );
};
