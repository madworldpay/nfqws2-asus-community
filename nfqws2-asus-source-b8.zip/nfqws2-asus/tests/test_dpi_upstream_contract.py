"""Pinned native upstream with synthetic targets in a network namespace without uplinks."""
import hashlib,json,os,subprocess,tempfile,unittest
from pathlib import Path
from test_dpi_normalize import PHP,PUBLIC,ROOT

class DpiUpstreamContractTests(unittest.TestCase):
    def test_pinned_cli_json_with_only_synthetic_network(self):
        assets=Path(os.environ['DPI_TEST_ASSETS']);abi=Path(PHP).name.removesuffix('-cli-wrapper');arm=abi.startswith('armv7');name='dpi-detector-linux-armv7' if arm else 'dpi-detector-linux-arm64'
        catalog=json.loads((ROOT/'support/dpi-catalog.json').read_text());artifact=catalog['artifacts']['armv7-3.2' if arm else 'aarch64-3.10'];binary=assets/name
        self.assertEqual(hashlib.sha256(binary.read_bytes()).hexdigest(),artifact['sha256'])
        cache=Path(PHP).parent;qemu=cache/('qemu-arm' if arm else 'qemu-aarch64');sysroot=cache/(abi+'-sysroot')
        script='''import os,json,socket,subprocess,threading,sys
subprocess.run(['ip','link','set','lo','up'],check=True)
s=socket.socket();s.bind(('127.0.0.1',0));s.listen();s.settimeout(.1)
stop=False
def serve():
 while not stop:
  try:c,_=s.accept();c.close()
  except socket.timeout:pass
t=threading.Thread(target=serve,daemon=True);t.start()
p=json.load(open('config.yml'));p.update(TIMEOUT=.1,FAT_CONNECT_TIMEOUT=.1,FAT_READ_TIMEOUT=.1,STUB_IPS_TIMEOUT=.1,IP4_LOOKUP_URLS=[],IP6_LOOKUP_URLS=[],CYMRU_DOH_SERVERS=[])
open('config.yml','w').write(json.dumps(p));open('tcp16.json','w').write(json.dumps([{'id':'HE-01','asn':'PRIVATE_CANARY','provider':'PRIVATE_CANARY','ip':'127.0.0.1','port':s.getsockname()[1]}]))
r=subprocess.run(sys.argv[1:]+['--json','--tests','3','--lang','ru','--profile','ru','--concurrency','2','--domains','domains.txt','--tcp16','tcp16.json'],env={'PATH':'/usr/bin:/bin','LANG':'C','HOME':os.getcwd(),'XDG_CONFIG_HOME':os.getcwd(),'TMPDIR':os.getcwd(),'TOKIO_WORKER_THREADS':'1'},capture_output=True,timeout=15)
stop=True;s.close();sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);sys.exit(r.returncode)
'''
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory);(p/'config.yml').write_text((ROOT/'support/dpi-profile.json').read_text());(p/'domains.txt').write_text('example.com\n');(p/'whitelist_sni.txt').write_text('example.com\n')
            run=subprocess.run(['unshare','-Urn','python3','-c',script,str(qemu),'-L',str(sysroot),str(binary)],cwd=p,capture_output=True,timeout=20)
            self.assertEqual(run.returncode,0,run.stderr.decode());raw=p/'raw';raw.write_bytes(run.stdout)
            value=json.loads(run.stdout);self.assertEqual(value['schema_version'],1);self.assertEqual(list(value['results']),['tcp16'])
            code="require $argv[1].'/dpi-normalize.php';echo json_encode(AsusDpiNormalizer::group(file_get_contents($argv[2]),3,AsusDpiCatalog::load()));"
            r=subprocess.run([PHP,'-n','-r',code,str(PUBLIC),str(raw)],capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertNotIn('PRIVATE_CANARY',r.stdout);self.assertEqual(json.loads(r.stdout)['rows'][0]['target'],'HE-01')
