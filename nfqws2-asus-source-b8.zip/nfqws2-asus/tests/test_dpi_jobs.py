import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from test_dpi_normalize import PHP,PUBLIC,ROOT


class DpiJobsTests(unittest.TestCase):
    def call(self,script):
        with tempfile.TemporaryDirectory() as directory:
            code='''require $argv[1].'/dpi-jobs.php';try{$s=new AsusDpiStore($argv[2].'/state',(int)$argv[3]);$calls=[];
            $dep=['launch'=>function($id,$kind)use(&$calls){$calls[]=[$id,$kind];},'available'=>fn()=>['available'=>true,'code'=>'ready'],'installed'=>fn()=>true];
            $j=new AsusDpiJobs($s,$dep);'''+script+'''}catch(Throwable $e){echo json_encode(['error'=>$e->getMessage()]);}'''
            r=subprocess.run([PHP,'-n','-r',code,str(PUBLIC),directory,str(os.getuid()),str(ROOT)],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertEqual(r.stderr,'');return json.loads(r.stdout)
    def test_default_12_and_all_groups_require_exact_heavy_consent(self):
        for groups,consent,error in [([1,2],[],None),([0,1,2,3,4,5,6],[5,6],None),([5],[],'consent_required'),([2],[5],'invalid_request'),([1,1],[],'invalid_request'),([],[],'invalid_request'),([7],[],'invalid_request')]:
            s='echo json_encode([$j->startRun("11111111-1111-4111-8111-111111111111",'+json.dumps(groups)+','+json.dumps(consent)+'),$calls]);'
            r=self.call(s)
            if error:self.assertEqual(r,{'error':error})
            else:self.assertEqual(r[0]['tests'],groups);self.assertEqual(len(r[1]),1)
    def test_request_replay_never_launches_again(self):
        r=self.call('$a=$j->startRun("11111111-1111-4111-8111-111111111111",[1,2],[]);$b=$j->startRun("11111111-1111-4111-8111-111111111111",[1,2],[]);echo json_encode([$a,$b,count($calls)]);')
        self.assertEqual(r[0]['id'],r[1]['id']);self.assertEqual(r[2],1)
    def test_later_failure_preserves_earlier_group_and_marks_context_change(self):
        script='''$job=$s->reserve('11111111-1111-4111-8111-111111111111','run',['tests'=>[2,3],'heavy_consent'=>[]]);$n=0;
        $w=new AsusDpiWorker($s,['work'=>fn($id)=>$argv[2],'binary'=>fn()=>'/synthetic-detector','probe'=>function($id,$args,$cwd,$limit)use(&$n,$argv){$n++;if($n===2)throw new RuntimeException('timed_out');return ['exit'=>0,'stdout'=>json_encode(json_decode(file_get_contents($argv[4].'/tests/fixtures/dpi/group2.json'),true)['raw'])];},'context'=>function()use(&$n){return ['nfqws'=>'running','ark'=>$n?'absent':'loaded','tun_observed'=>false];}]);
        $w->run($job['id']);echo $s->readResult($job['id']);'''
        r=self.call(script);self.assertEqual(r['state'],'timed_out');self.assertEqual([g['group'] for g in r['groups']],[2]);self.assertTrue(r['context']['changed']);self.assertNotIn('PRIVATE_CANARY',json.dumps(r))
    def test_profile_is_fixed_and_command_has_no_proxy_or_interface_override(self):
        r=self.call('echo json_encode([AsusDpiWorker::arguments("/managed/binary",6),AsusDpiWorker::profile()]);')
        args,profile=r;self.assertIn('--json',args);self.assertIn('--tests',args);self.assertIn('--burst',args)
        self.assertNotIn('--proxy',args);self.assertNotIn('--iface',args);self.assertEqual(profile['MAX_CONCURRENT'],2);self.assertEqual(profile['PROXY_URL'],None)
        self.assertEqual(len(profile['DNS_AVAILABILITY_SERVERS']),9);self.assertEqual(profile['IP_VERSION'],'ipv4')
    def test_exit_error_or_missing_json_is_not_completed(self):
        script='''$job=$s->reserve('11111111-1111-4111-8111-111111111111','run',['tests'=>[2],'heavy_consent'=>[]]);$w=new AsusDpiWorker($s,['work'=>fn($id)=>$argv[2],'binary'=>fn()=>'/synthetic-detector','probe'=>fn()=>['exit'=>1,'stdout'=>'PRIVATE_CANARY'],'context'=>fn()=>['nfqws'=>'unknown','ark'=>'unknown','tun_observed'=>false]]);$w->run($job['id']);echo json_encode($s->status());'''
        r=self.call(script);self.assertEqual(r['history'][0]['state'],'failed');self.assertEqual(r['history'][0]['groups'],[])
