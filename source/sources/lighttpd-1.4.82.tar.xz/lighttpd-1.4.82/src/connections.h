#ifndef _CONNECTIONS_H_
#define _CONNECTIONS_H_
#include "first.h"

#include "base_decls.h"

struct server_socket;   /* declaration */

__attribute_cold__
void connections_pool_clear(server *srv);

__attribute_cold__
void connections_free(server *srv);

__attribute_cold__
void connection_graceful_shutdown_maint (server *srv);

void connection_periodic_maint (server *srv, unix_time64_t cur_ts);

connection * connection_accepted(server *srv, const struct server_socket *srv_socket, sock_addr *cnt_addr, int cnt);

void connection_state_machine(connection *con);

#endif
