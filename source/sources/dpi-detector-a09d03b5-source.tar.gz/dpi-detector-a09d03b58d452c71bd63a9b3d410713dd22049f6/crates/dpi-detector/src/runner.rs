//! Test orchestration: one `run_test_suite` call drives every selected test,
//! collects the rows it produced and emits both the human report and the JSON
//! document. Split out of `main` so the CLI/TUI shell and the run logic do not
//! share one 1700-line file.

use std::collections::HashSet;
use std::io::{self, IsTerminal, Write};
use std::net::{IpAddr, SocketAddr};
use std::sync::Arc;
use std::time::{Duration, Instant};
use dpi_core::classify::Detail;
use dpi_core::config::{
    clean_domain, embedded_burst_domains, embedded_domains,
    embedded_quic_unsupported, embedded_tcp16_targets, embedded_whitelist_sni,
    load_domains_from_file, load_quic_unsupported, load_tcp16_targets_from_file,
    load_whitelist_sni, resource_path, AppConfig, Tcp16Target,
};
use dpi_core::probe::tcp16::Tcp16Row;
use dpi_core::probe::dns_avail::check_dns_availability;
use dpi_core::dns::parse_socks_proxy;
use dpi_core::dns::udp::probe_udp_dns;
use crate::i18n::{legend_text, Language, Messages};
use dpi_core::net::fingerprint::{HelloVariant, TlsFingerprint};
use dpi_core::net::netinfo::{detect_bypass_tools, fetch_public_ips, get_system_dns, is_tun_name};
use dpi_core::probe::burst::{
    burst_targets, BurstAlpn, BurstObserver, BurstProfileReport, BurstSettings, BurstTarget,
    BurstTlsVersion, BURST_DEFAULT_ATTEMPTS, BURST_DEFAULT_LAUNCH_GAP_MS, BURST_DEFAULT_TIMEOUT_SECS,
};
use dpi_core::dns::cymru::{fetch_ip_cymru, IpCymruInfo};
use dpi_core::probe::domains::{
    check_domains, collect_stub_ips, domain_stats, IpFamily,
};
use dpi_core::probe::telegram::run_telegram_full;
use dpi_core::probe::whitelist::run_whitelist_sni;
use dpi_core::probe::{check_tcp_16_20, domains};
use dpi_core::profile::RegionProfile;
use dpi_core::{PhaseProgress, ProgressTick};
use tokio::sync::Semaphore;

use crate::args::CliArgs;
use crate::render::{
    render_banner, render_burst_table,
    render_dns_availability, render_dns_endpoints, render_dns_resolve_notes, render_domain_table, render_intercept_notice, render_netinfo_panel, render_summary, render_tcp_table, render_telegram,
    render_whitelist, LiveProgress,
    NetFamilyInfo, NetInfoData, NetTtlb, Spinner, SummaryData,
};
use crate::{print_out, tcp16_detail, Emitter};

/// The domains to probe: `-d` names first, then `--domains`/the configured file,
/// then the embedded list, then the profile's own.
///
/// A list the user named *is* the run's target set, so it either yields targets
/// or comes back as an error: `--domains /typo.txt`, a `--domains` file that
/// parses to nothing and a `-d` list whose every entry `clean_domain` filtered
/// away all used to end as a "successful" run that probed nothing. The
/// configured and embedded lists are preferences, so those still fall through.
pub(crate) fn load_domains(args: &CliArgs, cfg: &AppConfig, profile: RegionProfile, msg: &Messages) -> io::Result<Vec<String>> {
    load_domain_set(args, profile, &cfg.domains_file, embedded_domains(), msg)
}

/// Test 6's shipped target file. Deliberately not the configured `domains_file`:
/// that one belongs to test 2, and a `domains.txt` sitting next to the binary
/// would otherwise put the censored-sites list in front of test 6's own hosts.
const BURST_DOMAINS_FILE: &str = "burst-domains.txt";

/// Test 6's targets, by the same precedence with its own list.
///
/// `-d` and `--domains` still pick the hosts for a run — someone who wrote a
/// list out means it. What this does not do is fall back to the censored sites
/// test 2 measures: a host that is already blocked cannot say whether connecting
/// to it N times is what broke it.
pub(crate) fn load_burst_domains(args: &CliArgs, profile: RegionProfile, msg: &Messages) -> io::Result<Vec<String>> {
    load_domain_set(args, profile, BURST_DOMAINS_FILE, embedded_burst_domains(), msg)
}

fn load_domain_set(
    args: &CliArgs,
    profile: RegionProfile,
    file_name: &str,
    embedded: Vec<String>,
    msg: &Messages,
) -> io::Result<Vec<String>> {
    // The two ways a list the operator named can come back empty are refused
    // here rather than turned into a run with no targets: `empty_named_list` is
    // the reason the caller's notice (`domains_load_failed`) prints in its `{}`
    // slot, and it names the source the notice cannot tell apart by itself.
    if !args.domain.is_empty() {
        let named: Vec<String> = args.domain.iter().filter_map(|d| clean_domain(d)).collect();
        if named.is_empty() {
            return Err(empty_named_list(msg, "-d"));
        }
        return Ok(named);
    }
    if let Some(path) = &args.domains {
        // A file the user named is the run's target list, so a path that cannot
        // be read is reported rather than swapped for an empty one: `--domains
        // /typo.txt` used to end as a "successful" run that probed nothing. The
        // path is folded into the error because the OS message alone does not
        // say which file it was.
        let from_file = load_domains_from_file(path)
            .map_err(|err| io::Error::new(err.kind(), format!("{path}: {err}")))?;
        // A file that reads but holds no domain (blank lines and `#` comments
        // only) is the same empty run, so it is refused the same way.
        if from_file.is_empty() {
            return Err(empty_named_list(msg, path));
        }
        return Ok(from_file);
    }
    let from_file = load_domains_from_file(resource_path(file_name)).unwrap_or_default();
    if !from_file.is_empty() {
        return Ok(from_file);
    }
    if !embedded.is_empty() {
        return Ok(embedded);
    }
    Ok(profile.default_domains().iter().map(|s| s.to_string()).collect())
}

/// The error for a list the operator named that holds nothing to probe.
///
/// An `io::Error` — and so exit code 2 at the caller — rather than an empty
/// `Ok`: a run with no targets prints a report of nothing and exits zero, which
/// reads as "nothing was blocked". The source is folded in because the notice
/// alone does not say whether it was `-d` or the `--domains` file.
fn empty_named_list(msg: &Messages, source: &str) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        msg.domains_list_empty.replace("{}", source),
    )
}

/// The 16 KB-test targets: `--tcp16`, then the configured file, then the
/// embedded list, then the shipped defaults.
///
/// The one error that comes back is the file `--tcp16` named: it *is* the run's
/// target list, so the caller reports it instead of firing at the shipped hosts
/// the operator never asked for.
pub(crate) fn load_tcp16_targets(args: &CliArgs, cfg: &AppConfig) -> io::Result<Vec<Tcp16Target>> {
    if let Some(path) = &args.tcp16 {
        // The path is folded into the error because the OS message alone does
        // not say which file it was.
        let from_file = load_tcp16_targets_from_file(path)
            .map_err(|err| io::Error::new(err.kind(), format!("{path}: {err}")))?;
        return Ok(if from_file.is_empty() { embedded_tcp16_targets() } else { from_file });
    }
    let from_file = load_tcp16_targets_from_file(resource_path(&cfg.tcp16_file)).unwrap_or_default();
    if !from_file.is_empty() {
        return Ok(from_file);
    }
    Ok(embedded_tcp16_targets())
}

/// The white-SNI list: the configured file, else the embedded one. There is no
/// flag for it, and test 4 reports itself unavailable when this is empty.
///
/// A file that is there but cannot be read is reported and then treated as
/// absent: the embedded list is the documented fallback, and the notice is what
/// lets an operator tell an unreadable file from a missing one — which is why a
/// missing file (the normal case on a router) stays silent. The notice goes to
/// stderr, so `--json` stdout stays byte-clean.
pub(crate) fn load_whitelist_sni_list(cfg: &AppConfig, msg: &Messages) -> Vec<(String, usize)> {
    let path = resource_path(&cfg.whitelist_sni_file);
    let from_file = match load_whitelist_sni(&path) {
        Ok(list) => list,
        Err(err) => {
            if err.kind() != io::ErrorKind::NotFound {
                eprintln!(
                    "{}",
                    msg.whitelist_load_failed
                        .replacen("{}", &format!("{}: {err}", path.display()), 1)
                );
            }
            Vec::new()
        }
    };
    if from_file.is_empty() {
        embedded_whitelist_sni()
    } else {
        from_file
    }
}

pub(crate) fn load_quic_unsupported_list(cfg: &AppConfig, msg: &Messages) -> Vec<String> {
    let path = resource_path(&cfg.quic_unsupported_file);
    let from_file = match load_quic_unsupported(&path) {
        Ok(list) => list,
        Err(err) => {
            if err.kind() != io::ErrorKind::NotFound {
                eprintln!(
                    "{}",
                    msg.quic_unsupported_load_failed
                        .replacen("{}", &format!("{}: {err}", path.display()), 1)
                );
            }
            Vec::new()
        }
    };
    if from_file.is_empty() {
        embedded_quic_unsupported()
    } else {
        from_file
    }
}

pub(crate) fn mask_proxy(url: &str) -> String {
    // socks5://user:pass@host → socks5://user:***@host
    match url.find('@') {
        Some(at) => {
            let (left, right) = url.split_at(at);
            match left.rfind(':') {
                Some(colon) if left[..colon].contains("://") => {
                    format!("{}:***{}", &left[..colon], right)
                }
                _ => url.to_string(),
            }
        }
        None => url.to_string(),
    }
}

/// Builds one per-family fact. A Cymru field the lookup did not answer stays
/// `None`, which is what the panel renders as its red localized timeout cell —
/// "not measured" is a state of the value, not a value of its own, so it must
/// not be spelled out here.
pub(crate) fn family_info(ip: Option<(IpAddr, u64)>, extra: Option<IpCymruInfo>) -> Option<NetFamilyInfo> {
    let (addr, ms) = ip?;
    let (subnet, org, asn, cc) = match extra {
        Some(e) => (e.subnet, e.org, Some(e.asn), e.country),
        None => (None, None, None, None),
    };
    Some(NetFamilyInfo {
        ip: Some(addr.to_string()),
        ttlb: NetTtlb::Ms(ms),
        subnet,
        org,
        asn,
        cc,
    })
}

/// Both lookups dead: every cell of both families is the panel's timeout cell.
pub(crate) fn timeout_family() -> NetFamilyInfo {
    NetFamilyInfo {
        ip: None,
        ttlb: NetTtlb::Timeout,
        subnet: None,
        org: None,
        asn: None,
        cc: None,
    }
}

/// The hosts a run probes once the settings screen has answered: the typed host
/// replaces the configured list for that run, and an empty box goes back to it.
///
/// The screen opens with the last answer already in its box, so an empty box is
/// the user having cleared it. Treating empty as "reuse the previous answer"
/// ran the host typed twenty minutes earlier while the box looked empty.
pub(crate) fn burst_targets_after_screen(defaults: &[String], choice: Option<&str>) -> Vec<String> {
    match choice {
        Some(domain) => vec![domain.to_string()],
        None => defaults.to_vec(),
    }
}

/// Everything test 6 needs: the burst shape and the hosts to fire it at.
pub(crate) struct BurstPlan {
    pub(crate) settings: BurstSettings,
    pub(crate) targets: Vec<String>,
}

/// Reports an unknown test 6 axis value (TLS version, ALPN) and keeps the
/// default, the way an unknown profile name is reported rather than swapped
/// silently.
pub(crate) fn warn_unknown_axis(msg: &Messages, args: &CliArgs, flag: &str, value: &str, fallback: &str) {
    if args.json {
        return;
    }
    eprintln!(
        "{}",
        msg.warn_unknown_flag_value
            .replacen("{}", flag, 1)
            .replacen("{}", value, 1)
            .replacen("{}", fallback, 1)
    );
}

/// Builds test 6's plan from the CLI. An unknown profile name is reported (the
/// test then runs the profiles it did understand) rather than silently swapped
/// for a different set.
pub(crate) fn burst_plan_from_cli(args: &CliArgs, domains: &[String], msg: &Messages) -> BurstPlan {
    let (profiles, unknown) = match &args.burst_profiles {
        Some(value) => TlsFingerprint::parse_list(value),
        None => (TlsFingerprint::DEFAULT_SET.to_vec(), Vec::new()),
    };
    if !args.json {
        for token in unknown {
            let fallback =
                profiles.iter().map(|f| f.display_label()).collect::<Vec<_>>().join(", ");
            eprintln!(
                "{}",
                msg.warn_unknown_fingerprint.replacen("{}", &token, 1).replacen("{}", &fallback, 1)
            );
        }
    }
    let tls = match &args.burst_tls {
        Some(value) => BurstTlsVersion::parse(value).unwrap_or_else(|| {
            warn_unknown_axis(msg, args, "--burst-tls", value, BurstTlsVersion::default().code());
            BurstTlsVersion::default()
        }),
        None => BurstTlsVersion::default(),
    };
    let alpn = match &args.burst_alpn {
        Some(value) => BurstAlpn::parse(value).unwrap_or_else(|| {
            warn_unknown_axis(msg, args, "--burst-alpn", value, BurstAlpn::default().token());
            BurstAlpn::default()
        }),
        None => BurstAlpn::default(),
    };
    // Fatal rather than a warning, the way an interface name that matches nothing
    // is: carrying on would fire the profiles as they are while the caller
    // believes a variant was tested, and that is a wrong answer instead of a
    // missing one. Every other axis keeps its default and says so.
    let variant = match &args.burst_variant {
        Some(value) => match HelloVariant::parse(value) {
            Ok(variant) => Some(variant),
            Err(reason) => {
                eprintln!(
                    "{}",
                    msg.burst_variant_bad.replacen("{}", value, 1).replacen("{}", &reason.to_string(), 1)
                );
                std::process::exit(2);
            }
        },
        None => None,
    };
    let mut settings = BurstSettings::clamped(
        args.burst.unwrap_or(BURST_DEFAULT_ATTEMPTS),
        args.burst_timeout.unwrap_or(BURST_DEFAULT_TIMEOUT_SECS),
        args.burst_gap.unwrap_or(BURST_DEFAULT_LAUNCH_GAP_MS),
        tls,
        alpn,
        profiles,
    );
    settings.variant = variant;
    // `all` and any long explicit list cost a handshake per profile per host per
    // version axis, so the price is stated before the run rather than discovered
    // in the wall clock. The default set stays quiet: it is the budget a run
    // without flags already assumes.
    if !args.json && settings.profiles.len() > TlsFingerprint::DEFAULT_SET.len() {
        eprintln!(
            "{}",
            msg.warn_burst_budget
                .replacen("{}", &settings.profiles.len().to_string(), 1)
                .replacen("{}", &TlsFingerprint::DEFAULT_SET.len().to_string(), 1)
        );
    }
    // `-d` picks the targets, exactly as it does for test 2 — and goes through
    // the same cleaner, so `-d https://host/path` probes `host` instead of a name
    // no resolver knows. An input that cleans to nothing falls back to the
    // configured list rather than firing at no target at all.
    let targets = if args.domain.is_empty() {
        domains.to_vec()
    } else {
        let cleaned: Vec<String> = args.domain.iter().filter_map(|d| clean_domain(d)).collect();
        if cleaned.is_empty() {
            domains.to_vec()
        } else {
            cleaned
        }
    };
    BurstPlan { settings, targets }
}

/// Draws the burst's live line: the shape on the wire right now, which round
/// that is of how many, how many hosts of the round are done, and the clock.
pub(crate) struct BurstLine {
    live: Arc<LiveProgress>,
    msg: Messages,
}

impl BurstObserver for BurstLine {
    fn round_started(&self, fingerprint: TlsFingerprint, index: usize, total: usize, hosts: usize) {
        // `LiveProgress` resets its clock on every `set`, so the timer reads as
        // the round's elapsed time rather than the whole run's.
        self.live.set(
            format!(
                "{}: {} {}/{}",
                self.msg.burst_testing,
                fingerprint.display_label(),
                index + 1,
                total
            ),
            hosts,
        );
    }

    fn host_finished(&self) {
        self.live.tick();
    }
}

/// `--trace`: one line per attempt of test 6, written the moment the attempt
/// exists.
///
/// The line is machine-readable on purpose — a UTC stamp, the round, the shape,
/// the host, the attempt, the status token, the detail code and the milliseconds
/// — so a round that fell over can be read back afterwards (`grep safari
/// trace.log`) or watched live in a second window (`Get-Content -Wait`) while
/// the screen redraws. It carries no translated text, so it reads the same in
/// every language, and it never touches stdout: the frame and the table stay
/// where they were.
struct TraceObserver {
    /// The queue into the writer thread. A `Mutex` for `Sync`, not for
    /// contention — the burst loop is its only sender, and a send on an
    /// unbounded channel only enqueues, so the lock never spans I/O.
    out: std::sync::Mutex<TraceWriter>,
    round: std::sync::Mutex<(usize, usize)>,
}

/// The thread that owns a `--trace` sink.
///
/// The burst loop runs on the one runtime thread the TUI draws on, and `--trace`
/// is aimed at routers, where the file is flash rather than page cache: a
/// write+flush per attempt from there stalls the probes and the screen with
/// them. One thread fed over a channel keeps the order the lines were produced
/// in and still flushes each line, which is what a live `Get-Content -Wait`
/// tailing the file needs.
struct TraceWriter {
    /// `None` once the writer is dropped: the channel has to be closed before
    /// the thread can be joined, and a field is only dropped *after* `drop`
    /// returns, so the close has to be an explicit take.
    tx: Option<std::sync::mpsc::Sender<String>>,
    thread: Option<std::thread::JoinHandle<()>>,
}

impl TraceWriter {
    fn spawn(out: Box<dyn Write + Send>) -> Self {
        // Unbounded on purpose: a bounded `send` would block the runtime thread
        // exactly when the sink is slow, which is the stall this thread exists
        // to remove. The queue only grows if the file cannot keep up with the
        // probes.
        let (tx, rx) = std::sync::mpsc::channel::<String>();
        let thread = std::thread::spawn(move || {
            let mut out = out;
            // Ends when the observer drops its sender.
            while let Ok(line) = rx.recv() {
                // A failed write is not worth stopping a diagnostic run for.
                let _ = writeln!(out, "{line}");
                let _ = out.flush();
            }
        });
        Self { tx: Some(tx), thread: Some(thread) }
    }

    fn send(&self, line: String) {
        if let Some(tx) = &self.tx {
            // A writer that is gone leaves the run untraced rather than failing.
            let _ = tx.send(line);
        }
    }
}

impl Drop for TraceWriter {
    fn drop(&mut self) {
        // Close the channel, then wait for the queue to drain: the last lines of
        // a round are the interesting ones, and the process may exit the moment
        // the run ends.
        self.tx = None;
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

impl TraceObserver {
    /// `None` when no trace was asked for, or when the file it named cannot be
    /// opened — in which case the run continues untraced and says why.
    fn new(target: Option<&str>, msg: &Messages) -> Option<Self> {
        let target = target?;
        let out: Box<dyn Write + Send> = if target.is_empty() {
            Box::new(std::io::stderr())
        } else {
            match std::fs::File::create(target) {
                Ok(file) => Box::new(file),
                Err(err) => {
                    eprintln!(
                        "{}",
                        msg.trace_open_failed
                            .replacen("{}", &format!("{target}: {err}"), 1)
                    );
                    return None;
                }
            }
        };
        Some(Self {
            out: std::sync::Mutex::new(TraceWriter::spawn(out)),
            round: std::sync::Mutex::new((0, 0)),
        })
    }

    fn line(&self, text: String) {
        if let Ok(out) = self.out.lock() {
            out.send(text);
        }
    }
}

impl BurstObserver for TraceObserver {
    fn round_started(&self, fingerprint: TlsFingerprint, index: usize, total: usize, hosts: usize) {
        if let Ok(mut round) = self.round.lock() {
            *round = (index, total);
        }
        self.line(format!(
            "{}  round {}/{} {} ({}) hosts={hosts}",
            utc_clock(),
            index + 1,
            total,
            fingerprint.display_label(),
            fingerprint.code()
        ));
    }

    fn host_probed(&self, fingerprint: TlsFingerprint, domain: &str, report: &BurstProfileReport) {
        let (index, total) = self.round.lock().map(|r| *r).unwrap_or((0, 0));
        for (attempt, result) in report.attempts.iter().enumerate() {
            self.line(format!(
                "{}  r{}/{} {:<8} {:<28} #{:<2} {:<12} {:<40} {:>5} ms",
                utc_clock(),
                index + 1,
                total,
                fingerprint.code(),
                domain,
                attempt + 1,
                result.status.as_str(),
                result.detail.code(),
                result.ms,
            ));
        }
    }
}

/// UTC, because a timezone database is not worth carrying for a trace: the lines
/// only have to line up with each other and with the run.
fn utc_clock() -> String {
    let secs = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    format!("{:02}:{:02}:{:02}Z", (secs / 3600) % 24, (secs / 60) % 60, secs % 60)
}

/// The observers one run may have: the live line when the terminal can take one,
/// and the trace when `--trace` asked for it. Either may be absent, so neither
/// mode has to know about the other.
struct Observers<'a> {
    line: Option<&'a BurstLine>,
    trace: Option<&'a TraceObserver>,
}

impl BurstObserver for Observers<'_> {
    fn round_started(&self, fingerprint: TlsFingerprint, index: usize, total: usize, hosts: usize) {
        if let Some(line) = self.line {
            line.round_started(fingerprint, index, total, hosts);
        }
        if let Some(trace) = self.trace {
            trace.round_started(fingerprint, index, total, hosts);
        }
    }

    fn host_finished(&self) {
        if let Some(line) = self.line {
            line.host_finished();
        }
    }

    fn host_probed(&self, fingerprint: TlsFingerprint, domain: &str, report: &BurstProfileReport) {
        if let Some(trace) = self.trace {
            trace.host_probed(fingerprint, domain, report);
        }
    }
}

#[allow(
    clippy::too_many_arguments,
    reason = "one parameter per input the run needs; the shell holds each of them separately and a wrapper struct would only move the same list one level down"
)]
pub(crate) async fn run_test_suite(
    tests_str: &str,
    concurrency: usize,
    args: &CliArgs,
    cfg: &AppConfig,
    domains: &[String],
    tcp_items: &[dpi_core::config::Tcp16Target],
    whitelist_sni: &[(String, usize)],
    burst: &BurstPlan,
    msg: &Messages,
    profile: RegionProfile,
    lang: Language,
    badge: &str,
    intercept: Option<&dpi_core::net::netinfo::Intercept>,
    banner_done: bool,
    emitter: &mut Emitter,
) {
    let tests = crate::TestSelection::parse(tests_str);

    let mut results = crate::json::Results::default();

    if !args.json && !banner_done {
        emitter.emit(&render_banner(msg, profile, badge));
    }
    // What the run means depends on whether the bypass sees it, so this comes
    // before any result: a reader who sees only the tables must not have to
    // guess which of the two worlds they were measured in.
    if let Some(notice) = render_intercept_notice(msg, intercept) {
        emitter.emit(&notice);
    }

    let sem = Arc::new(Semaphore::new(concurrency.max(1)));
    // Live progress lines on a TTY only;
    // pipes and --json stay byte-clean.
    let live = LiveProgress::new();
    let phases: Option<PhaseProgress> = if !args.json && std::io::stderr().is_terminal() {
        let live_c = Arc::clone(&live);
        let live_b = Arc::clone(&live);
        let msg_copy = *msg;
        Some(PhaseProgress {
            on_phase: Arc::new(move |phase: dpi_core::PhaseId, total: usize| {
                // Stages of test 2 share one line, so a new stage advances its
                // own counter instead of starting a line of its own.
                if let Some(block) = phase.stage_block() {
                    live_c.set_total(block, total);
                    let tick_c = Arc::clone(&live_c);
                    let tick: ProgressTick = Arc::new(move || tick_c.bump(block));
                    return tick;
                }
                let desc = msg_copy.phase_text(phase);
                live_c.set(desc, total);
                let tick_c = Arc::clone(&live_c);
                let tick: ProgressTick = Arc::new(move || tick_c.tick());
                tick
            }),
            on_blocks: Arc::new(move |phase: dpi_core::PhaseId, blocks: &[(dpi_core::ProgressBlock, usize)]| {
                let desc = msg_copy.phase_text(phase);
                live_b.set_blocks(desc, blocks);
                let tick_c = Arc::clone(&live_b);
                let tick: dpi_core::BlockTick = Arc::new(move |block| tick_c.bump(block));
                tick
            }),
        })
    } else {
        None
    };
    let family = IpFamily::from_config(&cfg.ip_version);
    // The proxy is validated here, not carried further: test 1's DNS path parses
    // the same URL itself (`check_dns_availability`) and no other probe speaks
    // SOCKS. A URL the SOCKS5 code cannot use is a rejected input, so it has to
    // be readable in `--json` too, where the emitter writes nothing — the notice
    // goes to stderr there and stdout stays the machine document.
    if let Some(url) = cfg.effective_proxy() {
        if let Err(e) = parse_socks_proxy(url) {
            let notice = msg.invalid_proxy_err.replacen("{}", url, 1).replacen("{}", &e.to_string(), 1);
            emitter.emit(&notice);
            if args.json {
                eprint!("{}", notice);
            }
        }
    }

    let mut dns_stats = None;
    let mut dom_stats = None;
    let mut tcp_summary = None;
    let mut tg_full = None;

    // ── Test 0: network & system ──
    if tests.net {
        let spinner = (!args.json).then(|| Spinner::start(msg.fetching_net_info));
        // The cap must clear the inner budgets (3.5 s public-IP race then 5 s
        // Cymru, both bounding their whole fetch): with a smaller one a slow
        // but working network would print "network information unavailable"
        // instead of the panel with its red timeout rows.
        let net_data = tokio::time::timeout(Duration::from_secs(10), async {
            let ips = fetch_public_ips(
                &cfg.ip4_lookup_urls,
                &cfg.ip6_lookup_urls,
                Duration::from_millis(3500),
            )
            .await;
            let (v4_extra, v6_extra) = tokio::join!(
                async {
                    match ips.v4 {
                        Some((ip, _)) => {
                            fetch_ip_cymru(&IpAddr::V4(ip), &cfg.cymru_doh_servers, Duration::from_secs(5)).await
                        }
                        None => None,
                    }
                },
                async {
                    match ips.v6 {
                        Some((ip, _)) => {
                            fetch_ip_cymru(&IpAddr::V6(ip), &cfg.cymru_doh_servers, Duration::from_secs(5)).await
                        }
                        None => None,
                    }
                }
            );
            (ips, v4_extra, v6_extra)
        })
        .await;
        if let Some(s) = spinner {
            s.finish();
        }

        // Both of these shell out on Windows (`route print`, `tasklist`, 5 s
        // caps) and read the registry, so on the single-threaded runtime they
        // would block the worker — and the badge poll with it. They are
        // independent, so they run on the blocking pool together; a join error
        // only happens when the runtime is shutting down, and a default value
        // then says "unknown" rather than failing the run.
        let (mut dns_info, bypass) = {
            let signatures = cfg.bypass_tools();
            let dns = tokio::task::spawn_blocking(get_system_dns);
            let tools = tokio::task::spawn_blocking(move || detect_bypass_tools(&signatures));
            let (dns, tools) = tokio::join!(dns, tools);
            (dns.unwrap_or_default(), tools.unwrap_or_default())
        };

        if let Ok((ips, v4_extra, v6_extra)) = net_data {
            // Upstream router / VPN relay: whoami.akamai.net via local candidates.
            let mut candidates: Vec<IpAddr> = Vec::new();
            for (ip_str, _) in &dns_info.active {
                if let Ok(ip) = ip_str.parse::<IpAddr>() {
                    if domains::is_local_or_relay_ip(&ip) && !candidates.contains(&ip) {
                        candidates.push(ip);
                    }
                }
            }
            if let Some(gw) = dns_info.gateway {
                if domains::is_local_or_relay_ip(&gw) && !candidates.contains(&gw) {
                    candidates.push(gw);
                }
            }
            let mut upstream: Option<String> = None;
            for cand in &candidates {
                let server = SocketAddr::new(*cand, 53);
                if let Ok((addrs, _)) =
                    probe_udp_dns(server, "whoami.akamai.net", Duration::from_secs(2), None).await
                {
                    if let Some(up) = addrs.first() {
                        let mut text = up.to_string();
                        if let Some(extra) =
                            fetch_ip_cymru(up, &cfg.cymru_doh_servers, Duration::from_secs(5)).await
                        {
                            if let Some(org) = extra.org.as_ref() {
                                if !org.is_empty() {
                                    text += &format!(" ({})", org);
                                }
                            }
                        }
                        upstream = Some(text);
                        break;
                    }
                }
            }
            if let Some(up) = upstream {
                let a_name = dns_info.active_name.clone().unwrap_or_default();
                let label = if is_tun_name(&a_name) { msg.upstream_vpn } else { msg.router_resolver };
                dns_info.upstream = Some(up);
                dns_info.upstream_label = Some(label.to_string());
            }

            let v4 = family_info(ips.v4.map(|(ip, ms)| (IpAddr::V4(ip), ms)), v4_extra.clone());
            let v6 = ips.v6.map(|(ip, ms)| (IpAddr::V6(ip), ms));
            let v6 = family_info(v6, v6_extra);
            // Both lookups dead: both families render as the panel's red
            // timeout cells.
            let (v4, v6) = match (&v4, &v6) {
                (None, None) => (Some(timeout_family()), Some(timeout_family())),
                _ => (v4, v6),
            };
            let data = NetInfoData { v4, v6, empty: false };
            if !args.json {
                emitter.emit(&render_netinfo_panel(&data, &dns_info, &bypass, msg));
            } else {
                let mut tun: Vec<String> = Vec::new();
                if let Some(ref n) = dns_info.active_name {
                    if is_tun_name(n) && !tun.contains(n) {
                        tun.push(n.clone());
                    }
                }
                for (_, n) in &dns_info.other_static {
                    if is_tun_name(n) && !tun.contains(n) {
                        tun.push(n.clone());
                    }
                }
                let endpoint = |ip: Option<IpAddr>, latency_ms: Option<u64>| {
                    ip.zip(latency_ms)
                        .map(|(ip, latency_ms)| crate::json::Endpoint { ip: ip.to_string(), latency_ms })
                };
                results.network_info = Some(crate::json::NetworkInfo {
                    ipv4: endpoint(ips.v4.map(|(ip, _)| IpAddr::V4(ip)), ips.v4.map(|(_, lat)| lat)),
                    ipv6: endpoint(ips.v6.map(|(ip, _)| IpAddr::V6(ip)), ips.v6.map(|(_, lat)| lat)),
                    v4_asn: v4_extra.as_ref().map(|c| c.asn.clone()),
                    v4_org: v4_extra.as_ref().and_then(|c| c.org.clone()),
                    v4_cc: v4_extra.as_ref().and_then(|c| c.country.clone()),
                    upstream: dns_info.upstream.clone(),
                    system_dns: dns_info.nameservers.iter().map(|ip| ip.to_string()).collect(),
                    gateway: dns_info.gateway.map(|g| g.to_string()),
                    tun,
                    bypass_tools: bypass,
                });
            }
        } else if !args.json {
            emitter.emit(msg.net_info_unavailable);
        }

    }
    // ── Test 1: DNS availability ──
    if tests.dns {
        if cfg.availability_servers().is_empty() {
            if !args.json {
                emitter.emit(msg.dns_servers_empty_skip);
            }
        } else {
            let report = check_dns_availability(cfg, phases.clone(), concurrency).await;
            live.finish();
            if !args.json {
                emitter.emit(&render_dns_endpoints(&report, msg));
                emitter.emit(&render_dns_availability(&report, cfg, msg));
            } else {
                let s = &report.stats;
                results.dns_availability = Some(crate::json::DnsAvailability {
                    doh_ok: s.doh_ok,
                    doh_total: s.doh_total,
                    dot_ok: s.dot_ok,
                    dot_total: s.dot_total,
                    udp_ok: s.udp_ok,
                    udp_total: s.udp_total,
                    hijacked_brands: s.hijacked_brands.clone(),
                    resolvers_total: s.resolvers_total,
                    subst_sub: s.subst_sub,
                    subst_total: s.subst_total,
                    fakeip_sub: s.fakeip_sub,
                    failures: report
                        .endpoint_failures()
                        .into_iter()
                        .map(|f| crate::json::DnsEndpointFailure {
                            provider: f.provider,
                            protocol: f.kind.as_str(),
                            endpoint: f.endpoint,
                            ok: f.ok,
                            total: f.total,
                            status: f.reason.as_ref().map(|r| r.status.as_str()),
                            detail: f.reason.as_ref().map(|r| r.detail.code().into_owned()),
                        })
                        .collect(),
                });
            }
            dns_stats = Some(report.stats.clone());
        }
    }

    // ── Test 2: domains (resolve → TLS1.3 → TLS1.2 → HTTP) ──
    if tests.domains {
        if !args.json {
            emitter.emit(&format!(
                "\n{}  {}: {} | {}: {} | {}: {}s\n\n",
                msg.domains_check_header,
                msg.targets_label,
                domains.len(),
                msg.ip_col,
                if cfg.ip_version == "ipv6" { "IPv6" } else { "IPv4" },
                msg.timeout_label,
                cfg.timeout
            ));
        }
        // Silent stub collection with its own timeout.
        let stub_ips: HashSet<IpAddr> = tokio::time::timeout(
            Duration::from_secs_f64(cfg.stub_ips_timeout),
            collect_stub_ips(cfg),
        )
        .await
        .unwrap_or_default();

        // The hosts whose endpoint serves no HTTP/3: no Initial goes out for
        // them, their cell is a dash, and the QUIC column — the live line and the
        // summary alike — counts only the rows that can answer it.
        let quic_unsupported = load_quic_unsupported_list(cfg, msg);
        let quic_total = domains
            .iter()
            .filter(|d| domains::quic_applicable(d, &quic_unsupported))
            .count();

        // Every column is on the road from the first second: the five stages are
        // pipelined per domain, so there is no stage start to announce — the line
        // reads as one progressing run, not as five that scroll away.
        if !args.json {
            live.begin_stages(
                msg.stages_label.to_string(),
                &[
                    (dpi_core::ProgressBlock::DomainDns, domains.len()),
                    (dpi_core::ProgressBlock::DomainTls13, domains.len()),
                    (dpi_core::ProgressBlock::DomainTls12, domains.len()),
                    (dpi_core::ProgressBlock::DomainHttp, domains.len()),
                    (dpi_core::ProgressBlock::DomainQuic, quic_total),
                ],
            );
        }
        let entries =
            check_domains(domains, family, cfg, &stub_ips, &quic_unsupported, &sem, phases.clone()).await;
        live.finish();

        let stats = domain_stats(&entries);
        if !args.json {
            emitter.emit(&render_domain_table(&entries, msg));
            emitter.emit(&render_dns_resolve_notes(&entries, msg));
        } else {
            results.domain_inspection = Some(
                entries
                    .iter()
                    .map(|e| crate::json::DomainRow {
                        domain: e.domain.clone(),
                        resolved: e.resolved.map(|ip| ip.to_string()),
                        http: e.http.status.as_str(),
                        http_detail: e.http.detail.clone(),
                        tls12: e.t12.status.as_str(),
                        tls12_detail: e.t12.detail.clone(),
                        tls13: e.t13.status.as_str(),
                        tls13_detail: e.t13.detail.clone(),
                        quic: e.quic.status.as_str(),
                        quic_detail: e.quic.detail.clone(),
                    })
                    .collect(),
            );
        }
        dom_stats = Some(stats);
    }

    // ── Test 3: TCP 16–20 KB ──
    if tests.tcp {
        if !args.json {
            emitter.emit(&format!(
                "\n{}  {}: {} | {}: {}s\n",
                msg.tcp16_check_title,
                msg.targets_label,
                tcp_items.len(),
                msg.timeout_label,
                cfg.fat_connect_timeout
            ));
            emitter.emit(&format!("{}\n", msg.checking_status));
        }
        let mut rows: Vec<Tcp16Row> = Vec::new();
        let tcp_tick = phases
            .as_ref()
            .map(|p| (p.on_phase)(dpi_core::PhaseId::Tcp16, tcp_items.len()));
        let mut handles = Vec::new();
        // One config for every task instead of one per target: the shipped
        // config carries the whole DNS server list, and 104 clones of it were
        // alive at once while the tasks queued on the semaphore.
        let cfg_arc = Arc::new(cfg.clone());
        for item in tcp_items {
            let item = item.clone();
            let cfg_c = Arc::clone(&cfg_arc);
            let sem_c = Arc::clone(&sem);
            let tick = tcp_tick.clone();
            handles.push(tokio::spawn(async move {
                let port = item.port;
                let sni = if port == 80 {
                    String::new()
                } else {
                    item.sni.clone().unwrap_or_else(|| cfg_c.fat_default_sni.clone())
                };
                let t0 = Instant::now();
                let (status, detail, _rtt) =
                    check_tcp_16_20(&item.ip, port, &sni, &cfg_c, &sem_c, None).await;
                let elapsed = t0.elapsed().as_secs_f64();
                let detail = tcp16_detail(detail, elapsed);
                let asn_str = item.display_asn();
                // Ticked by the probe itself, never by the collector loop: the
                // counter is a live reading and a slow target must not hold it.
                if let Some(t) = tick.as_ref() {
                    t();
                }
                (item.id, asn_str, item.provider, status, detail)
            }));
        }
        for h in handles {
            if let Ok((id, asn, provider, status, detail)) = h.await {
                rows.push(Tcp16Row { id, asn, provider, status, detail });
            }
        }
        // The verdict tally, by the classifier's own predicates: the badge is a
        // Latin label, not a contract, and no status spells "mixed". Mixed is a
        // property of the run — part of the list answered, part was cut — so it
        // is read off the two totals and drives the warning under the table. A
        // timeout is neither: the probe never learned what happened there.
        let mut ok = 0usize;
        let mut blocked = 0usize;
        for row in &rows {
            if row.status.is_ok_status() {
                ok += 1;
            } else if row.status.is_blocked() {
                blocked += 1;
            }
        }
        let mixed = ok > 0 && blocked > 0;
        tcp_summary = Some((ok, blocked, usize::from(mixed), rows.len()));
        live.finish();
        if !args.json {
            emitter.emit(&render_tcp_table(&rows, msg));
        } else {
            results.tcp16 = Some(rows.clone());
        }
    }

    // ── Test 4: white SNI ──
    if tests.sni {
        if whitelist_sni.is_empty() {
            if !args.json {
                emitter.emit(msg.whitelist_skipped);
            }
        } else {
            let port443: Vec<_> = tcp_items.iter().filter(|t| t.port == 443).collect();
            if !args.json {
                let mut asns = std::collections::HashSet::new();
                for t in &port443 {
                    let k = t.asn.trim().to_uppercase();
                    asns.insert(if k.is_empty() { t.ip.clone() } else { k });
                }
                emitter.emit(&format!(
                    "\n{}  AS: {} | {}: {} | SNI: {} | {}: {}\n",
                    msg.menu_test_sni,
                    asns.len(),
                    msg.ip_col,
                    port443.len(),
                    whitelist_sni.len(),
                    msg.batch_label,
                    cfg.sni_batch_size
                ));
                emitter.emit(&format!("{}\n", msg.phase_sni_base));
            }
            let report = run_whitelist_sni(tcp_items, whitelist_sni, cfg, &sem, phases.clone()).await;
            live.finish();
            if !args.json {
                if report.detected_as > 0 {
                    let pmsg = msg.phase_sni_parallel
                        .replacen("{}", &report.detected_as.to_string(), 1)
                        .replacen("{}", &cfg.sni_batch_size.to_string(), 1)
                        .replacen("{}", &cfg.sni_top_n.to_string(), 1);
                    emitter.emit(&format!("{}\n\n", pmsg));
                }
                emitter.emit(&render_whitelist(&report, port443.len(), msg));
            } else {
                results.whitelist_sni = Some(crate::json::WhitelistSni {
                    detected_as: report.detected_as,
                    found_as: report.found_as,
                });
            }
        }
    }

    // ── Test 5: Telegram ──
    if tests.telegram {
        let rep = run_telegram_full(cfg, phases.clone()).await;
        live.finish();
        if !args.json {
            emitter.emit(&render_telegram(&rep, msg));
        } else {
            let transfer = |t: &dpi_core::probe::telegram::TransferStats| crate::json::Transfer {
                status: t.status,
                avg_bps: t.avg_bps,
                peak_bps: t.peak_bps,
                bytes: t.bytes_total,
                drop_at_sec: t.drop_at_sec,
            };
            results.telegram = Some(crate::json::Telegram {
                verdict: rep.verdict.clone(),
                download: transfer(&rep.download),
                upload: transfer(&rep.upload),
                dc_reachable: rep.dc_reachable,
                dc_total: rep.dc_total,
            });
        }
        tg_full = Some(rep);
    }

    // ── Test 6: fingerprint / Siberian blocking (overlapping handshakes) ──
    if tests.burst {
        let settings = &burst.settings;
        // Profile-major: `burst_targets` probes every target with the first
        // shape to the end before the next shape starts, so a block one shape
        // triggers can never be read as the other's result. The simultaneity the
        // test measures is *within* a host (its N handshakes all leave together);
        // hosts inside one shape overlap like any other phase of the suite.
        let targets: Vec<BurstTarget> = burst.targets.iter().map(BurstTarget::new).collect();
        // No banner and no header block: the test says what it is doing on one
        // live line that names the shape currently on the wire and how far the
        // run has got, and nothing else is printed until the table.
        let line = BurstLine { live: Arc::clone(&live), msg: *msg };
        let trace = TraceObserver::new(args.trace.as_deref(), msg);
        let observers = Observers {
            line: (!args.json && std::io::stderr().is_terminal()).then_some(&line),
            trace: trace.as_ref(),
        };
        let reports = burst_targets(cfg, &targets, settings, concurrency, &observers).await;
        if !args.json && std::io::stderr().is_terminal() {
            live.finish();
        }

        if !args.json {
            emitter.emit(&render_burst_table(&reports, settings, msg));
        } else {
            let domains_wire: Vec<crate::json::BurstDomain> = reports
                .iter()
                .map(|report| crate::json::BurstDomain {
                    domain: report.domain.clone(),
                    resolved: report.resolved.map(|ip| ip.to_string()),
                    profiles: report
                        .profiles
                        .iter()
                        .map(|profile| {
                            let failed = profile.attempts.iter().find(|a| !a.status.is_ok_status());
                            let stat = crate::json::BurstProfile {
                                answered: profile.answered(),
                                attempts: profile.attempts.len(),
                                statuses: profile.attempts.iter().map(|a| a.status.as_str()).collect(),
                                detail: failed.map(|a| a.detail.clone()).unwrap_or(Detail::None),
                            };
                            (profile.fingerprint.code().to_string(), stat)
                        })
                        .collect(),
                })
                .collect();
            results.fingerprint_burst = Some(crate::json::FingerprintBurst {
                attempts: settings.attempts,
                tls: settings.tls.code().to_string(),
                alpn: settings.alpn.token().to_string(),
                timeout_secs: settings.timeout.as_secs(),
                gap_ms: settings.launch_gap.as_millis() as u64,
                profiles: settings.profiles.iter().map(|f| f.code().to_string()).collect(),
                variant: settings.variant.as_ref().map(HelloVariant::name),
                domains: domains_wire,
            });
        }
    }

    // ── Test 7: legend ──
    if tests.legend && !args.json {
        print_out(&legend_text(lang, msg));
    }

    // ── Summary ──
    if !args.json {
        let summary = render_summary(
            &SummaryData {
                run_dns: tests.dns,
                dns: dns_stats.as_ref(),
                domains: dom_stats.as_ref(),
                tcp: tcp_summary,
                run_telegram: tests.telegram,
                telegram: tg_full.as_ref(),
            },
            msg,
        );
        if !summary.is_empty() {
            emitter.emit(&summary);
        }
    }

    if args.json {
        let payload = crate::json::Report {
            schema_version: crate::json::SCHEMA_VERSION,
            version: env!("CARGO_PKG_VERSION"),
            profile: profile.code(),
            tls_fingerprint: TlsFingerprint::from_config(cfg).code().to_string(),
            results,
        };
        let text = serde_json::to_string_pretty(&payload).unwrap_or_default();
        println!("{}", text);
        if let Some(out_path) = &args.output {
            // The document is already on stdout, so a failed save is a warning
            // and not a fatal error — but it cannot be silent: `--json` is the
            // mode nobody watches, and a script that asked for the file will
            // assume it is there. Same message as the interactive export
            // (`tui/screens/post_run.rs`), on stderr, so stdout stays
            // byte-identical.
            if let Err(err) = std::fs::write(out_path, &text) {
                eprintln!("{}", msg.report_save_fail.replace("{}", &err.to_string()));
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::i18n::get_messages;

    fn targets_arg(domain: &[&str], domains: Option<&std::path::Path>) -> CliArgs {
        CliArgs {
            domain: domain.iter().map(|d| d.to_string()).collect(),
            domains: domains.map(|p| p.to_string_lossy().into_owned()),
            ..CliArgs::default()
        }
    }

    /// A list the operator named *is* the run's target set, so an empty one is
    /// refused. It used to come back as `Ok(vec![])`: the run then probed
    /// nothing, printed a report of nothing and exited zero — which an operator
    /// reads as "nothing was blocked".
    #[test]
    fn an_empty_named_target_list_is_an_error() {
        let msg = get_messages(Language::En);
        let cfg = AppConfig::default();
        let profile = RegionProfile::Ru;

        // `-d ""` and `-d "   "`: `clean_domain` keeps neither.
        let err = load_domains(&targets_arg(&["", "   "], None), &cfg, profile, &msg).unwrap_err();
        assert_eq!(err.kind(), io::ErrorKind::InvalidInput, "{err}");
        assert!(err.to_string().contains("-d"), "the failed flag is named: {err}");

        // `--domains` on a file that reads but holds no domain (comments and
        // blank lines only) is the same empty run.
        let path = std::env::temp_dir().join("dpi-detector-empty-domains.txt");
        std::fs::write(&path, "# only a comment\n\n").unwrap();
        let err = load_domains(&targets_arg(&[], Some(&path)), &cfg, profile, &msg).unwrap_err();
        let _ = std::fs::remove_file(&path);
        assert_eq!(err.kind(), io::ErrorKind::InvalidInput, "{err}");
        assert!(
            err.to_string().contains("dpi-detector-empty-domains.txt"),
            "the failed file is named: {err}"
        );

        // A path that cannot be read keeps the OS error kind — the path is
        // folded into the message, and `main.rs` maps the kind to exit code 2.
        let missing = std::path::Path::new("/no/such/domains.txt");
        let err = load_domains(&targets_arg(&[], Some(missing)), &cfg, profile, &msg).unwrap_err();
        assert_eq!(err.kind(), io::ErrorKind::NotFound, "{err}");
        assert!(err.to_string().contains("/no/such/domains.txt"), "the failed file is named: {err}");

        // An entry that does clean is still the run's list: the check rejects an
        // empty result, not a list with anything left in it.
        let kept = load_domains(&targets_arg(&["Example.COM/some/path", "   "], None), &cfg, profile, &msg).unwrap();
        assert_eq!(kept, vec!["example.com".to_string()]);
    }
}

