use std::collections::HashMap;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use serde::{Deserialize, Serialize};

fn d_max_concurrent() -> usize { 50 }
fn d_ip_version() -> String { "ipv4".to_string() }
fn d_tls_fingerprint() -> String { "rustls".to_string() }
fn d_timeout() -> f64 { 8.0 }
fn d_pool_timeout() -> f64 { 2.0 }
fn d_stub_ips_timeout() -> f64 { 5.0 }
fn d_tcp_block_min_kb() -> u64 { 12 }
fn d_tcp_block_max_kb() -> u64 { 36 }
fn d_fat_default_sni() -> String { "example.com".to_string() }
fn d_fat_connect_timeout() -> f64 { 8.0 }
fn d_fat_read_timeout() -> f64 { 12.0 }
/// The placeholder `User-Agent` `config.yml` starts with.
///
/// It is not what the probes send:
/// [`crate::net::fingerprint::TlsFingerprint::user_agent_for`] hands the
/// selected fingerprint profile's own UA to a probe, and only an operator who
/// edited `user_agent` away from this value gets it on the wire.
pub const DEFAULT_USER_AGENT: &str =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36";

fn d_user_agent() -> String {
    DEFAULT_USER_AGENT.to_string()
}
fn d_dns_check_timeout() -> f64 { 5.0 }
fn d_dns_availability_timeout() -> f64 { 10.0 }
fn d_dns_egress_concurrency() -> usize { 10 }
fn d_dns_asn_concurrency() -> usize { 8 }
fn d_dns_stub_threshold() -> u32 { 2 }
fn d_fat_chunks_count() -> usize { 10 }
fn d_fat_chunk_size() -> usize { 4000 }
fn d_fat_chunk_delay() -> f64 { 0.05 }
fn d_fat_random_pool_size() -> usize { 100000 }
fn d_sni_batch_size() -> usize { 5 }
fn d_sni_top_n() -> usize { 3 }
fn d_telegram_media_url() -> String {
    "https://telegram.org/img/Telegram200million.png".to_string()
}
fn d_telegram_media_size_mb() -> f64 { 30.97 }
fn d_telegram_upload_ip() -> String { "149.154.167.220".to_string() }
fn d_telegram_upload_port() -> u16 { 443 }
fn d_telegram_upload_size_mb() -> f64 { 10.0 }
fn d_telegram_stall_timeout() -> f64 { 10.0 }
fn d_telegram_total_timeout() -> f64 { 60.0 }
fn d_telegram_dc_ping_timeout() -> f64 { 5.0 }
fn d_telegram_dc_port() -> u16 { 443 }
fn d_domains_file() -> String { "domains.txt".to_string() }
fn d_tcp16_file() -> String { "tcp16.json".to_string() }
fn d_whitelist_sni_file() -> String { "whitelist_sni.txt".to_string() }
fn d_quic_unsupported_file() -> String { "quic_unsupported.txt".to_string() }

fn d_dns_check_domains() -> Vec<String> {
    vec![
        "rutor.info".to_string(),
        "flibusta.is".to_string(),
        "clubtone.do.am".to_string(),
        "rezka.ag".to_string(),
        "shikimori.one".to_string(),
    ]
}

fn d_dns_udp_servers() -> Vec<Vec<String>> {
    vec![
        vec!["8.8.8.8".to_string(), "Google".to_string()],
        vec!["1.1.1.1".to_string(), "Cloudflare".to_string()],
        vec!["9.9.9.9".to_string(), "Quad9".to_string()],
        vec!["94.140.14.14".to_string(), "AdGuard".to_string()],
        vec!["77.88.8.8".to_string(), "Yandex".to_string()],
        vec!["223.5.5.5".to_string(), "Alibaba".to_string()],
        vec!["208.67.222.222".to_string(), "OpenDNS".to_string()],
        vec!["76.76.2.0".to_string(), "ControlD".to_string()],
        vec!["194.242.2.2".to_string(), "Mullvad".to_string()],
        vec!["185.228.168.9".to_string(), "CleanBrowsing".to_string()],
        vec!["76.76.19.19".to_string(), "Alternate DNS".to_string()],
        vec!["76.223.122.150".to_string(), "NextDNS".to_string()],
        vec!["185.222.222.222".to_string(), "DNS.SB".to_string()],
        vec!["176.9.93.198".to_string(), "dnsforge".to_string()],
        vec!["8.26.56.26".to_string(), "Comodo".to_string()],
        vec!["84.200.69.80".to_string(), "DNS Watch".to_string()],
        vec!["209.244.0.3".to_string(), "Level 3".to_string()],
    ]
}

fn d_dns_availability_domains() -> Vec<String> {
    vec!["vk.ru".to_string(), "gosuslugi.ru".to_string()]
}

fn d_cymru_doh_servers() -> Vec<String> {
    vec![
        "https://dns.google/dns-query".to_string(),
        "https://cloudflare-dns.com/dns-query".to_string(),
        "https://common.dot.dns.yandex.net/dns-query".to_string(),
        "https://dns.nextdns.io/dns-query".to_string(),
        "https://dns.opendns.com/dns-query".to_string(),
    ]
}

fn d_ip4_lookup_urls() -> Vec<String> {
    vec![
        // NOTE: api4/api.ipify.org removed: several RF ISPs spoof their DNS
        // to bogus 8.x addresses, so these endpoints can never win the race.
        // Uncomment them back on clean networks if needed.
        "https://v4.ident.me".to_string(),
        "https://ipv4.icanhazip.com".to_string(),
        // Last-resort plain HTTP: proven reachable on lines where all HTTPS
        // lookups are SNI-filtered (returns caller IP as plaintext).
        "http://v4.ident.me".to_string(),
    ]
}

fn d_ip6_lookup_urls() -> Vec<String> {
    vec![
        "https://api64.ipify.org".to_string(),
        "https://icanhazip.com".to_string(),
        "https://ifconfig.me/ip".to_string(),
        "https://v6.ident.me".to_string(),
    ]
}

fn d_concurrency_presets() -> Vec<usize> {
    vec![1, 5, 20, 50, 100]
}

fn d_bypass_tools() -> Vec<Vec<serde_yaml::Value>> {
    // (name, [patterns]) — defaults mirror config.yml BYPASS_TOOLS
    let raw = r#"
- ["zapret", ["nfqws", "tpws", "zapret", "dvtws", "dbproxy", "winws"]]
- ["GoodbyeDPI", ["goodbyedpi", "goodbye-dpi", "windivert"]]
- ["ByeDPI", ["byedpi"]]
- ["SpoofDPI", ["spoofdpi"]]
- ["DPI-Blocker", ["dpi-blocker", "dpiblocker"]]
- ["Green Tunnel", ["greentunnel", "green-tunnel"]]
- ["PowerTunnel", ["powertunnel"]]
- ["Hysteria2", ["hysteria"]]
- ["TROJAN", ["trojan"]]
- ["NaiveProxy", ["naive"]]
- ["Wstunnel", ["wstunnel"]]
- ["UDP2RAW", ["udp2raw"]]
- ["dnscrypt-proxy", ["dnscrypt-proxy"]]
- ["xray", ["xray"]]
- ["FlClashX", ["flclashx", "flclashcore"]]
- ["AmneziaWG", ["amneziawg"]]
- ["Clash", ["mihomo", "clash-meta", "clash-verge", "clash_verge", "verge-mihomo"]]
- ["sing-box", ["sing-box"]]
- ["Hiddify", ["hiddify"]]
- ["Tailscale", ["tailscale"]]
- ["ZeroTier", ["zerotier"]]
- ["Mullvad", ["mullvad"]]
- ["WARP", ["warp-svc", "cloudflarewarp"]]
- ["NordVPN", ["nordvpn"]]
"#;
    serde_yaml::from_str(raw).unwrap_or_default()
}

fn d_dns_known_resolver_names() -> Vec<String> {
    vec![
        // Egress-ASN tokens observed on real (non-hijacked) answers.
        "google", "cloudflarenet", "i3dnet", "cdn77", "alibaba-cn-net",
        "as-vultr", "cdnext", "xtom", "tencent-net-ap-cn", "misaka-cis-as",
        "as-anexia", "ru-jsciot", "yandex", "cisco", "woodynet",
        "e1-emea", "gtt-backbone", "level3", "firstcolo",
        // Resolver-brand tokens, substring-matched against the egress ASN name:
        // a whitelisted org is always green, even if a sibling endpoint
        // of the same brand was hijacked elsewhere.
        // NOTE: the "t2" token is deliberately omitted (2-char substring
        // matches too broadly and would whitelist hijacker ASNs).
        "cloudflare", "quad9", "adguard", "opendns", "cleanbrowsing",
        "nextdns", "controld", "mullvad", "dns0", "ahadns",
        "comss", "geohide",
    ]
    .into_iter()
    .map(|s| s.to_string())
    .collect()
}

fn d_dns_hijack_exempt_resolvers() -> Vec<String> {
    // The two domestic resolvers that *are* the stand-in: a run that meets them
    // is being intercepted, and the summary names them there as the host that
    // answered, not as a brand whose answers were replaced.
    ["MSK-IX", "НСДИ"].into_iter().map(|s| s.to_string()).collect()
}

fn d_telegram_dcs() -> Vec<Vec<String>> {
    vec![
        vec!["149.154.175.53".to_string(), "DC1".to_string()],
        vec!["149.154.167.51".to_string(), "DC2".to_string()],
        vec!["149.154.175.100".to_string(), "DC3".to_string()],
        vec!["149.154.167.91".to_string(), "DC4".to_string()],
        vec!["91.108.56.130".to_string(), "DC5".to_string()],
    ]
}

/// One DNS availability server entry: [address, name, kind, port?].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DnsAvailServer {
    pub addr: String,
    pub name: String,
    pub kind: DnsAvailServerKind,
    pub port: u16,
}

/// The transport a `DNS_AVAILABILITY_SERVERS` row names, in the four spellings
/// `config.yml` documents: `udp`, `doh_json`, `doh_wire`, `dot`.
///
/// Deliberately not `probe::dns_avail::ProbeKind`. That one is the measurement
/// vocabulary — a variant per probe path, and its `doh_wire` token is frozen
/// into `--json` — while `doh_json` and `doh_wire` here are two input
/// spellings of the same wire probe, and the report names both `doh_wire`.
/// Adding a `DohJson` variant there would either emit `doh_json` where the
/// report says `doh_wire` today, or make a JSON-DoH server report as a wire one
/// from a variant that claims otherwise.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DnsAvailServerKind {
    Udp,
    DohJson,
    DohWire,
    Dot,
}

impl DnsAvailServerKind {
    /// Parses a `config.yml` token, case-insensitively: `UDP` has always been
    /// accepted. `None` for anything else, which the row parser turns into a
    /// skipped row the loader names by key.
    pub fn parse(s: &str) -> Option<Self> {
        // ASCII compare rather than `to_lowercase()`: every token is ASCII and
        // no non-ASCII character lowercases to one of these letters, so this
        // accepts exactly the spellings the membership test did — without an
        // allocation on a path that runs once per shipped server row.
        if s.eq_ignore_ascii_case("udp") {
            Some(Self::Udp)
        } else if s.eq_ignore_ascii_case("doh_json") {
            Some(Self::DohJson)
        } else if s.eq_ignore_ascii_case("doh_wire") {
            Some(Self::DohWire)
        } else if s.eq_ignore_ascii_case("dot") {
            Some(Self::Dot)
        } else {
            None
        }
    }

    /// The `config.yml` spelling of this transport: the input contract, pinned
    /// by the test module so renaming a variant cannot silently change what an
    /// operator has to write.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Udp => "udp",
            Self::DohJson => "doh_json",
            Self::DohWire => "doh_wire",
            Self::Dot => "dot",
        }
    }

    /// The port a row of this kind uses when it names none.
    ///
    /// The measurement vocabulary (`probe::dns_avail::ProbeKind`) owns the same
    /// three numbers for the probes it runs, and the two are held together by
    /// `test_the_two_transport_tables_agree_on_their_ports` rather than by one
    /// calling the other: `config` is the layer the probes read, and a call the
    /// other way would close the loop the doctrine's layering forbids.
    pub fn default_port(self) -> u16 {
        match self {
            Self::Udp => 53,
            Self::DohJson | Self::DohWire => 443,
            Self::Dot => 853,
        }
    }
}

fn yaml_str(v: &serde_yaml::Value) -> Option<String> {
    match v {
        serde_yaml::Value::String(s) => Some(s.clone()),
        serde_yaml::Value::Number(n) => Some(n.to_string()),
        serde_yaml::Value::Bool(b) => Some(b.to_string()),
        _ => None,
    }
}

/// One `DNS_AVAILABILITY_SERVERS` row: `[addr, name, kind, port?]`. `None` for
/// a short row, a non-string column, a kind outside the four the probes know, or
/// a port column that cannot be dialled. The loader runs this same predicate to
/// warn about the rows it skips, so the two cannot drift apart.
fn parse_availability_row(row: &[serde_yaml::Value]) -> Option<DnsAvailServer> {
    let [addr_v, name_v, kind_v, rest @ ..] = row else {
        return None;
    };
    let addr = yaml_str(addr_v)?;
    let name = yaml_str(name_v)?;
    let kind = DnsAvailServerKind::parse(&yaml_str(kind_v)?)?;
    // Only an *absent* port column may mean "the default for this kind": that is
    // the shipped shape, 120 rows of it. A column that is present but says
    // something undiallable — not a number, past `u16`, or an explicit 0 — is a
    // different thing: the row would run against a port the operator never
    // wrote, and a `0` probe can only time out. Such a row is skipped rather
    // than quietly given the default, and the loader names the key.
    let port = match rest.first() {
        None => kind.default_port(),
        Some(v) => match yaml_str(v).and_then(|s| s.parse::<u16>().ok()) {
            Some(p) if p != 0 => p,
            _ => return None,
        },
    };
    Some(DnsAvailServer { addr, name, kind, port })
}

/// One `BYPASS_TOOLS` row: `[name, [patterns]]`. `None` for a short row, a
/// non-string name or a second column that is not a pattern list.
fn parse_bypass_row(row: &[serde_yaml::Value]) -> Option<(String, Vec<String>)> {
    let [name_v, patterns_v, ..] = row else {
        return None;
    };
    let name = yaml_str(name_v)?;
    let patterns = match patterns_v {
        serde_yaml::Value::Sequence(seq) => seq
            .iter()
            .filter_map(yaml_str)
            .map(|s| s.to_lowercase())
            .collect(),
        _ => return None,
    };
    Some((name, patterns))
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct AppConfig {
    #[serde(default = "d_max_concurrent")]
    pub max_concurrent: usize,
    #[serde(default = "d_ip_version")]
    pub ip_version: String,
    /// ClientHello shape the probes present: `rustls` (default, unchanged
    /// behaviour) or `firefox` (Firefox-shaped, for fingerprint A/B runs).
    #[serde(default = "d_tls_fingerprint")]
    pub tls_fingerprint: String,
    #[serde(default)]
    pub proxy_url: Option<String>,
    /// Legacy alias: CLI --proxy writes here; holds the same value as proxy_url.
    #[serde(default)]
    pub proxy: Option<String>,
    /// Seconds one phase of a probe waits, for every category that speaks to a
    /// peer: the connection, the reply that follows it, and the QUIC Initial's
    /// window. One number for HTTP, TLS 1.2, TLS 1.3 and QUIC rather than a
    /// separate read/write pair, and the value the menu's Timeout row steps
    /// through, one second at a time from 1 to 60.
    ///
    /// A probe's own worst case is twice this: the connection and the reply are
    /// two phases, each bounded by it. Short enough that a silent target does
    /// not hold the run, generous enough for a router link.
    #[serde(default = "d_timeout")]
    pub timeout: f64,
    #[serde(default = "d_pool_timeout")]
    pub pool_timeout: f64,
    #[serde(default = "d_stub_ips_timeout")]
    pub stub_ips_timeout: f64,
    #[serde(default = "d_tcp_block_min_kb")]
    pub tcp_block_min_kb: u64,
    #[serde(default = "d_tcp_block_max_kb")]
    pub tcp_block_max_kb: u64,
    #[serde(default = "d_fat_default_sni")]
    pub fat_default_sni: String,
    #[serde(default = "d_fat_connect_timeout")]
    pub fat_connect_timeout: f64,
    #[serde(default = "d_fat_read_timeout")]
    pub fat_read_timeout: f64,
    #[serde(default = "d_user_agent")]
    pub user_agent: String,
    #[serde(default = "d_dns_check_timeout")]
    pub dns_check_timeout: f64,
    #[serde(default = "d_dns_availability_timeout")]
    pub dns_availability_timeout: f64,
    #[serde(default = "d_dns_check_domains")]
    pub dns_check_domains: Vec<String>,
    /// Domain → real IPs, used only where the live DoH/DoT truth is empty
    /// (a network that blocks every encrypted resolver).
    #[serde(default)]
    pub dns_truth_fallback: HashMap<String, Vec<String>>,
    #[serde(default = "d_dns_udp_servers")]
    pub dns_udp_servers: Vec<Vec<String>>,
    #[serde(default = "d_dns_availability_domains")]
    pub dns_availability_domains: Vec<String>,
    /// Raw server rows: [addr, name, kind, port?]. Parsed via `availability_servers()`.
    #[serde(default)]
    pub dns_availability_servers: Vec<Vec<serde_yaml::Value>>,
    #[serde(default = "d_dns_egress_concurrency")]
    pub dns_egress_concurrency: usize,
    #[serde(default = "d_dns_asn_concurrency")]
    pub dns_asn_concurrency: usize,
    #[serde(default = "d_dns_stub_threshold")]
    pub dns_stub_threshold: u32,
    #[serde(default = "d_fat_chunks_count")]
    pub fat_chunks_count: usize,
    #[serde(default = "d_fat_chunk_size")]
    pub fat_chunk_size: usize,
    #[serde(default = "d_fat_chunk_delay")]
    pub fat_chunk_delay: f64,
    #[serde(default = "d_fat_random_pool_size")]
    pub fat_random_pool_size: usize,
    #[serde(default = "d_sni_batch_size")]
    pub sni_batch_size: usize,
    #[serde(default = "d_sni_top_n")]
    pub sni_top_n: usize,
    #[serde(default = "d_telegram_media_url")]
    pub telegram_media_url: String,
    #[serde(default = "d_telegram_media_size_mb")]
    pub telegram_media_size_mb: f64,
    #[serde(default = "d_telegram_upload_ip")]
    pub telegram_upload_ip: String,
    #[serde(default = "d_telegram_upload_port")]
    pub telegram_upload_port: u16,
    #[serde(default = "d_telegram_upload_size_mb")]
    pub telegram_upload_size_mb: f64,
    #[serde(default = "d_telegram_stall_timeout")]
    pub telegram_stall_timeout: f64,
    #[serde(default = "d_telegram_total_timeout")]
    pub telegram_total_timeout: f64,
    #[serde(default = "d_telegram_dc_ping_timeout")]
    pub telegram_dc_ping_timeout: f64,
    #[serde(default = "d_telegram_dc_port")]
    pub telegram_dc_port: u16,
    #[serde(default = "d_telegram_dcs")]
    pub telegram_dcs: Vec<Vec<String>>,
    #[serde(default = "d_concurrency_presets")]
    pub concurrency_presets: Vec<usize>,
    /// Raw rows: `[name, [patterns]]`. Parsed via `bypass_tools()`.
    ///
    /// `from_yaml_str` lowercases every key before deserializing, and the field
    /// is the one place where the struct name does not match its key: without
    /// the rename, `BYPASS_TOOLS` became `bypass_tools`, matched no field, and
    /// was dropped in silence — the default mirrored `config.yml`, so an edit
    /// to the key never took effect and nothing said so. Deserialize-only, so
    /// the serialized name stays as it is.
    #[serde(default = "d_bypass_tools", rename(deserialize = "bypass_tools"))]
    pub bypass_tools_raw: Vec<Vec<serde_yaml::Value>>,
    #[serde(default = "d_dns_known_resolver_names")]
    pub dns_known_resolver_names: Vec<String>,
    /// Resolvers that are themselves the host other brands' answers come back
    /// from, so a run must not name them as victims of the substitution.
    #[serde(default = "d_dns_hijack_exempt_resolvers")]
    pub dns_hijack_exempt_resolvers: Vec<String>,
    #[serde(default = "d_cymru_doh_servers")]
    pub cymru_doh_servers: Vec<String>,
    #[serde(default = "d_ip4_lookup_urls")]
    pub ip4_lookup_urls: Vec<String>,
    #[serde(default = "d_ip6_lookup_urls")]
    pub ip6_lookup_urls: Vec<String>,
    #[serde(default = "d_domains_file")]
    pub domains_file: String,
    #[serde(default = "d_tcp16_file")]
    pub tcp16_file: String,
    #[serde(default = "d_whitelist_sni_file")]
    pub whitelist_sni_file: String,
    /// Hosts whose endpoint serves no HTTP/3 (`quic_unsupported.txt`): test 2
    /// does not probe their QUIC column and the summary counts the column out of
    /// the rows that can answer it.
    #[serde(default = "d_quic_unsupported_file")]
    pub quic_unsupported_file: String,
    #[serde(default)]
    pub debug: bool,
    #[serde(skip)]
    pub config_load_error: Option<String>,
    #[serde(skip)]
    pub config_warnings: Vec<ConfigWarning>,
}

/// A recoverable `config.yml` problem. The core reports the fact; the wording
/// lives in the binary's `i18n` layer, so warnings follow `--lang`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConfigWarning {
    /// Key rejected by the type/shape check: the value was dropped and the
    /// default applies.
    InvalidValue { key: String },
    /// A row-list key kept its valid rows and dropped the rest.
    ///
    /// Separate from `InvalidValue` because that message ends "using default",
    /// which is false here: a list where 119 of 120 rows survived would read as
    /// "the whole list was discarded", and the operator would stop looking for
    /// the one row that never ran.
    SkippedRows { key: String },
    /// Key that is not part of the schema.
    UnknownKey { key: String },
    UnknownFingerprint { value: String },
    MaxConcurrentReset,
    IpVersionReset,
    StubThresholdReset,
    UploadPortReset,
    DcPortReset,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            max_concurrent: d_max_concurrent(),
            ip_version: d_ip_version(),
            tls_fingerprint: d_tls_fingerprint(),
            proxy_url: None,
            proxy: None,
            timeout: d_timeout(),
            pool_timeout: d_pool_timeout(),
            stub_ips_timeout: d_stub_ips_timeout(),
            tcp_block_min_kb: d_tcp_block_min_kb(),
            tcp_block_max_kb: d_tcp_block_max_kb(),
            fat_default_sni: d_fat_default_sni(),
            fat_connect_timeout: d_fat_connect_timeout(),
            fat_read_timeout: d_fat_read_timeout(),
            user_agent: d_user_agent(),
            dns_check_timeout: d_dns_check_timeout(),
            dns_availability_timeout: d_dns_availability_timeout(),
            dns_check_domains: d_dns_check_domains(),
            dns_truth_fallback: HashMap::new(),
            dns_udp_servers: d_dns_udp_servers(),
            dns_availability_domains: d_dns_availability_domains(),
            dns_availability_servers: Vec::new(),
            dns_egress_concurrency: d_dns_egress_concurrency(),
            dns_asn_concurrency: d_dns_asn_concurrency(),
            dns_stub_threshold: d_dns_stub_threshold(),
            fat_chunks_count: d_fat_chunks_count(),
            fat_chunk_size: d_fat_chunk_size(),
            fat_chunk_delay: d_fat_chunk_delay(),
            fat_random_pool_size: d_fat_random_pool_size(),
            sni_batch_size: d_sni_batch_size(),
            sni_top_n: d_sni_top_n(),
            telegram_media_url: d_telegram_media_url(),
            telegram_media_size_mb: d_telegram_media_size_mb(),
            telegram_upload_ip: d_telegram_upload_ip(),
            telegram_upload_port: d_telegram_upload_port(),
            telegram_upload_size_mb: d_telegram_upload_size_mb(),
            telegram_stall_timeout: d_telegram_stall_timeout(),
            telegram_total_timeout: d_telegram_total_timeout(),
            telegram_dc_ping_timeout: d_telegram_dc_ping_timeout(),
            telegram_dc_port: d_telegram_dc_port(),
            telegram_dcs: d_telegram_dcs(),
            concurrency_presets: d_concurrency_presets(),
            bypass_tools_raw: d_bypass_tools(),
            dns_known_resolver_names: d_dns_known_resolver_names(),
            dns_hijack_exempt_resolvers: d_dns_hijack_exempt_resolvers(),
            cymru_doh_servers: d_cymru_doh_servers(),
            ip4_lookup_urls: d_ip4_lookup_urls(),
            ip6_lookup_urls: d_ip6_lookup_urls(),
            domains_file: d_domains_file(),
            tcp16_file: d_tcp16_file(),
            whitelist_sni_file: d_whitelist_sni_file(),
            quic_unsupported_file: d_quic_unsupported_file(),
            debug: false,
            config_load_error: None,
            config_warnings: Vec::new(),
        }
    }
}

const KNOWN_KEYS: &[&str] = &[
    "MAX_CONCURRENT", "IP_VERSION", "TLS_FINGERPRINT", "PROXY_URL", "TIMEOUT",
    "POOL_TIMEOUT", "STUB_IPS_TIMEOUT", "TCP_BLOCK_MIN_KB", "TCP_BLOCK_MAX_KB",
    "FAT_DEFAULT_SNI", "FAT_CONNECT_TIMEOUT", "FAT_READ_TIMEOUT", "USER_AGENT",
    "WSAECONNRESET", "WSAECONNREFUSED", "WSAETIMEDOUT", "WSAENETUNREACH",
    "WSAEHOSTUNREACH", "WSAECONNABORTED", "DNS_CHECK_TIMEOUT", "DNS_AVAILABILITY_TIMEOUT",
    "DNS_CHECK_DOMAINS", "DNS_TRUTH_FALLBACK", "DNS_UDP_SERVERS",
    "DNS_AVAILABILITY_DOMAINS", "DNS_AVAILABILITY_SERVERS",
    "DNS_EGRESS_CONCURRENCY", "DNS_ASN_CONCURRENCY",
    "ASN_CACHE_FILE", "FAT_CHUNKS_COUNT", "FAT_CHUNK_SIZE", "FAT_CHUNK_DELAY",
    "FAT_RANDOM_POOL_SIZE", "SNI_BATCH_SIZE", "SNI_TOP_N", "TELEGRAM_MEDIA_URL",
    "TELEGRAM_MEDIA_SIZE_MB", "TELEGRAM_UPLOAD_IP", "TELEGRAM_UPLOAD_PORT",
    "TELEGRAM_UPLOAD_SIZE_MB", "TELEGRAM_STALL_TIMEOUT", "TELEGRAM_TOTAL_TIMEOUT",
    "TELEGRAM_DC_PING_TIMEOUT", "TELEGRAM_DC_PORT", "TELEGRAM_DCS", "PIN_CACHE_MAX",
    "PIN_CACHE_TTL", "CONCURRENCY_PRESETS", "BYPASS_TOOLS", "DNS_KNOWN_RESOLVER_NAMES",
    "DNS_HIJACK_EXEMPT_RESOLVERS",
    "DNS_STUB_THRESHOLD", "DEBUG", "CYMRU_DOH_SERVERS", "IP4_LOOKUP_URLS",
    "IP6_LOOKUP_URLS", "IP_LOOKUP_URLS",
];

/// True when `value` can be an HTTP header value: `http` refuses every control
/// byte except tab and refuses 0x7F. Obs-text (≥ 0x80) stays valid, so a
/// Cyrillic user agent is not rejected.
///
/// The user agent is the only config string that reaches a request header, and
/// `net/http.rs` builds that request with an `expect`: one control byte from
/// a `USER_AGENT: |` block scalar would abort the whole run. The request
/// boundary keeps its own guard as a backstop; this is what names the key the
/// operator has to fix.
fn valid_header_value(value: &str) -> bool {
    value.bytes().all(|b| !b.is_ascii_control() || b == b'\t')
}

/// The shape a `DNS_UDP_SERVERS` / `TELEGRAM_DCS` row must have: at least two
/// string columns.
fn valid_pair_row(cols: &[serde_yaml::Value]) -> bool {
    cols.len() >= 2 && cols.iter().all(|c| c.as_str().is_some())
}

/// True when `v` is a row sequence holding at least one row the list parser
/// skips. Such a row is reported, never dropped in silence: these lists are
/// edited by hand, and a row shortened by an edit would otherwise never run and
/// never say so. The rows stay in the mapping — the parsers are what skip them.
fn has_skipped_rows(v: &serde_yaml::Value, valid: impl Fn(&[serde_yaml::Value]) -> bool) -> bool {
    match v {
        serde_yaml::Value::Sequence(rows) => rows.iter().any(|r| match r {
            serde_yaml::Value::Sequence(cols) => !valid(cols),
            _ => true,
        }),
        _ => false,
    }
}

/// Per-key type validation: a mistyped value is dropped so its default
/// survives, and a warning names the key. Without this, one bad scalar fails
/// the whole serde mapping and resets everything.
fn sanitize_mapping(mapping: &mut serde_yaml::Mapping, warnings: &mut Vec<ConfigWarning>) {
    let is_uint = |v: &serde_yaml::Value| v.as_u64().is_some();
    let is_num = |v: &serde_yaml::Value| v.as_u64().is_some() || v.as_f64().is_some();
    // Keys are compared case-insensitively, so a lowercase spelling of a
    // canonical UPPER_SNAKE key still matches its validator.
    let up = |k: &serde_yaml::Value| k.as_str().map(|s| s.to_uppercase());
    let mut drop_keys: Vec<serde_yaml::Value> = Vec::new();
    for (k, v) in mapping.iter_mut() {
        let key = match up(k) {
            Some(s) => s,
            None => continue,
        };
        let ok = match key.as_str() {
            "MAX_CONCURRENT" | "DNS_EGRESS_CONCURRENCY" | "DNS_ASN_CONCURRENCY"
            | "FAT_CHUNKS_COUNT" | "FAT_CHUNK_SIZE" | "FAT_RANDOM_POOL_SIZE"
            | "SNI_BATCH_SIZE" | "SNI_TOP_N" | "TCP_BLOCK_MIN_KB" | "TCP_BLOCK_MAX_KB" => {
                is_uint(v)
            }
            "TELEGRAM_UPLOAD_PORT" | "TELEGRAM_DC_PORT" => {
                v.as_u64().is_some_and(|p| (1..=65535).contains(&p))
            }
            "DNS_STUB_THRESHOLD" => v.as_u64().is_some_and(|t| (1..=50).contains(&t)),
            "TIMEOUT" | "POOL_TIMEOUT" | "STUB_IPS_TIMEOUT"
            | "DNS_CHECK_TIMEOUT" | "DNS_AVAILABILITY_TIMEOUT" | "FAT_CONNECT_TIMEOUT"
            | "FAT_READ_TIMEOUT" | "FAT_CHUNK_DELAY" | "TELEGRAM_MEDIA_SIZE_MB"
            | "TELEGRAM_UPLOAD_SIZE_MB" | "TELEGRAM_STALL_TIMEOUT" | "TELEGRAM_TOTAL_TIMEOUT"
            | "TELEGRAM_DC_PING_TIMEOUT" => {
                if !is_num(v) || v.as_f64().is_none_or(|f| f <= 0.0) {
                    false
                } else {
                    // Normalize ints (e.g. `TIMEOUT: 15`) to f64 so the
                    // f64 struct field deserializes instead of failing the file.
                    if v.as_u64().is_some() {
                        if let Some(f) = v.as_f64() {
                            *v = serde_yaml::Value::Number(serde_yaml::Number::from(f));
                        }
                    }
                    true
                }
            }
            "IP_VERSION" => matches!(v.as_str(), Some("ipv4") | Some("ipv6")),
            // The UA is validated as a header value, not merely as a string:
            // an unusable one is dropped like a mistyped number, so the
            // built-in default survives and `user_agent_for` falls back to the
            // fingerprint's own UA. A valid value still wins over that default.
            "USER_AGENT" => v.as_str().is_some_and(valid_header_value),
            "FAT_DEFAULT_SNI" | "TELEGRAM_MEDIA_URL" | "TELEGRAM_UPLOAD_IP" => {
                v.as_str().is_some()
            }
            "PROXY_URL" | "ASN_CACHE_FILE" => v.is_null() || v.as_str().is_some(),
            "DEBUG" => v.as_bool().is_some(),
            // Domain → IP list: drop rows that are not `name: [ip, ...]`.
            "DNS_TRUTH_FALLBACK" => match v {
                serde_yaml::Value::Mapping(map) => {
                    let bad: Vec<serde_yaml::Value> = map
                        .iter()
                        .filter(|(k, val)| {
                            k.as_str().is_none()
                                || !matches!(val, serde_yaml::Value::Sequence(s) if s.iter().all(|e| e.as_str().is_some()))
                        })
                        .map(|(k, _)| k.clone())
                        .collect();
                    for k in bad {
                        map.remove(&k);
                    }
                    true
                }
                _ => false,
            },
            // String lists: keep string elements only; a non-string element is
            // dropped from the sequence, not treated as a fatal error.
            "DNS_CHECK_DOMAINS" | "DNS_AVAILABILITY_DOMAINS" | "DNS_KNOWN_RESOLVER_NAMES"
            | "DNS_HIJACK_EXEMPT_RESOLVERS"
            | "CYMRU_DOH_SERVERS" | "IP4_LOOKUP_URLS" | "IP6_LOOKUP_URLS" | "IP_LOOKUP_URLS" => {
                match v {
                    serde_yaml::Value::Sequence(seq) => {
                        seq.retain(|e| e.as_str().is_some());
                        true
                    }
                    _ => false,
                }
            }
            // Pair lists: keep [str, str, ...] rows with ≥2 columns.
            "DNS_UDP_SERVERS" => match v {
                serde_yaml::Value::Sequence(rows) => {
                    let before = rows.len();
                    rows.retain(|r| matches!(r, serde_yaml::Value::Sequence(cols) if valid_pair_row(cols)));
                    if rows.len() != before {
                        warnings.push(ConfigWarning::SkippedRows { key: key.clone() });
                    }
                    true
                }
                _ => false,
            },
            // Same shape, but `telegram_dc_list` reads these rows: a dropped row
            // would silently lose a DC, so the key is named instead.
            "TELEGRAM_DCS" => match v {
                serde_yaml::Value::Sequence(rows) => {
                    let before = rows.len();
                    rows.retain(|r| matches!(r, serde_yaml::Value::Sequence(cols) if valid_pair_row(cols)));
                    if rows.len() != before {
                        warnings.push(ConfigWarning::SkippedRows { key: key.clone() });
                    }
                    true
                }
                _ => false,
            },
            // Row lists the parsers skip row-by-row: report the skip by key, so
            // a hand-edit that never ran is not mistaken for one that passed.
            "DNS_AVAILABILITY_SERVERS" => {
                if has_skipped_rows(v, |cols| parse_availability_row(cols).is_some()) {
                    warnings.push(ConfigWarning::SkippedRows { key: key.clone() });
                }
                true
            }
            "BYPASS_TOOLS" => {
                if has_skipped_rows(v, |cols| parse_bypass_row(cols).is_some()) {
                    warnings.push(ConfigWarning::SkippedRows { key: key.clone() });
                }
                true
            }
            _ => true,
        };
        if !ok {
            warnings.push(ConfigWarning::InvalidValue { key: key.clone() });
            drop_keys.push(k.clone());
        }
    }
    for k in &drop_keys {
        mapping.remove(k);
    }
}

impl AppConfig {
    /// Parses `config.yml` content. Unknown keys and mistyped values produce
    /// warnings; a parse error, a non-mapping root, or a mapping serde rejects
    /// after the sanitizer has run is recorded in `config_load_error` instead —
    /// never swallowed, because the fallback is the whole built-in config.
    /// A configuration with every field at its serde default. Every field of
    /// this struct carries a default, so an empty mapping parses — a failure
    /// here would be a bug in the struct definition, not in the input.
    fn defaults() -> Self {
        serde_yaml::from_str("{}").expect("an empty mapping parses into the serde defaults")
    }

    #[must_use = "the returned config carries the sanitized values and every collected warning"]
    pub fn from_yaml_str(content: &str) -> Self {
        let value: serde_yaml::Value = match serde_yaml::from_str(content) {
            Ok(v) => v,
            Err(e) => {
                let mut cfg = Self::defaults();
                cfg.config_load_error = Some(format!("config.yml parse error: {}", e));
                return cfg;
            }
        };
        let mut mapping = match value.as_mapping() {
            Some(m) => m.clone(),
            None => {
                let mut cfg = Self::defaults();
                cfg.config_load_error = Some("config.yml root is not a mapping".to_string());
                return cfg;
            }
        };

        let mut warnings: Vec<ConfigWarning> = Vec::new();
        for key in mapping.keys() {
            if let Some(k) = key.as_str() {
                let upper = k.to_uppercase();
                if !KNOWN_KEYS.contains(&upper.as_str()) {
                    warnings.push(ConfigWarning::UnknownKey { key: k.to_string() });
                }
            }
        }
        sanitize_mapping(&mut mapping, &mut warnings);
        // IP_LOOKUP_URLS compat: the v4 lookup falls back to the shared list
        // when IP4_LOOKUP_URLS is absent. v6 keeps its own default.
        let has_ip4 = mapping
            .keys()
            .any(|k| k.as_str().is_some_and(|s| s.eq_ignore_ascii_case("IP4_LOOKUP_URLS")));
        if !has_ip4 {
            let compat = mapping.iter().find_map(|(k, v)| {
                if k.as_str().is_some_and(|s| s.eq_ignore_ascii_case("IP_LOOKUP_URLS"))
                    && v.is_sequence()
                {
                    Some(v.clone())
                } else {
                    None
                }
            });
            if let Some(urls) = compat {
                mapping.insert(
                    serde_yaml::Value::String("IP4_LOOKUP_URLS".to_string()),
                    urls,
                );
            }
        }

        // Normalize keys to lowercase struct fields
        let mut norm = serde_yaml::Mapping::new();
        for (k, v) in mapping {
            if let Some(ks) = k.as_str() {
                norm.insert(
                    serde_yaml::Value::String(ks.to_lowercase()),
                    v.clone(),
                );
            }
        }
        let mut cfg: Self = match serde_yaml::from_value(serde_yaml::Value::Mapping(norm)) {
            Ok(cfg) => cfg,
            Err(e) => {
                // The mapping survived `sanitize_mapping` and serde still refused
                // it. The two row-list arms above report a bad row and keep it —
                // a row that is not a sequence, or a scalar for the key itself,
                // cannot deserialize into `Vec<Vec<serde_yaml::Value>>` — so the
                // fallback here replaces every setting in the file with the
                // shipped ones. Recording the reason is what keeps that from
                // being silent: without it the operator reads "one row skipped"
                // while their proxy, timeouts and server lists are gone.
                let mut cfg = Self::defaults();
                cfg.config_load_error =
                    Some(format!("config.yml could not be applied: {}", e));
                cfg
            }
        };
        cfg.config_warnings = warnings;
        cfg.clamp();
        cfg
    }

    fn clamp(&mut self) {
        // These resets keep their integer types instead of parsing into
        // `NonZero*`: a zero here is a legitimate input — an operator typo —
        // whose whole point is to be named and recovered from, which the
        // warnings below do in four languages. A non-zero type would instead
        // fail the whole serde mapping, so one zero would silently reset every
        // other key in the file and take the diagnostic with it.
        if self.max_concurrent < 1 {
            self.max_concurrent = 50;
            self.config_warnings.push(ConfigWarning::MaxConcurrentReset);
        }
        if self.ip_version != "ipv4" && self.ip_version != "ipv6" {
            self.ip_version = "ipv4".to_string();
            self.config_warnings.push(ConfigWarning::IpVersionReset);
        }
        if crate::net::fingerprint::TlsFingerprint::parse(&self.tls_fingerprint).is_none() {
            self.config_warnings.push(ConfigWarning::UnknownFingerprint {
                value: self.tls_fingerprint.clone(),
            });
            self.tls_fingerprint = d_tls_fingerprint();
        }
        if !(1..=50).contains(&self.dns_stub_threshold) {
            self.dns_stub_threshold = 2;
            self.config_warnings.push(ConfigWarning::StubThresholdReset);
        }
        if self.telegram_upload_port == 0 {
            self.telegram_upload_port = 443;
            self.config_warnings.push(ConfigWarning::UploadPortReset);
        }
        if self.telegram_dc_port == 0 {
            self.telegram_dc_port = 443;
            self.config_warnings.push(ConfigWarning::DcPortReset);
        }
        if self.fat_chunks_count < 1 {
            self.fat_chunks_count = 10;
        }
        if self.fat_chunk_size < 1 {
            self.fat_chunk_size = 4000;
        }
    }

    /// Effective proxy URL (CLI --proxy wins over config file).
    pub fn effective_proxy(&self) -> Option<&str> {
        self.proxy
            .as_deref()
            .or(self.proxy_url.as_deref())
    }

    /// Parsed availability servers, skipping malformed rows. `sanitize_mapping`
    /// warns about every row this skips, so one cannot vanish in silence.
    pub fn availability_servers(&self) -> Vec<DnsAvailServer> {
        self.dns_availability_servers
            .iter()
            .filter_map(|row| parse_availability_row(row))
            .collect()
    }

    /// Parsed bypass tools: (display name, lowercase patterns). Same warning as
    /// [`Self::availability_servers`] for the rows this skips.
    pub fn bypass_tools(&self) -> Vec<(String, Vec<String>)> {
        self.bypass_tools_raw
            .iter()
            .filter_map(|row| parse_bypass_row(row))
            .collect()
    }

    /// Telegram DC list as (ip, label).
    pub fn telegram_dc_list(&self) -> Vec<(String, String)> {
        self.telegram_dcs
            .iter()
            .filter_map(|row| {
                // Pattern-bound columns: a row without both fields is skipped,
                // never indexed past its end.
                let [ip, label, ..] = row.as_slice() else { return None };
                Some((ip.clone(), label.clone()))
            })
            .collect()
    }
}

/// Shipped lists embedded into the binary (workspace-root config.yml,
/// domains.txt, burst-domains.txt, tcp16.json, whitelist_sni.txt,
/// quic_unsupported.txt). External
/// files (cwd, then exe dir) win when present; the embedded copies keep the
/// standalone binary fully working from any directory, including routers.
pub const EMBEDDED_CONFIG_YML: &str = include_str!("../../../config.yml");
const EMBEDDED_DOMAINS_TXT: &str = include_str!("../../../domains.txt");
const EMBEDDED_BURST_DOMAINS_TXT: &str = include_str!("../../../burst-domains.txt");
const EMBEDDED_TCP16_JSON: &str = include_str!("../../../tcp16.json");
const EMBEDDED_WHITELIST_SNI_TXT: &str = include_str!("../../../whitelist_sni.txt");
const EMBEDDED_QUIC_UNSUPPORTED_TXT: &str = include_str!("../../../quic_unsupported.txt");

/// Locates config.yml: current dir first, then executable dir; `None` when
/// neither has one.
pub fn find_config_file() -> Option<PathBuf> {
    let cwd = Path::new("config.yml");
    if cwd.exists() {
        return Some(cwd.to_path_buf());
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            let p = dir.join("config.yml");
            if p.exists() {
                return Some(p);
            }
        }
    }
    None
}

/// Loads config.yml if present, otherwise the embedded copy. A file that cannot
/// be read is reported through `config_load_error`.
pub fn load_config() -> AppConfig {
    match find_config_file() {
        Some(path) => match fs::read_to_string(&path) {
            Ok(content) => AppConfig::from_yaml_str(&content),
            Err(e) => AppConfig {
                config_load_error: Some(format!("cannot read {}: {}", path.display(), e)),
                ..AppConfig::default()
            },
        },
        // No external file: the lists shipped inside the binary keep it working.
        None => AppConfig::from_yaml_str(EMBEDDED_CONFIG_YML),
    }
}

/// Directory of the running binary, or `.` when it cannot be resolved.
pub fn base_dir() -> PathBuf {
    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            return dir.to_path_buf();
        }
    }
    PathBuf::from(".")
}

/// Resolves a resource file: external path first (cwd, then exe dir).
pub fn resource_path(name: &str) -> PathBuf {
    let cwd = Path::new(name);
    if cwd.exists() {
        return cwd.to_path_buf();
    }
    let ext = base_dir().join(name);
    if ext.exists() {
        return ext;
    }
    PathBuf::from(name)
}

/// Cleans a raw domain string: strips scheme, path, port, brackets; lowercases.
/// Returns None for empty input.
pub fn clean_domain(raw: &str) -> Option<String> {
    let mut s = raw.trim().to_lowercase();
    if s.is_empty() {
        return None;
    }
    if let Some(idx) = s.find("://") {
        s = s[idx + 3..].to_string();
    }
    if let Some(idx) = s.find(['/', '?', '#']) {
        s = s[..idx].to_string();
    }
    // IPv6 literal in brackets
    if s.starts_with('[') {
        if let Some(end) = s.find(']') {
            let host = s[1..end].to_string();
            return if host.is_empty() { None } else { Some(host) };
        }
        return None;
    }
    // Bare IPv6 literal (multiple colons, no port possible)
    if s.matches(':').count() >= 2 {
        return Some(s);
    }
    // Strip :port
    if let Some(idx) = s.rfind(':') {
        let port_part = &s[idx + 1..];
        if !port_part.is_empty() && port_part.chars().all(|c| c.is_ascii_digit()) {
            s = s[..idx].to_string();
        }
    }
    s = s.trim_matches('.').to_string();
    if s.is_empty() {
        None
    } else {
        Some(s)
    }
}

/// Loads and cleans domain names from a line-separated text file.
pub fn load_domains_from_file(path: impl AsRef<Path>) -> io::Result<Vec<String>> {
    let content = fs::read_to_string(path)?;
    Ok(parse_domains(&content))
}

/// Line parsing shared by the file and the embedded domain list: blank lines and
/// `#` comments dropped, everything else through [`clean_domain`].
fn parse_domains(content: &str) -> Vec<String> {
    content
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .filter_map(clean_domain)
        .collect()
}

/// Loads whitelist SNI entries: non-empty, non-comment lines with their 1-based
/// file numbers.
///
/// The read error is returned instead of flattened to an empty list: a
/// present-but-unreadable file (an ordinary permissions mishap on an Entware
/// router) must not look like an absent one, or the caller silently substitutes
/// the embedded list and test 4 degrades with no diagnostic.
pub fn load_whitelist_sni(path: impl AsRef<Path>) -> io::Result<Vec<(String, usize)>> {
    let content = fs::read_to_string(path)?;
    Ok(parse_whitelist_sni(&content))
}

/// Line parsing shared by the file and the embedded SNI list. The second field
/// is the 1-based number of the entry, which the report prints.
fn parse_whitelist_sni(content: &str) -> Vec<(String, usize)> {
    let mut out = Vec::new();
    let mut num = 0usize;
    for line in content.lines() {
        let s = line.trim();
        if s.is_empty() || s.starts_with('#') {
            continue;
        }
        num += 1;
        out.push((s.to_string(), num));
    }
    out
}

/// Domains shipped inside the binary (fallback when domains.txt is absent).
pub fn embedded_domains() -> Vec<String> {
    parse_domains(EMBEDDED_DOMAINS_TXT)
}

/// Test 6's own shipped targets, fallback when burst-domains.txt is absent.
///
/// Separate from `embedded_domains` because the two tests ask opposite
/// questions of a host: test 2 wants sites known to be censored, test 6 wants
/// sites that answer normally until the connecting itself becomes the reason
/// they stop. One list cannot be both.
pub fn embedded_burst_domains() -> Vec<String> {
    parse_domains(EMBEDDED_BURST_DOMAINS_TXT)
}

/// Whitelist SNI shipped inside the binary.
pub fn embedded_whitelist_sni() -> Vec<(String, usize)> {
    parse_whitelist_sni(EMBEDDED_WHITELIST_SNI_TXT)
}

/// Loads the hosts whose endpoint serves no HTTP/3. The read error is returned
/// rather than flattened, for the reason `load_whitelist_sni` documents.
pub fn load_quic_unsupported(path: impl AsRef<Path>) -> io::Result<Vec<String>> {
    let content = fs::read_to_string(path)?;
    Ok(parse_quic_unsupported(&content))
}

/// Line parsing shared by the file and the embedded list: blank lines and `#`
/// comments dropped, the rest lowercased (hosts are matched whole, and DNS names
/// are case-insensitive).
fn parse_quic_unsupported(content: &str) -> Vec<String> {
    content
        .lines()
        .map(|l| l.trim())
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .map(|l| l.to_ascii_lowercase())
        .collect()
}

/// The QUIC-unsupported list shipped inside the binary.
pub fn embedded_quic_unsupported() -> Vec<String> {
    parse_quic_unsupported(EMBEDDED_QUIC_UNSUPPORTED_TXT)
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Tcp16Target {
    #[serde(default)]
    pub id: String,
    #[serde(default)]
    pub asn: String,
    #[serde(default)]
    pub provider: String,
    pub ip: String,
    #[serde(default = "default_tcp16_port")]
    pub port: u16,
    #[serde(default)]
    pub sni: Option<String>,
}

fn default_tcp16_port() -> u16 {
    443
}

impl Tcp16Target {
    /// The ASN as the tables show it: `AS` + digits, `AS` kept when the list
    /// already wrote it, `-` when the target carries none.
    pub fn display_asn(&self) -> String {
        let raw = self.asn.trim();
        if raw.is_empty() {
            "-".to_string()
        } else if raw.to_uppercase().starts_with("AS") {
            raw.to_uppercase()
        } else {
            format!("AS{}", raw)
        }
    }
}

/// Loads TCP16 targets from a JSON file.
pub fn load_tcp16_targets_from_file(path: impl AsRef<Path>) -> io::Result<Vec<Tcp16Target>> {
    let content = fs::read_to_string(path)?;
    let targets: Vec<Tcp16Target> = serde_json::from_str(&content)
        .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
    Ok(targets)
}

/// TCP16 targets shipped inside the binary.
pub fn embedded_tcp16_targets() -> Vec<Tcp16Target> {
    serde_json::from_str(EMBEDDED_TCP16_JSON).unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_clean_domain() {
        assert_eq!(clean_domain("https://Example.COM:443/path?q=1"), Some("example.com".to_string()));
        assert_eq!(clean_domain("  vk.ru  "), Some("vk.ru".to_string()));
        assert_eq!(clean_domain("[2001:db8::1]:8080"), Some("2001:db8::1".to_string()));
        assert_eq!(clean_domain("2001:db8::1"), Some("2001:db8::1".to_string()));
        assert_eq!(clean_domain(""), None);
    }

    /// A configured UA is the operator's word and wins; the built-in default is a
    /// placeholder, so the selected profile's own UA goes on the wire instead.
    #[test]
    fn user_agent_follows_the_profile_unless_configured() {
        use crate::net::fingerprint::TlsFingerprint;

        let mut cfg = AppConfig::default();
        assert!(TlsFingerprint::user_agent_for(&cfg, TlsFingerprint::Chrome107).contains("Chrome/107.0.0.0"));
        assert!(TlsFingerprint::user_agent_for(&cfg, TlsFingerprint::Firefox133).contains("Firefox/133.0"));
        assert_eq!(TlsFingerprint::user_agent_for(&cfg, TlsFingerprint::Rustls), DEFAULT_USER_AGENT);

        cfg.user_agent = "my-probe/1.0".to_string();
        for fingerprint in TlsFingerprint::ALL {
            assert_eq!(TlsFingerprint::user_agent_for(&cfg, fingerprint), "my-probe/1.0");
        }
    }

    #[test]
    fn test_config_defaults() {
        // Shipped defaults for the fields asserted below (threshold included).
        let cfg = AppConfig::default();
        assert_eq!(cfg.max_concurrent, 50);
        assert_eq!(cfg.ip_version, "ipv4");
        assert!(cfg.timeout > 0.0);
        assert!(cfg.dns_egress_concurrency > 0);
        assert_eq!(cfg.dns_stub_threshold, 2);
        assert_eq!(cfg.fat_chunks_count, 10);
        assert_eq!(cfg.telegram_dcs.len(), 5);
        assert!(!cfg.bypass_tools().is_empty());
    }

    #[test]
    fn test_config_from_yaml() {
        let cfg = AppConfig::from_yaml_str("MAX_CONCURRENT: 20\nIP_VERSION: ipv6\nUNKNOWN_KEY_X: 1\n");
        assert_eq!(cfg.max_concurrent, 20);
        assert_eq!(cfg.ip_version, "ipv6");
        assert_eq!(cfg.config_warnings.len(), 1);
    }

    #[test]
    fn test_availability_servers_parse() {
        let yaml = "DNS_AVAILABILITY_SERVERS:\n  - [\"8.8.8.8\", \"Google\", \"udp\"]\n  - [\"dns.google\", \"Google\", \"dot\", 8853]\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        let servers = cfg.availability_servers();
        assert_eq!(servers.len(), 2);
        assert_eq!(servers[0].port, 53);
        assert_eq!(servers[1].port, 8853);
    }

    /// The four `config.yml` tokens are the input contract: each parses, each
    /// carries its own default port, and any fifth spelling is a skipped row the
    /// loader names — not a server that quietly dials 443.
    #[test]
    fn test_availability_kind_vocabulary() {
        use crate::probe::dns_avail::ProbeKind;
        assert_eq!(
            ["udp", "doh_json", "doh_wire", "dot"]
                .map(|t| DnsAvailServerKind::parse(t).unwrap().default_port()),
            [53, 443, 443, 853]
        );
        // Two tables on purpose — `config`'s input vocabulary and the probe's
        // measurement one — and this is the net under that split: a row cannot be
        // loaded on one port while the endpoint table prints it against another.
        assert_eq!(
            ["udp", "doh_json", "doh_wire", "dot"]
                .map(|t| DnsAvailServerKind::parse(t).unwrap().default_port()),
            [ProbeKind::Udp, ProbeKind::DohWire, ProbeKind::DohWire, ProbeKind::Dot]
                .map(ProbeKind::default_port)
        );
        // Case-insensitive, as the string membership test it replaces was.
        assert_eq!(DnsAvailServerKind::parse("DOT"), Some(DnsAvailServerKind::Dot));
        assert_eq!(DnsAvailServerKind::parse("DoH_Json"), Some(DnsAvailServerKind::DohJson));
        assert_eq!(DnsAvailServerKind::parse("tls"), None);
        // `as_str` is the spelling an operator has to write, so it round-trips.
        for token in ["udp", "doh_json", "doh_wire", "dot"] {
            assert_eq!(DnsAvailServerKind::parse(token).map(|k| k.as_str()), Some(token));
        }
    }

    /// A port column is not the same as no port column. Absent means "the
    /// default for this kind" — the shape every shipped row has — while a column
    /// that says something undiallable would run the probe somewhere the
    /// operator never wrote: `0` can only time out, and a mistyped port must not
    /// become 53, 443 or 853 behind the operator's back. Those rows are skipped
    /// and the loader names the key.
    #[test]
    fn test_availability_port_column_must_be_diallable() {
        let yaml = concat!(
            "DNS_AVAILABILITY_SERVERS:\n",
            "  - [\"8.8.8.8\", \"absent\", \"udp\"]\n",
            "  - [\"8.8.8.8\", \"named\", \"udp\", 5353]\n",
            "  - [\"8.8.8.8\", \"zero\", \"udp\", 0]\n",
            "  - [\"8.8.8.8\", \"past-u16\", \"udp\", 65536]\n",
            "  - [\"8.8.8.8\", \"words\", \"udp\", \"fifty-three\"]\n",
        );
        let cfg = AppConfig::from_yaml_str(yaml);
        let servers = cfg.availability_servers();
        assert_eq!(servers.len(), 2, "{servers:?}");
        assert_eq!(servers[0].port, 53, "an absent port is still the kind's default");
        assert_eq!(servers[1].port, 5353, "a diallable port is kept as written");
        assert!(cfg.config_warnings.contains(&ConfigWarning::SkippedRows { key: "DNS_AVAILABILITY_SERVERS".to_string() }));
    }

    /// A value that cannot become an HTTP header, and a list row the parser
    /// skips, are both reported instead of silently ignored: the operator
    /// hand-edits config.yml, and a key that never took effect must not look
    /// like one that did.
    #[test]
    fn test_unusable_values_are_reported_not_swallowed() {
        // A block scalar keeps its trailing newline, which `http` refuses in a
        // header value; the built-in default must survive so `user_agent_for`
        // falls back to the fingerprint's own UA.
        let yaml = "USER_AGENT: |\n  Mozilla/5.0 (Windows NT 10.0)\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert_eq!(cfg.user_agent, DEFAULT_USER_AGENT);
        assert!(cfg.config_warnings.contains(&ConfigWarning::InvalidValue { key: "USER_AGENT".to_string() }));

        // Obs-text is a valid header value, so a Cyrillic UA is kept verbatim.
        let yaml = "USER_AGENT: \"Мой агент/1.0\"\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert_eq!(cfg.user_agent, "Мой агент/1.0");
        assert!(cfg.config_warnings.is_empty(), "{:?}", cfg.config_warnings);

        // A short availability row, a bypass row without its pattern list, a
        // `telegram_dcs` row the sanitizer has to drop, and a `dns_udp_servers`
        // row missing its second column.
        let yaml = "DNS_AVAILABILITY_SERVERS:\n  - [\"8.8.8.8\", \"Google\", \"udp\"]\n  - [\"1.1.1.1\", \"Cloudflare\"]\nBYPASS_TOOLS:\n  - [\"zapret\", [\"nfqws\"]]\n  - [\"broken\"]\nTELEGRAM_DCS:\n  - [\"149.154.175.53\", \"DC1\"]\n  - [\"1\"]\nDNS_UDP_SERVERS:\n  - [\"8.8.8.8\", \"Google\"]\n  - [\"1.1.1.1\"]\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert_eq!(cfg.availability_servers().len(), 1);
        assert_eq!(cfg.bypass_tools().len(), 1);
        assert_eq!(cfg.telegram_dc_list().len(), 1);
        assert_eq!(cfg.dns_udp_servers.len(), 1);
        // A list key that dropped rows is reported as skipped rows, not as an
        // invalid value: "using default" would be a lie about the rows that
        // survived and did run.
        assert!(cfg.config_warnings.contains(&ConfigWarning::SkippedRows { key: "DNS_AVAILABILITY_SERVERS".to_string() }));
        assert!(cfg.config_warnings.contains(&ConfigWarning::SkippedRows { key: "BYPASS_TOOLS".to_string() }));
        assert!(cfg.config_warnings.contains(&ConfigWarning::SkippedRows { key: "TELEGRAM_DCS".to_string() }));
        assert!(cfg.config_warnings.contains(&ConfigWarning::SkippedRows { key: "DNS_UDP_SERVERS".to_string() }));
    }

    /// A row-list key whose value is not a list of rows: `sanitize_mapping`
    /// reports the bad row and leaves it in place, so serde refuses the whole
    /// mapping and the built-in defaults replace the file. That used to be
    /// silent — the operator read "one row skipped" while their `MAX_CONCURRENT`
    /// was gone — so the refusal is now a load error, which `main` prints and the
    /// run carries on with.
    #[test]
    fn test_a_row_that_is_not_a_sequence_is_a_load_error() {
        let yaml = "MAX_CONCURRENT: 25\nDNS_AVAILABILITY_SERVERS:\n  - \"8.8.8.8 Google udp\"\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert!(cfg.config_load_error.is_some(), "{:?}", cfg.config_load_error);

        // The same shape one key over: a scalar where the rows go.
        let cfg = AppConfig::from_yaml_str("BYPASS_TOOLS: nfqws\n");
        assert!(cfg.config_load_error.is_some(), "{:?}", cfg.config_load_error);

        // A row the parser skips but serde can still read is not this failure:
        // the file loads, and every other key in it survives.
        let yaml = "MAX_CONCURRENT: 25\nDNS_AVAILABILITY_SERVERS:\n  - [\"8.8.8.8\", \"Google\", \"udp\"]\n  - [\"1.1.1.1\", \"Cloudflare\"]\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert!(cfg.config_load_error.is_none(), "{:?}", cfg.config_load_error);
        assert_eq!(cfg.max_concurrent, 25, "the rest of the file is kept");
    }

    /// A value of the wrong type or out of range is rejected: each bad key
    /// keeps its default and is named in the warnings.
    #[test]
    fn test_invalid_values_retain_default() {
        let yaml = "MAX_CONCURRENT: \"one hundred\"\nIP_VERSION: \"ipv5\"\nTIMEOUT: -5.0\nUNKNOWN_SECRET_KEY: 12345\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert_eq!(cfg.max_concurrent, 50);
        assert_eq!(cfg.ip_version, "ipv4");
        assert_eq!(cfg.timeout, 8.0);
        // Assert the typed warning, not its `Debug` rendering: that derive is
        // not a stable format, and the variant plus its payload is the contract.
        assert!(cfg.config_warnings.contains(&ConfigWarning::InvalidValue { key: "MAX_CONCURRENT".to_string() }));
        assert!(cfg.config_warnings.contains(&ConfigWarning::InvalidValue { key: "IP_VERSION".to_string() }));
        assert!(cfg.config_warnings.contains(&ConfigWarning::InvalidValue { key: "TIMEOUT".to_string() }));
        assert!(cfg.config_warnings.contains(&ConfigWarning::UnknownKey { key: "UNKNOWN_SECRET_KEY".to_string() }));
    }

    /// A config whose every key is valid loads with no warnings.
    #[test]
    fn test_valid_custom_config() {
        let yaml = "MAX_CONCURRENT: 25\nIP_VERSION: \"ipv6\"\nTIMEOUT: 15.0\nDNS_STUB_THRESHOLD: 3\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert_eq!(cfg.max_concurrent, 25);
        assert_eq!(cfg.ip_version, "ipv6");
        assert_eq!(cfg.timeout, 15.0);
        assert_eq!(cfg.dns_stub_threshold, 3);
        assert!(cfg.config_warnings.is_empty(), "{:?}", cfg.config_warnings);
    }

    /// `IP_LOOKUP_URLS` compat: v4 falls back to the shared list, v6 keeps its
    /// own default, and an explicit `IP4_LOOKUP_URLS` wins over the fallback.
    #[test]
    fn test_ip_lookup_urls_compat() {
        let yaml = "IP_LOOKUP_URLS:\n  - \"https://example.com/v4\"\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert_eq!(cfg.ip4_lookup_urls, vec!["https://example.com/v4".to_string()]);
        assert_eq!(cfg.ip6_lookup_urls, d_ip6_lookup_urls());
        // Explicit IP4 wins over compat.
        let yaml = "IP_LOOKUP_URLS:\n  - \"https://example.com/v4\"\nIP4_LOOKUP_URLS:\n  - \"https://example.com/other\"\n";
        let cfg = AppConfig::from_yaml_str(yaml);
        assert_eq!(cfg.ip4_lookup_urls, vec!["https://example.com/other".to_string()]);
    }

    /// Every list parsed from the shipped config.yml matches the values
    /// asserted below: any drift fails here.
    #[test]
    fn test_lists_match_shipped_config_yml() {
        let cfg = AppConfig::from_yaml_str(include_str!("../../../config.yml"));
        assert!(cfg.config_load_error.is_none(), "{:?}", cfg.config_load_error);
        assert_eq!(
            cfg.dns_check_domains,
            vec!["rutor.info", "flibusta.is", "clubtone.do.am", "rezka.ag", "shikimori.one"]
        );
        assert_eq!(cfg.dns_udp_servers.len(), 17);
        assert_eq!(cfg.dns_udp_servers[0], vec!["8.8.8.8", "Google"]);
        assert_eq!(cfg.dns_availability_domains, vec!["vk.ru", "gosuslugi.ru"]);
        let servers = cfg.availability_servers();
        assert_eq!(servers.iter().filter(|s| s.kind.as_str() == "udp").count(), 49);
        assert_eq!(servers.iter().filter(|s| s.kind.as_str() == "doh_wire").count(), 37);
        assert_eq!(servers.iter().filter(|s| s.kind.as_str() == "dot").count(), 34);
        assert_eq!(servers.len(), 120);
        assert_eq!(servers[0].addr, "94.140.14.14");
        assert_eq!(servers.last().map(|s| s.kind.as_str()), Some("dot"));
        assert_eq!(cfg.telegram_dc_list().len(), 5);
        assert_eq!(cfg.telegram_dc_list()[0], ("149.154.175.53".to_string(), "DC1".to_string()));
        let tools = cfg.bypass_tools();
        assert_eq!(tools.len(), 24);
        assert_eq!(tools[0].0, "zapret");
        assert_eq!(cfg.ip4_lookup_urls.len(), 3);
        assert_eq!(cfg.concurrency_presets, vec![1, 5, 20, 50, 100]);
        assert_eq!(cfg.cymru_doh_servers.len(), 5);
        assert_eq!(cfg.ip6_lookup_urls.len(), 4);
        assert_eq!(cfg.dns_known_resolver_names.len(), 31);
        assert!(cfg.dns_known_resolver_names.contains(&"google".to_string()));
        assert!(cfg.dns_known_resolver_names.contains(&"yandex".to_string()));
        assert_eq!(cfg.dns_hijack_exempt_resolvers, vec!["MSK-IX", "НСДИ"]);
        assert_eq!(cfg.timeout, 8.0);
    }

    /// No-file fallbacks carry the same lists (embedded use without config.yml).
    #[test]
    fn test_default_lists_match_shipped_yml() {
        let from_yml = AppConfig::from_yaml_str(include_str!("../../../config.yml"));
        let def = AppConfig::default();
        assert_eq!(def.dns_check_domains, from_yml.dns_check_domains);
        assert_eq!(def.dns_udp_servers, from_yml.dns_udp_servers);
        assert_eq!(def.dns_availability_domains, from_yml.dns_availability_domains);
        assert_eq!(def.telegram_dcs, from_yml.telegram_dcs);
        assert_eq!(def.bypass_tools(), from_yml.bypass_tools());
        assert_eq!(def.cymru_doh_servers, from_yml.cymru_doh_servers);
        assert_eq!(def.ip4_lookup_urls, from_yml.ip4_lookup_urls);
        assert_eq!(def.ip6_lookup_urls, from_yml.ip6_lookup_urls);
        assert_eq!(def.dns_known_resolver_names, from_yml.dns_known_resolver_names);
        assert_eq!(def.dns_hijack_exempt_resolvers, from_yml.dns_hijack_exempt_resolvers);
        assert_eq!(def.concurrency_presets, from_yml.concurrency_presets);
        assert_eq!(def.timeout, from_yml.timeout);
    }

    /// Embedded fallbacks parse to the same lists as the shipped files.
    #[test]
    fn test_embedded_lists_match_files() {
        let domains = embedded_domains();
        assert!(!domains.is_empty(), "the fallback ships a list");
        assert!(domains.contains(&"vk.ru".to_string()));
        assert!(domains.contains(&"www.instagram.com".to_string()));
        // The list is data, not a constant - it grows and shrinks with the file,
        // so pin the invariant instead of a count: no shipped line may be
        // dropped by the cleaner.
        let shipped = EMBEDDED_DOMAINS_TXT
            .lines()
            .filter(|l| !l.trim().is_empty() && !l.trim().starts_with('#'))
            .count();
        assert_eq!(domains.len(), shipped, "every shipped domain survives cleaning");
        let file_targets: Vec<Tcp16Target> =
            serde_json::from_str(include_str!("../../../tcp16.json")).unwrap();
        assert_eq!(embedded_tcp16_targets(), file_targets);
        assert!(!embedded_tcp16_targets().is_empty());
        assert!(!embedded_whitelist_sni().is_empty());
        // The QUIC-unsupported list: the same invariant (every shipped line
        // survives parsing) and the one property the column depends on — its
        // hosts are hosts test 2 actually probes, or the dash never appears.
        let unsupported = embedded_quic_unsupported();
        assert!(!unsupported.is_empty(), "the fallback ships a list");
        assert!(unsupported.contains(&"www.canva.com".to_string()));
        let shipped_unsupported = EMBEDDED_QUIC_UNSUPPORTED_TXT
            .lines()
            .filter(|l| !l.trim().is_empty() && !l.trim().starts_with('#'))
            .count();
        assert_eq!(unsupported.len(), shipped_unsupported, "every shipped host survives parsing");
        assert!(
            unsupported.iter().any(|h| domains.contains(h)),
            "the list names hosts the shipped domains.txt probes"
        );
        // Test 6 ships its own short list of ordinary hosts: same invariant, and
        // it is not the censored-sites list test 2 probes.
        let burst = embedded_burst_domains();
        assert!(!burst.is_empty(), "the fallback ships a list");
        assert!(burst.contains(&"ezgame.su".to_string()));
        assert!(burst.contains(&"www.smartape.ru".to_string()));
        assert!(!burst.iter().any(|d| domains.contains(d)), "the two lists ask different questions");
        let shipped_burst = EMBEDDED_BURST_DOMAINS_TXT
            .lines()
            .filter(|l| !l.trim().is_empty() && !l.trim().starts_with('#'))
            .count();
        assert_eq!(burst.len(), shipped_burst, "every shipped burst target survives cleaning");
        let cfg = AppConfig::from_yaml_str(EMBEDDED_CONFIG_YML);
        assert_eq!(cfg.availability_servers().len(), 120);
    }
}
