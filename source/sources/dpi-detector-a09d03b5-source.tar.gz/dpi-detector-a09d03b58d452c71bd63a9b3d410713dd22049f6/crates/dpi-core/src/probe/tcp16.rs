//! Test 3: FAT-header TCP probe.
//!
//! Opens one keep-alive connection per target and sends `fat_chunks_count`
//! HEAD requests with a growing `X-Pad` header (`fat_chunk_size` bytes per
//! step, 10 × 4 KB = 40 KB total). A break inside the DPI window
//! (`tcp_block_min_kb`..`tcp_block_max_kb`) is reported as DETECTED.

use std::hash::{Hash, Hasher};
use std::net::{IpAddr, SocketAddr};
use std::sync::OnceLock;
use std::time::{Duration, Instant};
use http_body_util::{BodyExt, Limited};

use hyper::Method;
use rustls::pki_types::ServerName;
use tokio::sync::Semaphore;
use tokio::time::timeout;
use tokio_rustls::TlsConnector;

use crate::classify::{
    classify_connect_error_full, classify_connect_error_icmp, classify_read_error, Detail,
    DpiStatus, ProbeStage,
};
use crate::config::AppConfig;
use crate::net::fingerprint::{http_identity, TlsFingerprint};
use crate::net::http::{
    http_err_info, negotiated_h2, request_headers, BODY_CAP, HttpRequest, HttpSender,
};
use crate::net::tcp::{dial_tcp, DialError};
use crate::net::tls::{create_tls_config, TlsProfile};

/// The X-Pad bytes. Seeded from the OS once per run: a constant seed made
/// every probe of every user pad with the same 4 KB header, which is a
/// signature a censor can match to block the tool itself rather than the
/// traffic it measures.
fn random_pool(size: usize) -> Vec<u8> {
    // xorshift64* — deterministic PRNG, no extra deps, ASCII alphanumerics
    let mut state: u64 = rand::random();
    if state == 0 {
        // xorshift never leaves zero once there.
        state = 0x9E3779B97F4A7C15;
    }
    let mut out = Vec::with_capacity(size);
    while out.len() < size {
        state ^= state >> 12;
        state ^= state << 25;
        state ^= state >> 27;
        let v = state.wrapping_mul(0x2545F4914F6CDD1D);
        for b in v.to_le_bytes() {
            out.push(b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"[(b % 62) as usize]);
            if out.len() >= size {
                break;
            }
        }
    }
    out
}

/// One pool per process, not one per probe: 100 KB instead of 100 KB ×
/// concurrency (5 MB at the shipped 50). It stays an `OnceLock` rather than a
/// `LazyLock` because its size is the configured `fat_random_pool_size`, known
/// only at runtime.
static PAD_POOL: OnceLock<Vec<u8>> = OnceLock::new();

fn pad_pool(size: usize) -> &'static [u8] {
    PAD_POOL.get_or_init(|| random_pool(size))
}

/// Which connection is being padded. A target keeps its bytes for the run, and
/// two targets do not pad alike, so the same slice does not travel to every
/// destination from every user.
fn conn_key(ip: IpAddr, port: u16, sni: &str) -> u64 {
    let mut h = std::collections::hash_map::DefaultHasher::new();
    ip.hash(&mut h);
    port.hash(&mut h);
    sni.hash(&mut h);
    h.finish()
}

/// Where in the pool a chunk's padding starts. Within one connection every
/// chunk must take a different slice: HTTP/2 compresses headers, so an
/// identical value is HPACK-indexed after its first use and stops reaching the
/// wire, and the probe would upload far less than its chunk count claims while
/// still reporting the window it thinks it crossed. The step and the pool size
/// are coprime (7919 is prime and does not divide 96000), so rotating the
/// start by connection keeps the slices of one connection distinct.
fn pad_offset(max_start: usize, chunk: usize, conn: u64) -> usize {
    if max_start == 0 {
        return 0;
    }
    (conn as usize).wrapping_add(chunk.wrapping_mul(7919)) % max_start
}

async fn connect_fat_target(
    addr: SocketAddr,
    target_ip: IpAddr,
    sni: &str,
    use_tls: bool,
    cfg: &AppConfig,
) -> Result<HttpSender, (DpiStatus, Detail)> {
    let connect_stage = ProbeStage::TcpConnect;
    let tcp = match dial_tcp(&addr, Duration::from_secs_f64(cfg.fat_connect_timeout)).await {
        Ok(s) => s,
        Err(DialError::Io { error, icmp }) => {
            let (s, d) = classify_connect_error_icmp(&error, icmp, 0, connect_stage);
            return Err((s, d));
        }
        Err(DialError::Timeout) => {
            return Err((DpiStatus::SynDropped, Detail::TcpSynTimeout));
        }
    };

    if use_tls {
        let server_name = if sni.is_empty() {
            ServerName::IpAddress(rustls::pki_types::IpAddr::from(target_ip))
        } else {
            match ServerName::try_from(sni.to_string()) {
                Ok(n) => n,
                Err(_) => ServerName::IpAddress(rustls::pki_types::IpAddr::from(target_ip)),
            }
        };
        let profile = TlsProfile::insecure(TlsFingerprint::from_config(cfg));
        let tls_stream = match timeout(
            Duration::from_secs_f64(cfg.fat_connect_timeout),
            TlsConnector::from(create_tls_config(&profile)).connect(server_name, tcp),
        )
        .await
        {
            Ok(Ok(s)) => s,
            Ok(Err(e)) => {
                let msg = e.to_string();
                let (s, d) = classify_connect_error_full(&msg, e.raw_os_error(), Some(e.kind()), 0, ProbeStage::TlsHandshake);
                return Err((s, d));
            }
            Err(_) => {
                return Err((DpiStatus::TlsDropped, Detail::TlsHandshakeTimeout));
            }
        };
        let alpn_h2 = negotiated_h2(&tls_stream);
        match HttpSender::handshake(tls_stream, alpn_h2, TlsFingerprint::from_config(cfg)).await {
            Ok(sender) => Ok(sender),
            Err(e) => {
                let (msg, os_code, os_kind) = http_err_info(&e);
                let (s, d) = classify_connect_error_full(&msg, os_code, os_kind, 0, ProbeStage::TlsConnected);
                Err((s, d))
            }
        }
    } else {
        // No TLS, so no ALPN: HTTP/1.1 is the only protocol on the wire here.
        match HttpSender::handshake(tcp, false, TlsFingerprint::from_config(cfg)).await {
            Ok(sender) => Ok(sender),
            Err(e) => {
                let (msg, os_code, os_kind) = http_err_info(&e);
                let (s, d) = classify_connect_error_full(&msg, os_code, os_kind, 0, ProbeStage::TcpConnect);
                Err((s, d))
            }
        }
    }
}

/// KB actually handed to the socket before the failing chunk, rounded up: the
/// detail reports the chunk the drop happened in, and cutting the remainder
/// (`i * chunk_size / 1024`) made a 16 KB mark read as `15KB` on the default
/// One row of test 3's report: the machine-readable shape `--json` carries and
/// the table renders. It lives here, beside the probe, so a column added for the
/// table is a change to a contract with a `SCHEMA_VERSION` behind it rather than
/// a view edit that moves the schema silently.
#[derive(Clone, serde::Serialize)]
pub struct Tcp16Row {
    pub id: String,
    pub asn: String,
    pub provider: String,
    pub status: DpiStatus,
    pub detail: Detail,
}

/// 4000-byte chunks.
fn kb_sent(chunks_sent: usize, chunk_size: usize) -> usize {
    (chunks_sent * chunk_size).div_ceil(1024)
}

/// Raw FAT probe. Returns (status, detail, rtt_secs).
pub async fn probe_tcp_16_20(
    ip: &str,
    port: u16,
    sni: &str,
    cfg: &AppConfig,
    hint_rtt: Option<f64>,
) -> (DpiStatus, Detail, Option<f64>) {
    let target_ip: IpAddr = match ip.parse() {
        Ok(a) => a,
        Err(_) => {
            return (DpiStatus::Err, Detail::Other(format!("bad IP: {}", ip)), None);
        }
    };
    let addr = SocketAddr::new(target_ip, port);
    let use_tls = port != 80;

    let chunks = cfg.fat_chunks_count.max(1);
    let chunk_size = cfg.fat_chunk_size.max(1);
    let min_detect_chunk =
        (cfg.tcp_block_min_kb * 1024).div_ceil(chunk_size as u64).max(1) as usize;

    // Dynamic read timeout: 3 × RTT clamped to 1.5 s..fat_read_timeout, seeded by the
    // hint or, when there is none, by the slowest of the first two measured RTTs.
    let mut dynamic_timeout = hint_rtt.map(|r| (r * 3.0).max(1.5).min(cfg.fat_read_timeout));
    let mut measured_rtt = hint_rtt;
    let mut rtt_samples: Vec<f64> = Vec::new();

    let pool = pad_pool(cfg.fat_random_pool_size.max(chunk_size + 1));
    let conn = conn_key(target_ip, port, sni);

    let host_val = if !sni.is_empty() {
        sni.to_string()
    } else if port == 80 || port == 443 {
        target_ip.to_string()
    } else {
        format!("{}:{}", target_ip, port)
    };

    // Read once per target instead of once per chunk (and again on the retry):
    // the identity is a `Copy` view of a static table, and the user agent comes
    // from the config.
    let identity = http_identity(TlsFingerprint::from_config(cfg));
    let user_agent = TlsFingerprint::user_agent_for(cfg, TlsFingerprint::from_config(cfg));

    let mut sender = match connect_fat_target(addr, target_ip, sni, use_tls, cfg).await {
        Ok(s) => s,
        Err((s, d)) => return (s, d, measured_rtt),
    };


    for i in 0..chunks {
        // If keep-alive connection was closed by peer or previous response, reconnect
        if sender.is_closed() {
            sender = match connect_fat_target(addr, target_ip, sni, use_tls, cfg).await {
                Ok(s) => s,
                Err((_s, d)) => {
                    if i < min_detect_chunk {
                        return (DpiStatus::Timeout, d, measured_rtt);
                    } else {
                        return (
                            DpiStatus::Tcp16Detected,
                            Detail::at_kb(d, kb_sent(i, chunk_size) as f64),
                            measured_rtt,
                        );
                    }
                }
            };
        }

        let pad_str = if i > 0 {
            let max_start = pool.len().saturating_sub(chunk_size);
            let start_idx = pad_offset(max_start, i, conn);
            // Borrowed from the pool, not owned: the pool is ASCII alphanumerics
            // by construction (`random_pool`, pinned by `test_random_pool_ascii`),
            // so the slice is already valid UTF-8 and the one owned copy of these
            // bytes happens below, where the header value is built.
            std::str::from_utf8(&pool[start_idx..start_idx + chunk_size]).ok()
        } else {
            None
        };

        let make_req = |pad: Option<&str>| -> HttpRequest<'_> {
            let mut extras = vec![("Connection", "keep-alive".into())];
            if let Some(p) = pad {
                extras.push(("X-Pad", p.to_string().into()));
            }
            HttpRequest {
                method: Method::HEAD,
                host: &host_val,
                path: "/",
                headers: request_headers(&identity, user_agent, extras, true),
                priority_on_h1: identity.priority_on_h1,
            }
        };

        let req = make_req(pad_str);
        let read_timeout = dynamic_timeout.unwrap_or(cfg.fat_read_timeout);
        let t0 = Instant::now();

        let mut res = timeout(Duration::from_secs_f64(read_timeout), sender.send(req)).await;

        // If connection was closed concurrently between requests, reconnect and retry this chunk once
        if let Ok(Err(ref e)) = res {
            let (emsg, _, _) = http_err_info(e);
            if e.is_canceled() || emsg.contains("canceled") || sender.is_closed() {
                if let Ok(new_sender) = connect_fat_target(addr, target_ip, sni, use_tls, cfg).await {
                    sender = new_sender;
                    let retry_req = make_req(pad_str);
                    res = timeout(Duration::from_secs_f64(read_timeout), sender.send(retry_req)).await;
                }
            }
        }

        match res {
            Ok(Ok(resp)) => {
                // The body is dropped, but the await is not free: hyper answers
                // a HEAD over h1 with an empty body, while over h2 the stream
                // ends only on END_STREAM, so a peer that sends headers and then
                // goes quiet would leave this pending for good — `runner.rs` has
                // no outer cap on the fat probe, so that would hang the phase.
                // The deadline is the read timeout the request itself used.
                let _ = timeout(
                    Duration::from_secs_f64(read_timeout),
                    Limited::new(resp.into_body(), BODY_CAP).collect(),
                )
                .await;
                let elapsed = t0.elapsed().as_secs_f64();
                if i == 0 && measured_rtt.is_none() {
                    measured_rtt = Some(elapsed);
                }
                if hint_rtt.is_none() && i < 2 {
                    rtt_samples.push(elapsed);
                    if rtt_samples.len() == 2 {
                        let base = rtt_samples.iter().cloned().reduce(f64::max).unwrap_or(elapsed);
                        dynamic_timeout = Some((base * 3.0).max(1.5).min(cfg.fat_read_timeout));
                    }
                }
                if cfg.fat_chunk_delay > 0.0 {
                    tokio::time::sleep(Duration::from_secs_f64(cfg.fat_chunk_delay)).await;
                }
            }
            Ok(Err(e)) => {
                let (msg, os_code, os_kind) = http_err_info(&e);
                let lower = msg.to_ascii_lowercase();
                let is_read_timeout = e.is_timeout() || lower.contains("timed out");
                if is_read_timeout {
                    let err_type = if lower.contains("write") {
                        Detail::WriteTimeoutWord
                    } else {
                        Detail::ReadTimeoutWord
                    };
                    if i == 0 {
                        return (DpiStatus::ReadTimeout, Detail::at_kb(err_type, 0.0), measured_rtt);
                    }
                    // Before the window opens the verdict is a plain timeout, but
                    // the offset it died at is still the useful part of it.
                    if i < min_detect_chunk {
                        return (
                            DpiStatus::Timeout,
                            Detail::at_kb(err_type, kb_sent(i, chunk_size) as f64),
                            measured_rtt,
                        );
                    }
                    return (
                        DpiStatus::Tcp16Detected,
                        Detail::at_kb(err_type, kb_sent(i, chunk_size) as f64),
                        measured_rtt,
                    );
                }
                let (s, d) = classify_read_error(&msg, os_code, os_kind, 0);
                if i == 0 {
                    return (s, d, measured_rtt);
                }
                if i < min_detect_chunk {
                    return (
                        DpiStatus::Timeout,
                        Detail::at_kb(d, kb_sent(i, chunk_size) as f64),
                        measured_rtt,
                    );
                }
                return (
                    DpiStatus::Tcp16Detected,
                    Detail::at_kb(d, kb_sent(i, chunk_size) as f64),
                    measured_rtt,
                );
            }
            Err(_) => {
                if i == 0 {
                    return (DpiStatus::ReadTimeout, Detail::at_kb(Detail::ReadTimeoutWord, 0.0), measured_rtt);
                }
                if i < min_detect_chunk {
                    return (
                        DpiStatus::Timeout,
                        Detail::at_kb(Detail::ReadTimeoutWord, kb_sent(i, chunk_size) as f64),
                        measured_rtt,
                    );
                }
                return (
                    DpiStatus::Tcp16Detected,
                    Detail::at_kb(Detail::ReadTimeoutWord, kb_sent(i, chunk_size) as f64),
                    measured_rtt,
                );
            }
        }
    }

    (DpiStatus::Ok, Detail::None, measured_rtt)
}

/// Semaphore-gated wrapper: takes one permit per probe, then runs `probe_tcp_16_20`.
pub async fn check_tcp_16_20(
    ip: &str,
    port: u16,
    sni: &str,
    cfg: &AppConfig,
    sem: &Semaphore,
    hint_rtt: Option<f64>,
) -> (DpiStatus, Detail, Option<f64>) {
    let _permit = crate::probe::permit(sem).await;
    probe_tcp_16_20(ip, port, sni, cfg, hint_rtt).await
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_random_pool_ascii() {
        let pool = random_pool(1000);
        assert_eq!(pool.len(), 1000);
        assert!(pool.iter().all(|b| b.is_ascii_alphanumeric()));
    }

    /// The pool is seeded per run, so two pools must not come out alike: a
    /// constant seed is what put the same 4 KB header on the wire for every
    /// user, every target and every run.
    #[test]
    fn pool_bytes_differ_between_pools() {
        assert_ne!(random_pool(64), random_pool(64));
    }

    /// One pool per process: rebuilding it per probe is what made 50
    /// concurrent probes hold 5 MB of identical padding.
    #[test]
    fn pad_pool_is_built_once() {
        assert_eq!(pad_pool(4_000), pad_pool(4_000));
    }

    /// Every chunk of one connection must take its own slice: HTTP/2 indexes a
    /// repeated header value after its first use, so an identical pad stops
    /// reaching the wire and the probe under-uploads what it counts.
    #[test]
    fn chunks_of_one_connection_use_distinct_slices() {
        let (pool_len, chunk) = (100_000usize, 4_000usize);
        let max_start = pool_len - chunk;
        let conn = conn_key("192.0.2.1".parse().unwrap(), 443, "example.com");
        let mut seen: Vec<usize> = Vec::new();
        for i in 1..10 {
            let off = pad_offset(max_start, i, conn);
            assert!(off + chunk <= pool_len, "смещение {off} вышло за пул");
            assert!(!seen.contains(&off), "чанк {i} повторил смещение {off}");
            seen.push(off);
        }
    }

    /// Targets must not pad alike, or one captured connection describes every
    /// connection the tool makes.
    #[test]
    fn different_targets_spread_over_the_pool() {
        let max_start = 96_000;
        let mut offsets = std::collections::HashSet::new();
        for n in 1..=64u8 {
            let key = conn_key(IpAddr::from([192, 0, 2, n]), 443, "example.com");
            offsets.insert(pad_offset(max_start, 1, key));
        }
        // A collision or two over 96000 slots is possible; one shared slice is
        // not.
        assert!(offsets.len() >= 60, "смещений всего {}", offsets.len());
    }

    #[test]
    fn test_min_detect_chunk_math() {
        // 12 KB / 4 KB = chunk 3
        let chunk_size = 4000usize;
        let min_detect = (12u64 * 1024).div_ceil(chunk_size as u64).max(1) as usize;
        assert_eq!(min_detect, 4); // chunks are 0-based: the detect range starts at i>=4
    }

    /// The offset in the detail is the mark the drop happened at, not the last
    /// whole KB below it: 4 chunks of 4000 B are 16 KB (15.6 rounded down read
    /// as "15KB" and made the 16 KB test look off by one).
    #[test]
    fn test_kb_sent_rounds_up_to_the_mark() {
        assert_eq!(kb_sent(4, 4000), 16);
        assert_eq!(kb_sent(5, 4000), 20);
        assert_eq!(kb_sent(3, 4000), 12);
        assert_eq!(kb_sent(3, 1024), 3);
        assert_eq!(kb_sent(0, 4000), 0);
    }
}
