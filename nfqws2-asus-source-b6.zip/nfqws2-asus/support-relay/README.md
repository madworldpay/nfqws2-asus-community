# Diagnostic mail relay

Separate operator service; it is never included in the router IPK. The router
defaults to mail disabled. A fixed HTTPS endpoint and a fixed mailbox must be
configured privately by the operator before mail can be offered to users.

The service accepts only the closed `support/report.schema.json` collector
format and a filename matching its model and timestamp. It mails the original
bytes as one JSON attachment. It cannot choose a recipient from a request.
It does not retain report bodies or raw client addresses. SQLite contains only
submission IDs, digests, states, timestamps and daily source HMACs.

Each SMTP operation runs in one short-lived Linux child. The parent enforces
one 10-second wall-clock budget, including native DNS and TLS stalls; killing
the parent also kills that child. Only safe phase markers cross the pipe.
A timeout after beginning DATA is unknown; a confirmed DATA 250 stays accepted
if cleanup stalls. No report, address or credential is written to a child argv,
environment or temporary file.

SMTP acceptance means a 250 reply after DATA; it does not promise Inbox delivery.
An ambiguous disconnect is terminal `unknown`, with no automatic resend. A
safe failure needs an explicit new user action and a new UUID. Quotas count
reserved attempts, including failures: 3/source/day, 20 globally/day, one active
SMTP operation. Reservations are atomic across both workers; stale 30-second
leases become unknown. Hourly expiry uses a 6-day-23-hour cutoff, keeping a
margin below seven days while the service and timer are running. An offline
machine cannot run cleanup; startup/request cleanup catches up on resumption.

## Operator prerequisites

Use a supported Linux host with Python 3.10+, systemd encrypted credentials,
an existing valid TLS certificate, an unused TCP 443 and outbound SMTP access.
Verify DNS, TCP, TLS and SMTP AUTH first. A TCP timeout precedes authentication;
changing mailbox passwords cannot fix that timeout. Do not deploy this service
until the SMTP check succeeds. A Gmail account needs 2-Step Verification and a
valid app password; an ordinary account password or passkey is not a substitute.

No test email is sent by health checks, credential loading, installation or
restart. Get explicit operator permission before sending a concrete test report.

## Installation after SMTP preflight succeeds

1. Save the original service, listener, firewall and certificate state privately.
   Do not alter an existing Hysteria listener or its configuration. HTTPS uses
   TCP 443 only; it does not take UDP 443. Keep standalone certificate renewal's
   TCP 80 free. If another HTTPS server owns TCP 443, integrate a dedicated
   server block through that operator's normal process instead of replacing it.
2. Privately render `deploy/nginx.conf.example` first, changing only the hostname
   and certificate paths. On a **fresh Debian/Ubuntu host**, run as root:
   `python3 support-relay/deploy/install-nginx.py /private/rendered-site.conf`.
   The helper refuses existing Nginx/operator policy, masks only the new Nginx
   service, and temporarily denies package autostart before installing Nginx
   and Python venv support. It disables only the newly packaged default site,
   checks the complete configuration has only `listen 443 ssl`, and starts
   Nginx only after validation. Failure keeps the new service masked; inspect
   privately and revalidate before unmasking. The temporary package policy is
   removed without replacing an operator policy. For an **existing** Nginx,
   do not run this helper: integrate the server block manually, preserve all
   operator sites, inspect `nginx -T`, validate, and reload through its owner.
   Verify `ss -ltnp 'sport = :80'` remains empty outside standalone renewal.
   Never install/start the packaged default port-80 site as an intermediate step.
   Copy the
   `support-relay` and sibling `support` directories under a root-owned
   `/usr/local/lib/nfqws-support/`. Keep their relative layout. Create `venv`
   there and run `venv/bin/python -m pip install --require-hashes -r
   support-relay/requirements.lock`. Do not install unpinned runtime packages.
3. Install `deploy/nfqws-support.sysusers` as
   `/etc/sysusers.d/nfqws-support.conf`, then run `systemd-sysusers`. The account
   has no login shell. Install the service and cleanup service/timer into
   `/etc/systemd/system/`. Source and venv remain root-owned and read-only to
   the service account. StateDirectory owns the only writable application path.
4. Build the configuration in a private operator process using prompts and
   `getpass`, keeping it only in memory. The example JSON shows its shape;
   its placeholders must be replaced. Use a random 32-byte HMAC key, the full
   sender address and the same address as `sender`. Strip spaces from the
   16-character app password. Send the JSON over anonymous stdin directly to
   `systemd-creds encrypt --name=relay-config -
   /etc/credstore.encrypted/nfqws-support.cred`. Run the process as root and
   set the encrypted file mode to 0600. Never put the plaintext in a file,
   command argument, environment variable, shell history or diagnostic log.
   The encrypted file is machine-bound; preserve recovery access separately.
5. Keep the privately rendered `deploy/nginx.conf.example` from step 2.
   The file is a server block, for the operator's `http` context. No address or
   mailbox is substituted into public source or packages. Leave request logging
   off (including the server-scoped `/dev/null` error log) and request buffering on; the body buffer fits the full allowed 1 MiB.
   Validate with `nginx -t` before reloading. Install `renew-nginx.sh` only as a
   certificate renewal deploy hook: it validates and reloads Nginx alone.
6. Run `systemd-analyze verify` for the installed units. Enable/start
   `nfqws-support.service` and `nfqws-support-cleanup.timer`. Verify HTTPS
   `/health` returns only `{"state":"ready"}`. Health does not authenticate
   to SMTP, so a successful health response is not proof of working mail.
7. The router operator may separately configure its private, root-owned 0600
   `/opt/etc/nfqws-asus-web/support-relay.json` with `enabled: true` and the
   HTTPS `/nfqws-support/v1/reports` URL. Do not distribute a personal deployment
   address through the public package. Router installation is a separate step.

## Verification and rollback

Use fake SMTP for routine tests. Set `NFQWS_MAIL_TEST_PYTHON` to a private
hash-locked venv and `PHP_TEST_BINARY` to a matching Entware test runtime;
run `python -m unittest discover -s tests -p 'test_support_relay_*.py' -v`
from the repository root. `NGINX_TEST_BINARY` enables the isolated real Nginx
TLS/body-cap integration fixture. There are no calls to the real mail service.

For rollback, disable router mail first (local preview/save still work), stop
and disable only the new service and cleanup timer, remove only this server
block and validate Nginx before reload. Restore saved original configuration.
Do not restart unrelated services or replace their listeners. Delete this
service's encrypted credential and metadata only after an explicit operator
decision; downloaded reports and already delivered mailbox attachments have
independent retention. A service restart never automatically resends a report.
