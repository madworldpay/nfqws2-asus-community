import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Link,
  Stack,
  Typography,
} from '@mui/material';

import { useTranslation } from '@/hooks/useTranslation';

export const RequirementsDialog = ({ onClose }: { onClose: VoidFunction }) => {
  const { t } = useTranslation();
  return (
    <Dialog open maxWidth="sm" fullWidth onClose={onClose}>
      <DialogTitle>{t('requirements.title')}</DialogTitle>
      <DialogContent>
        <Typography variant="body2">{t('requirements.intro')}</Typography>
        <Stack component="ol" spacing={2} sx={{ pl: 3 }}>
          {(
            [
              'platform',
              'dns',
              'transit',
              'ark',
              'traffic',
              'verify',
              'updates',
            ] as const
          ).map((item) => (
            <Typography component="li" variant="body2" key={item}>
              {t(`requirements.items.${item}`)}
            </Typography>
          ))}
        </Stack>
        <Typography variant="body2">{t('requirements.sources')}:</Typography>
        <Stack spacing={1}>
          <Link
            href="https://www.asuswrt-merlin.net/download"
            target="_blank"
            rel="noreferrer"
          >
            Asuswrt-Merlin
          </Link>
          <Link
            href="https://github.com/nfqws/nfqws2-keenetic#подготовка-keeneticnetcraze"
            target="_blank"
            rel="noreferrer"
          >
            NFQWS2
          </Link>
          <Link
            href="https://www.asus.com/support/faq/1045253/"
            target="_blank"
            rel="noreferrer"
          >
            ASUS DNS
          </Link>
          <Link
            href="https://github.com/RMerl/asuswrt-merlin.ng/wiki/DNS-Director"
            target="_blank"
            rel="noreferrer"
          >
            Merlin DNS Director
          </Link>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.close')}</Button>
      </DialogActions>
    </Dialog>
  );
};
