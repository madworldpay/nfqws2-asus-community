<?php
require __DIR__ . '/../webui/web/public/support-report-values.php';
function check($yes, $name) { if (!$yes) throw new RuntimeException($name); }
$v = new AsusReportValues();
check($v::decimal('18446744073709551615', '18446744073709551615') === '18446744073709551615', 'uint64 remains decimal text');
check($v::decimal('18446744073709551616', '18446744073709551615') === null, 'overflow');
check($v::decimal('-1', '4294967295') === null, 'negative');
check($v::uint32('4294967295') == 4294967295.0, 'uint32 on ARM32');
$s = $v::literalSettings("A='literal\nvalue'\nB=123 # comment\nC=\"$(touch /tmp/REPORT_CANARY)\"\nB=2\nD='one'\"two\"\n");
check($s['A'] === "literal\nvalue", 'multiline literal');
check($s['B'] === null && $s['C'] === null && $s['D'] === null, 'duplicates and dynamic expressions unknown');
check(!file_exists('/tmp/REPORT_CANARY'), 'no shell evaluation');
check($v->alias('WAN', 'secret-iface') === $v->alias('WAN', 'secret-iface'), 'stable within report');
check($v->alias('WAN', 'another') === 'WAN_2', 'local aliases');
foreach (['0.0.0.0/0','192.168.1.1/32','::/0','2001:db8::1/128'] as $ip) check($v::network($ip) !== null, 'network parse');
check($v::overlaps($v::network('192.168.0.0/16'), $v::network('192.168.1.1/32')), 'overlap');
check(!$v::overlaps($v::network('192.168.0.0/24'), $v::network('192.168.1.1/32')), 'disjoint');
check($v::network('::/129') === null, 'invalid prefix');
echo "PASS values\n";
